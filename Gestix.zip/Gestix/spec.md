# Feature Specification: Pesquisa e Base Narrativa do GESTIX

**Feature Branch**: `001-pesquisa-base-narrativa`

**Created**: 2026-10-22

**Status**: Draft

**Input**: User description: Organizar e documentar referências de jogos e estilos visuais e a base narrativa atual do GESTIX, distinguindo conteúdo aprovado, propostas provisórias e decisões pendentes.

## User Scenarios & Testing *(mandatory)*

### User Story 1 - Consultar referências de pesquisa (Priority: P1)

Como integrante do grupo, quero consultar referências de jogos e estilos visuais considerados para
GESTIX, entendendo a origem e a relevância de cada referência, para embasar discussões sem presumir
que uma referência já representa uma escolha de direção artística.

**Why this priority**: As referências documentadas dão ao grupo uma base rastreável para discutir a
identidade do projeto e separar pesquisa de decisão aprovada.

**Independent Test**: O grupo revisa as referências registradas e consegue localizar a fonte e a
justificativa de relevância de cada item, sem depender de contexto verbal não registrado.

**Acceptance Scenarios**:

1. **Given** uma referência de jogo ou estilo visual selecionada para pesquisa, **When** ela é
   registrada, **Then** a entrada identifica a referência, aponta uma fonte rastreável e explica
   sua relevância para GESTIX.
2. **Given** uma referência que está sendo considerada, **When** o grupo consulta o registro,
   **Then** a referência de pesquisa pode ser distinguida de uma decisão de estilo aprovada.
3. **Given** uma entrada que combina informação da fonte e interpretação do grupo, **When** ela é
   revisada, **Then** o leitor consegue distinguir a informação citada da interpretação.

---

### User Story 2 - Revisar a base narrativa em desenvolvimento (Priority: P2)

Como integrante do grupo, quero consultar uma organização da premissa, do universo e dos elementos
narrativos presentes no material atual, com suas fontes e estados, para saber o que está aprovado,
o que ainda é provisório e o que permanece pendente.

**Why this priority**: A separação explícita de estados evita que rascunhos sejam tratados como
roteiro ou cânone definitivo nas próximas etapas.

**Independent Test**: Um integrante que não participou da redação consulta a base narrativa e
consegue identificar a fonte e o estado de cada elemento documentado.

**Acceptance Scenarios**:

1. **Given** o documento de história em desenvolvimento, **When** um elemento narrativo é incluído
   na base, **Then** seu registro identifica a fonte e o marca como aprovado, provisório ou pendente.
2. **Given** um trecho identificado pela fonte como proposta ou ainda sujeito a mudanças, **When**
   ele é registrado, **Then** continua identificado como provisório ou pendente, salvo evidência
   registrada de aprovação do grupo.
3. **Given** que o documento descreve a motivação do Maestro como proposta complementar, **When**
   esse elemento é incluído, **Then** permanece provisório ou pendente enquanto não houver aprovação
   explícita registrada pelo grupo.

---

### User Story 3 - Identificar decisões abertas (Priority: P3)

Como integrante do grupo, quero consultar as questões ainda não decididas sobre referências e
narrativa, para que o grupo possa revisá-las sem confundi-las com definições já aprovadas.

**Why this priority**: Tornar explícitas as pendências orienta discussões criativas futuras. Esta pesquisa não é pré-requisito nem bloqueio das fases técnicas do jogo.

**Independent Test**: O grupo revisa a lista de pendências e consegue distinguir cada questão aberta
dos registros aprovados e provisórios.

**Acceptance Scenarios**:

1. **Given** uma decisão narrativa ou de referência sem aprovação registrada, **When** a base é
   revisada, **Then** a questão aparece como pendente ou provisória, junto do contexto disponível.
2. **Given** a base de pesquisa organizada, **When** a equipe consultar referências em uma discussão criativa, **Then** consegue distinguir registros aprovados, provisórios e pendentes sem tratá-los como requisitos de gameplay.
3. **Given** a revisão do escopo da Spec 001, **When** o grupo consultar a documentação, **Then** identifica que a feature registra pesquisa como apoio criativo opcional e não implementa o jogo.

### Edge Cases

- Uma fonte consultada está indisponível ou não permite verificar a informação; o registro não
  apresenta como fato confirmado uma informação que não foi possível verificar.
- Fontes ou trechos apresentam versões conflitantes; a divergência é registrada como pendência,
  sem resolução inventada nesta feature.
- O material narrativo contém uma ideia descrita como proposta; ela permanece provisória ou pendente
  até que uma aprovação do grupo esteja registrada.
- Uma entrada não possui fonte ou justificativa de relevância suficiente; ela não é apresentada
  como referência pesquisada completa.
- Um integrante sugere personagem, estilo ou acontecimento ainda não decidido; a sugestão não é
  incorporada como fato aprovado.

## Requirements *(mandatory)*

### Functional Requirements

- **FR-001**: A documentação MUST registrar referências de jogos e estilos visuais selecionadas
  para pesquisa sobre GESTIX.
- **FR-002**: Cada referência registrada MUST identificar a obra ou o material, fornecer uma fonte
  rastreável e explicar sua relevância para a discussão de GESTIX.
- **FR-003**: O registro MUST distinguir informação atribuída à fonte, interpretação do grupo e
  decisão aprovada, quando esses elementos forem apresentados.
- **FR-004**: A base narrativa MUST organizar a premissa, o universo e os elementos narrativos do
  material atual que forem incluídos para consulta do grupo, preservando a origem de cada informação.
- **FR-005**: Cada elemento narrativo incluído MUST receber um estado explícito: aprovado, provisório
  ou pendente.
- **FR-006**: Um elemento MUST ser marcado como aprovado somente quando houver confirmação explícita
  do grupo registrada em material consultável. A ausência de evidência de aprovação MUST manter o
  elemento como provisório ou pendente.
- **FR-007**: Propostas e conteúdos sujeitos a mudança no documento de história MUST permanecer
  identificados como provisórios ou pendentes; esta feature MUST NOT convertê-los em requisitos
  narrativos definitivos.
- **FR-008**: A documentação MUST manter uma relação consultável das decisões pendentes e do contexto
  disponível para revisá-las, sem inventar respostas, responsáveis ou prazos.
- **FR-009**: A documentação MUST permitir que o grupo consulte as fontes, a relevância das referências
  e o estado de aprovação dos elementos narrativos sem depender de explicações orais não registradas.
- **FR-010**: O escopo MUST limitar-se à pesquisa e à documentação da base narrativa e de referências.
  Conceitos visuais e assets podem ser tratados em trabalho criativo separado; esta feature não implementa funcionalidades nem é pré-requisito de gameplay.

### Key Entities *(include if data involved)*

- **Referência de pesquisa**: Jogo, estilo visual ou material consultado, com fonte rastreável,
  relevância para GESTIX e distinção entre descrição da fonte e interpretação do grupo.
- **Elemento narrativo**: Premissa, aspecto do universo ou elemento da história registrado com
  indicação de fonte e estado de aprovação.
- **Estado de aprovação**: Classificação do registro como aprovado, provisório ou pendente, conforme
  a existência de confirmação explícita do grupo.
- **Decisão pendente**: Questão ainda não decidida, com o contexto disponível para discussão pelo
  grupo, sem resposta presumida.

## Success Criteria *(mandatory)*

### Measurable Outcomes

- **SC-001**: 100% das referências incluídas na documentação possuem fonte rastreável e explicação
  explícita de sua relevância para GESTIX.
- **SC-002**: 100% dos elementos narrativos incluídos possuem fonte identificada e estado de
  aprovação explícito.
- **SC-003**: 100% dos elementos marcados como aprovados possuem confirmação explícita do grupo
  registrada em material consultável.
- **SC-004**: Todo conteúdo narrativo sem confirmação registrada permanece identificado como
  provisório ou pendente, e nenhuma proposta do material em desenvolvimento é apresentada como
  decisão definitiva.
- **SC-005**: Um integrante do grupo que não participou da organização consegue distinguir referências
  de pesquisa, conteúdo narrativo aprovado, propostas provisórias e decisões pendentes consultando
  apenas a documentação produzida nesta feature.

## Assumptions

- O grupo é a autoridade para aprovar decisões narrativas e de referência no escopo desta feature;
  uma aprovação só será considerada registrada quando houver evidência consultável.
- O documento “GESTIX — O Mundo Além da Melodia: História em desenvolvimento” é material de
  referência em elaboração, não roteiro definitivo; elementos explicitamente indicados como propostas
  ou sujeitos a mudanças não são tratados como aprovados sem confirmação adicional do grupo.
- Não há quantidade mínima de jogos ou estilos visuais aprovada para a pesquisa. A documentação
  registrará os itens que o grupo selecionar e não alegará ser uma pesquisa exaustiva.
- As Specs técnicas do jogo, incluindo `specs/002-reconhecimento-gestos/`, são independentes desta base. A equipe pode consultá-la para contexto criativo, mas seu conteúdo não bloqueia implementação nem altera requisitos funcionais.
- O documento de história fornecido está fora da árvore atual do repositório. Esta feature não decide
  onde armazenar uma cópia permanente; a fonte deverá permanecer identificável e acessível durante
  a pesquisa e a revisão.

## Relação com o backlog de gameplay

Esta pesquisa pode apoiar decisões criativas, mas o jogo Gestix deve inicializar e operar sem narrativa, história de personagens ou introdução cinematográfica. Ela não corresponde a um backlog funcional e não bloqueia as fases registradas em `backlog/README.md`.
