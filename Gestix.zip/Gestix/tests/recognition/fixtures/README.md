# Recognition fixtures

Fixtures in this directory must contain only approved processed/synthetic
landmark data and labels. Do not store camera frames or identifiable data here.
The upstream schema and gesture criteria are pending, so no gesture fixtures
are supplied yet.
