import unittest

from gestix.recognition.consistency_check import OpenAIConfig, OpenAIConsistencyVerifier
from gestix.recognition.result import RecognitionResult, RecognitionStatus
from gestix.recognition.session import RecognitionSession


class SessionTests(unittest.TestCase):
    def test_disabled_verifier_never_publishes_candidate(self):
        classifier = lambda sample: RecognitionResult(RecognitionStatus.RECOGNIZED,
                                                       "HORIZONTAL_CUT", 0.9)
        session = RecognitionSession(classifier, OpenAIConsistencyVerifier())
        result = session.process([0.1, 0.2])
        self.assertEqual(result.status, RecognitionStatus.UNAVAILABLE)
        self.assertIsNone(result.gesture_id)

    def test_consistency_is_required_for_recognized(self):
        classifier = lambda sample: RecognitionResult(RecognitionStatus.RECOGNIZED,
                                                       "HORIZONTAL_CUT", 0.9)
        config = dict(enabled=True, transmission_approved=True, payload_approved=True,
                      api_key="secret", model="model", api_url="unused", timeout_seconds=1)
        verifier = OpenAIConsistencyVerifier(
            OpenAIConfig(**config),
            payload_builder=lambda gesture, data: {"input": data},
            response_parser=lambda response: response,
            transport=lambda *args: "consistent")
        result = RecognitionSession(classifier, verifier).process([0.1])
        self.assertEqual(result.status, RecognitionStatus.RECOGNIZED)
        self.assertEqual(result.gesture_id, "HORIZONTAL_CUT")

    def test_invalid_input_returns_non_actionable_result(self):
        result = RecognitionSession(lambda _: self.fail("classifier must not run"),
                                    OpenAIConsistencyVerifier()).process(None)
        self.assertEqual(result.status, RecognitionStatus.NOT_RECOGNIZED)
        self.assertIsNone(result.gesture_id)

    def test_invalid_classifier_output_fails_closed(self):
        result = RecognitionSession(lambda _: object(), OpenAIConsistencyVerifier()).process([1])
        self.assertEqual(result.status, RecognitionStatus.UNAVAILABLE)
        self.assertIsNone(result.gesture_id)


if __name__ == "__main__":
    unittest.main()
