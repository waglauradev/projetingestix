import unittest

from gestix.recognition.consistency_check import (
    OpenAIConfig, OpenAIConsistencyVerifier,
)


class ConsistencyCheckTests(unittest.TestCase):
    def test_default_disabled_never_calls_transport(self):
        called = []
        verifier = OpenAIConsistencyVerifier(transport=lambda *args: called.append(args))
        self.assertEqual(verifier.verify("G", "sample").status, "unavailable")
        self.assertEqual(called, [])

    def configured(self, transport, parser=lambda response: response):
        config = OpenAIConfig(True, True, True, "secret", "test-model",
                              "https://invalid.example/unused", 0.25)
        return OpenAIConsistencyVerifier(
            config, payload_builder=lambda gesture, data: {"input": data},
            response_parser=parser, transport=transport)

    def test_fake_transport_consistent_and_inconsistent(self):
        transport = lambda key, payload, timeout: self.assertEqual(key, "secret") or "consistent"
        self.assertEqual(self.configured(transport).verify("G", "x").status, "consistent")
        self.assertEqual(self.configured(lambda *args: "inconsistent").verify("G", "x").status,
                         "inconsistent")

    def test_fake_transport_timeout_and_invalid_response_fail_closed(self):
        def timeout(*args):
            raise TimeoutError()
        self.assertEqual(self.configured(timeout).verify("G", "x").status, "unavailable")
        self.assertEqual(self.configured(lambda *args: "maybe").verify("G", "x").status,
                         "unavailable")
        self.assertEqual(self.configured(lambda *args: None).verify("G", "x").status,
                         "unavailable")

    def test_config_requires_each_explicit_approval(self):
        config = OpenAIConfig(True, True, False, "secret", "model", "url", 1)
        self.assertFalse(config.ready)


if __name__ == "__main__":
    unittest.main()
