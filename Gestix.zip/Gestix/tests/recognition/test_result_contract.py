import unittest
import math

from gestix.recognition.result import RecognitionResult, RecognitionStatus


class ResultContractTests(unittest.TestCase):
    def test_recognized_requires_identifier(self):
        with self.assertRaises(ValueError):
            RecognitionResult(RecognitionStatus.RECOGNIZED)

    def test_non_actionable_states_cannot_have_identifier(self):
        for status in (RecognitionStatus.NOT_RECOGNIZED, RecognitionStatus.UNAVAILABLE):
            with self.subTest(status=status), self.assertRaises(ValueError):
                RecognitionResult(status, gesture_id="HORIZONTAL_CUT")

    def test_confidence_must_be_finite_without_assuming_a_scale(self):
        with self.assertRaises(ValueError):
            RecognitionResult(RecognitionStatus.RECOGNIZED, "HORIZONTAL_CUT", math.nan)


if __name__ == "__main__":
    unittest.main()
