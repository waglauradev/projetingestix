"""Recognition package tests."""
