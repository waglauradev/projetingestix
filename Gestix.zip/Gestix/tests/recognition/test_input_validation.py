import math
import unittest

from gestix.recognition.input_validation import validate_processed_input


class InputValidationTests(unittest.TestCase):
    def test_accepts_finite_numeric_sequence(self):
        self.assertTrue(validate_processed_input([0, 0.5, -1]).valid)

    def test_rejects_empty_and_non_finite(self):
        self.assertEqual(validate_processed_input([]).reason_code, "insufficient_data")
        self.assertEqual(validate_processed_input([math.nan]).reason_code, "invalid_input")

    def test_rejects_wrong_types_and_null(self):
        for sample in (None, {}, "data", [True], [object()]):
            with self.subTest(sample=sample):
                self.assertFalse(validate_processed_input(sample).valid)


if __name__ == "__main__":
    unittest.main()
