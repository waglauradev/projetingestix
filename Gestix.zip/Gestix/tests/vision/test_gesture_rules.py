import unittest

from gestix.recognition.result import RecognitionStatus
from gestix.recognition.gesture_rules import GestureRuleClassifier
from gestix.vision.landmarks import HandObservation
from helpers import cut_sequence, make_palm, palm_sequence


def classify_sequence(classifier, samples):
    result = None
    for sample in samples:
        current = classifier(sample)
        if current.status is RecognitionStatus.RECOGNIZED:
            return current
        result = current
    return result


class GestureRulesTests(unittest.TestCase):
    def test_detects_sustained_forward_palm_for_both_hands(self):
        for side in ("Right", "Left"):
            result = classify_sequence(GestureRuleClassifier(), palm_sequence(side))
            self.assertEqual(result.status, RecognitionStatus.RECOGNIZED)
            self.assertEqual(result.gesture_id, "PALM_FORWARD")
            self.assertTrue(0.0 <= result.confidence <= 1.0)

    def test_detects_horizontal_cut_in_either_direction(self):
        for direction in (-1, 1):
            result = classify_sequence(GestureRuleClassifier(), cut_sequence(direction=direction))
            self.assertEqual(result.status, RecognitionStatus.RECOGNIZED)
            self.assertEqual(result.gesture_id, "HORIZONTAL_CUT")

    def test_rejects_short_or_diagonal_motion(self):
        short = classify_sequence(GestureRuleClassifier(),
                                  cut_sequence(dx_per_frame=0.005, count=12))
        self.assertEqual(short.status, RecognitionStatus.NOT_RECOGNIZED)
        diagonal = [make_palm(offset_x=0.045 * i, timestamp=0.03 * i)
                    for i in range(12)]
        diagonal = [type(s)(tuple(v + (0.30 * i if j % 3 == 1 else 0.0)
                                  for j, v in enumerate(s.landmarks)),
                           s.handedness, s.timestamp_seconds)
                    for i, s in enumerate(diagonal)]
        self.assertNotEqual(classify_sequence(GestureRuleClassifier(), diagonal).gesture_id,
                            "HORIZONTAL_CUT")

    def test_rejects_wrong_palm_side_bent_finger_and_short_hold(self):
        right_facing_left = [HandObservation(sample.landmarks, "Left", sample.timestamp_seconds)
                             for sample in palm_sequence("Right", count=8)]
        self.assertNotEqual(classify_sequence(GestureRuleClassifier(), right_facing_left).gesture_id,
                            "PALM_FORWARD")

        bent = []
        for sample in palm_sequence(count=8):
            values = list(sample.landmarks)
            values[8 * 3:8 * 3 + 3] = values[6 * 3:6 * 3 + 3]
            bent.append(HandObservation(tuple(values), sample.handedness,
                                        sample.timestamp_seconds))
        self.assertNotEqual(classify_sequence(GestureRuleClassifier(), bent).gesture_id,
                            "PALM_FORWARD")

        short_hold = palm_sequence(count=5, step=0.01)
        self.assertNotEqual(classify_sequence(GestureRuleClassifier(), short_hold).gesture_id,
                            "PALM_FORWARD")

    def test_candidate_is_emitted_once_while_palm_remains_held(self):
        classifier = GestureRuleClassifier()
        result = classify_sequence(classifier, palm_sequence(count=5))
        self.assertEqual(result.gesture_id, "PALM_FORWARD")
        held = [make_palm(timestamp=0.15 + i * 0.03) for i in range(5)]
        result = classify_sequence(classifier, held)
        self.assertEqual(result.status, RecognitionStatus.NOT_RECOGNIZED)
        self.assertIsNone(result.gesture_id)

    def test_cut_latch_rearms_after_stable_window(self):
        classifier = GestureRuleClassifier()
        first = cut_sequence()
        outputs = [classifier(sample) for sample in first]
        self.assertTrue(any(item.gesture_id == "HORIZONTAL_CUT" for item in outputs))

        offset = 0.055 * (len(first) - 1)
        stable = [make_palm(offset_x=offset, timestamp=first[-1].timestamp_seconds + 0.03 * i)
                  for i in range(1, 7)]
        stable_outputs = [classifier(sample) for sample in stable]
        self.assertTrue(all(item.status is RecognitionStatus.NOT_RECOGNIZED
                            for item in stable_outputs))

        next_cut = [make_palm(offset_x=offset - 0.055 * i,
                              timestamp=stable[-1].timestamp_seconds + 0.03 * i)
                    for i in range(1, 8)]
        next_outputs = [classifier(sample) for sample in next_cut]
        self.assertTrue(any(item.gesture_id == "HORIZONTAL_CUT" for item in next_outputs))

    def test_missing_hand_resets_tracking(self):
        classifier = GestureRuleClassifier()
        classify_sequence(classifier, cut_sequence(count=5))
        result = classifier([])
        self.assertEqual(result.status, RecognitionStatus.NOT_RECOGNIZED)
        self.assertIsNone(result.gesture_id)


if __name__ == "__main__":
    unittest.main()
