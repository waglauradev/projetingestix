import math
import unittest
from types import SimpleNamespace

from gestix.vision.landmarks import LandmarkValidationError, make_hand_observation


class LandmarkTests(unittest.TestCase):
    def setUp(self):
        self.points = [SimpleNamespace(x=i / 21, y=i / 42, z=-i / 84)
                       for i in range(21)]

    def test_flattens_21_points_in_order_to_63_aspect_scaled_values(self):
        sample = make_hand_observation(self.points, "Right", 640, 480, 1.25)
        self.assertEqual(len(sample), 63)
        self.assertAlmostEqual(sample[0], 0.0)
        self.assertAlmostEqual(sample[3], (1 / 21) * (4 / 3))
        self.assertAlmostEqual(sample[5], -1 / 84 * (4 / 3))
        self.assertEqual(sample.handedness, "Right")
        self.assertEqual(sample.timestamp_seconds, 1.25)

    def test_rejects_wrong_count_dimensions_handedness_and_non_finite(self):
        with self.assertRaises(LandmarkValidationError):
            make_hand_observation(self.points[:-1], "Right", 640, 480, 1)
        with self.assertRaises(LandmarkValidationError):
            make_hand_observation(self.points, "Right", 0, 480, 1)
        with self.assertRaises(LandmarkValidationError):
            make_hand_observation(self.points, "Unknown", 640, 480, 1)
        bad = list(self.points)
        bad[3] = SimpleNamespace(x=math.nan, y=0.0, z=0.0)
        with self.assertRaises(LandmarkValidationError):
            make_hand_observation(bad, "Right", 640, 480, 1)


if __name__ == "__main__":
    unittest.main()
