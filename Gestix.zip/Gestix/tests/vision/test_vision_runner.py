import unittest

from gestix.recognition.consistency_check import OpenAIConfig, OpenAIConsistencyVerifier
from gestix.recognition.result import RecognitionStatus
from gestix.recognition.session import RecognitionSession
from gestix.recognition.gesture_rules import GestureRuleClassifier
from gestix.vision.runner import process_observation, render_hud, run_loop
from gestix.vision.mediapipe_camera import OpenCVMediapipeCamera
from helpers import make_palm, palm_sequence
from types import SimpleNamespace
from pathlib import Path
import tempfile


class FakeCV:
    FONT_HERSHEY_SIMPLEX = 0
    LINE_AA = 16
    COLOR_BGR2RGB = 1
    def __init__(self, keys=()):
        self.keys = iter(keys)
        self.text = []
        self.line_calls = []
        self.circle_calls = []
        self.destroyed = False
        self.shown = 0

    def putText(self, frame, text, *args):
        self.text.append(text)

    def imshow(self, name, frame):
        self.shown += 1

    def waitKey(self, delay):
        return next(self.keys, -1)

    def destroyAllWindows(self):
        self.destroyed = True

    def VideoCapture(self, index):
        return self.capture

    def flip(self, frame, direction):
        self.flipped = direction == 1
        return frame

    def cvtColor(self, frame, code):
        return frame

    def line(self, *args):
        self.line_calls.append(args)

    def circle(self, *args):
        self.circle_calls.append(args)


class FakeCapture:
    def __init__(self, observations):
        self.observations = iter(observations)
        self.closed = False

    def read(self):
        return SimpleNamespace(frame=object(), observation=next(self.observations), timestamp_ms=1)

    def close(self):
        self.closed = True


class FakeVideoFrame:
    shape = (480, 640, 3)


class FakeCVModule(FakeCV):
    def __init__(self, capture, keys=()):
        super().__init__(keys)
        self.capture = capture
        self.flipped = False


class FakeDevice:
    def __init__(self, opened=True, reads=()):
        self.opened = opened
        self.reads = iter(reads)
        self.released = False

    def isOpened(self):
        return self.opened

    def read(self):
        return next(self.reads, (False, None))

    def release(self):
        self.released = True


class FakeMediaPipe:
    class ImageFormat:
        SRGB = 1

    class Image:
        def __init__(self, **kwargs):
            self.kwargs = kwargs

    class tasks:
        class BaseOptions:
            def __init__(self, model_asset_path):
                self.model_asset_path = model_asset_path

        class vision:
            class RunningMode:
                VIDEO = "VIDEO"

            class HandLandmarkerOptions:
                def __init__(self, **kwargs):
                    self.kwargs = kwargs

            class HandLandmarker:
                instance = None

                @classmethod
                def create_from_options(cls, options):
                    cls.instance = cls()
                    return cls.instance

                def detect_for_video(self, image, timestamp_ms):
                    sample = make_palm(timestamp=timestamp_ms / 1000.0)
                    points = [SimpleNamespace(x=sample[i] * 0.75,
                                               y=sample[i + 1],
                                               z=sample[i + 2] * 0.75)
                              for i in range(0, 63, 3)]
                    return SimpleNamespace(
                        hand_landmarks=[points],
                        handedness=[[SimpleNamespace(category_name="Right")]],
                    )

                def close(self):
                    self.closed = True


class VisionRunnerTests(unittest.TestCase):
    def make_session(self):
        classifier = GestureRuleClassifier()
        verifier = OpenAIConsistencyVerifier(OpenAIConfig())
        return classifier, RecognitionSession(classifier, verifier)

    def test_offline_candidate_does_not_replace_official_unavailable(self):
        official_classifier, session = self.make_session()
        preview_classifier = GestureRuleClassifier()
        candidate = official = None
        for sample in palm_sequence(count=5):
            current_candidate, official = process_observation(
                sample, preview_classifier, official_classifier, session)
            if current_candidate.status is RecognitionStatus.RECOGNIZED:
                candidate = current_candidate
        self.assertEqual(candidate.gesture_id, "PALM_FORWARD")
        self.assertEqual(candidate.status, RecognitionStatus.RECOGNIZED)
        self.assertEqual(official.status, RecognitionStatus.UNAVAILABLE)
        self.assertIsNone(official.gesture_id)

    def test_no_hand_stays_not_recognized(self):
        official_classifier, session = self.make_session()
        candidate, official = process_observation(
            None, GestureRuleClassifier(), official_classifier, session)
        self.assertEqual(candidate.status, RecognitionStatus.NOT_RECOGNIZED)
        self.assertEqual(official.status, RecognitionStatus.NOT_RECOGNIZED)
        self.assertIsNone(official.gesture_id)

    def test_hud_shows_separate_candidate_official_status_confidence_and_fps(self):
        cv = FakeCV()
        preview = GestureRuleClassifier()
        preview_result = None
        for item in palm_sequence(count=5):
            preview_result = preview.preview(item)
        official_classifier, session = self.make_session()
        for item in palm_sequence(count=5):
            official = session.process(item)
        render_hud(cv, object(), official, preview_result, 24.5)
        self.assertTrue(any("UNAVAILABLE" in line for line in cv.text))
        self.assertTrue(any("PALM_FORWARD" in line for line in cv.text))
        self.assertTrue(any("24.5" in line for line in cv.text))

    def test_q_closes_capture_and_windows(self):
        cv = FakeCV(keys=[ord("q")])
        capture = FakeCapture([None])
        official_classifier, session = self.make_session()
        run_loop(capture, session, GestureRuleClassifier(), official_classifier, cv,
                 max_frames=3)
        self.assertTrue(capture.closed)
        self.assertTrue(cv.destroyed)
        self.assertEqual(cv.shown, 1)

    def test_camera_adapter_mirrors_draws_and_converts_without_hardware(self):
        capture = FakeDevice(reads=[(True, FakeVideoFrame())])
        cv = FakeCVModule(capture)
        with tempfile.NamedTemporaryFile() as asset:
            camera = OpenCVMediapipeCamera(0, Path(asset.name), cv_module=cv,
                                             mediapipe_module=FakeMediaPipe)
            try:
                item = camera.read()
                self.assertTrue(cv.flipped)
                self.assertEqual(len(item.observation), 63)
                self.assertEqual(len(cv.circle_calls), 21)
                self.assertGreaterEqual(len(cv.line_calls), 20)
            finally:
                camera.close()
            self.assertTrue(FakeMediaPipe.tasks.vision.HandLandmarker.instance.closed)
        self.assertTrue(capture.released)

    def test_camera_open_failure_releases_device(self):
        from gestix.vision.mediapipe_camera import VisionSetupError

        capture = FakeDevice(opened=False)
        cv = FakeCVModule(capture)
        with tempfile.NamedTemporaryFile() as asset:
            with self.assertRaises(VisionSetupError):
                OpenCVMediapipeCamera(9, Path(asset.name), cv_module=cv,
                                       mediapipe_module=FakeMediaPipe)
        self.assertTrue(capture.released)


if __name__ == "__main__":
    unittest.main()
