from gestix.vision.landmarks import HandObservation


def make_palm(handedness: str = "Right", offset_x: float = 0.0,
              timestamp: float = 0.0) -> HandObservation:
    """A deterministic open palm with landmarks in mirrored image coordinates."""
    points = [
        (0.50, 0.75, 0.00),  # wrist
        (0.58, 0.65, 0.00), (0.63, 0.62, 0.00), (0.69, 0.58, 0.00), (0.74, 0.54, 0.00),
        (0.58, 0.55, 0.00), (0.60, 0.43, 0.00), (0.61, 0.32, 0.00), (0.62, 0.20, 0.00),
        (0.54, 0.54, 0.00), (0.55, 0.41, 0.00), (0.56, 0.29, 0.00), (0.56, 0.17, 0.00),
        (0.47, 0.55, 0.00), (0.46, 0.44, 0.00), (0.45, 0.34, 0.00), (0.44, 0.24, 0.00),
        (0.42, 0.57, 0.00), (0.39, 0.48, 0.00), (0.36, 0.40, 0.00), (0.33, 0.33, 0.00),
    ]
    if handedness == "Left":
        points = [(1.0 - x, y, z) for x, y, z in points]
    values = tuple(value for x, y, z in points
                   for value in (x + offset_x, y, z))
    return HandObservation(values, handedness, timestamp)


def palm_sequence(handedness: str = "Right", count: int = 8,
                  step: float = 0.03) -> list[HandObservation]:
    return [make_palm(handedness, timestamp=i * step) for i in range(count)]


def cut_sequence(count: int = 12, dx_per_frame: float = 0.055,
                 step: float = 0.03, direction: int = 1,
                 start_offset: float = 0.0) -> list[HandObservation]:
    return [make_palm("Right", offset_x=start_offset + direction * dx_per_frame * i,
                      timestamp=i * step) for i in range(count)]
