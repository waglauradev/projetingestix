# Synthetic vision fixtures

Geometry fixtures are generated programmatically in `helpers.py` so the repository contains no webcam frames or image data. Add only synthetic numeric landmarks unless a separate approved requirement explicitly defines data handling.
