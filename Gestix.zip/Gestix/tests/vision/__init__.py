"""Tests for the isolated webcam preview feature."""
