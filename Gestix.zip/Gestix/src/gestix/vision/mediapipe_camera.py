"""Local OpenCV capture and current MediaPipe Tasks Hand Landmarker adapter."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import importlib
import time
from typing import Any

from .landmarks import HandObservation, LandmarkValidationError, make_hand_observation


class VisionSetupError(RuntimeError):
    """Missing dependency, model asset, or camera device."""


class CameraReadError(RuntimeError):
    """Camera stopped producing a valid frame."""


@dataclass(frozen=True, slots=True)
class VisionFrame:
    frame: Any
    observation: HandObservation | None
    timestamp_ms: int


# Hand Landmarker's 21 point connections; indices follow the official map.
HAND_CONNECTIONS: tuple[tuple[int, int], ...] = (
    (0, 1), (1, 2), (2, 3), (3, 4),
    (0, 5), (5, 6), (6, 7), (7, 8),
    (5, 9), (9, 10), (10, 11), (11, 12),
    (9, 13), (13, 14), (14, 15), (15, 16),
    (13, 17), (17, 18), (18, 19), (19, 20),
    (0, 17),
)


class OpenCVMediapipeCamera:
    def __init__(self, camera_index: int, model_path: Path,
                 *, cv_module: Any | None = None,
                 mediapipe_module: Any | None = None) -> None:
        if not model_path.is_file():
            raise VisionSetupError(f"MediaPipe task asset not found: {model_path}")
        try:
            self._cv = cv_module or importlib.import_module("cv2")
            self._mp = mediapipe_module or importlib.import_module("mediapipe")
        except ImportError as exc:
            raise VisionSetupError(
                "Install opencv-python and mediapipe from requirements-vision.txt") from exc

        self._capture = self._cv.VideoCapture(camera_index)
        if not self._capture.isOpened():
            self._capture.release()
            raise VisionSetupError(f"Unable to open camera index {camera_index}")
        try:
            options = self._mp.tasks.vision.HandLandmarkerOptions(
                base_options=self._mp.tasks.BaseOptions(model_asset_path=str(model_path)),
                running_mode=self._mp.tasks.vision.RunningMode.VIDEO,
                num_hands=1,
                min_hand_detection_confidence=0.5,
                min_hand_presence_confidence=0.5,
                min_tracking_confidence=0.5,
            )
            self._landmarker = self._mp.tasks.vision.HandLandmarker.create_from_options(options)
        except Exception as exc:
            self._capture.release()
            raise VisionSetupError("Could not initialize MediaPipe Hand Landmarker") from exc
        self._last_timestamp_ms = -1
        self._closed = False

    def read(self) -> VisionFrame:
        if self._closed:
            raise CameraReadError("camera is closed")
        ok, frame = self._capture.read()
        if not ok or frame is None:
            raise CameraReadError("camera frame read failed")
        try:
            height, width = frame.shape[:2]
        except (AttributeError, TypeError, ValueError) as exc:
            raise CameraReadError("camera returned an invalid frame") from exc
        if width <= 0 or height <= 0:
            raise CameraReadError("camera returned an empty frame")

        mirrored = self._cv.flip(frame, 1)
        rgb = self._cv.cvtColor(mirrored, self._cv.COLOR_BGR2RGB)
        image = self._mp.Image(image_format=self._mp.ImageFormat.SRGB, data=rgb)
        timestamp_ms = max(self._last_timestamp_ms + 1, time.monotonic_ns() // 1_000_000)
        self._last_timestamp_ms = timestamp_ms
        result = self._landmarker.detect_for_video(image, timestamp_ms)
        self._draw_landmarks(mirrored, result.hand_landmarks)

        observation = None
        if result.hand_landmarks:
            landmarks = result.hand_landmarks[0]
            try:
                handedness = result.handedness[0][0].category_name
                observation = make_hand_observation(
                    landmarks, handedness, width, height, timestamp_ms / 1000.0)
            except (IndexError, AttributeError, LandmarkValidationError):
                observation = None
        return VisionFrame(mirrored, observation, timestamp_ms)

    def _draw_landmarks(self, frame: Any, hands: list[list[Any]]) -> None:
        height, width = frame.shape[:2]
        for hand in hands:
            pixels = [
                (max(0, min(width - 1, round(point.x * width))),
                 max(0, min(height - 1, round(point.y * height))))
                for point in hand
            ]
            for first, second in HAND_CONNECTIONS:
                self._cv.line(frame, pixels[first], pixels[second], (80, 220, 80), 2)
            for x, y in pixels:
                self._cv.circle(frame, (x, y), 4, (40, 80, 255), -1)

    def close(self) -> None:
        if self._closed:
            return
        self._closed = True
        try:
            self._landmarker.close()
        finally:
            self._capture.release()

    def __enter__(self) -> "OpenCVMediapipeCamera":
        return self

    def __exit__(self, exc_type: Any, exc: Any, traceback: Any) -> None:
        self.close()
