"""Optional vision adapters for local Gestix gesture preview."""
