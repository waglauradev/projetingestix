"""Pure MediaPipe landmark conversion; imports neither OpenCV nor MediaPipe."""

from __future__ import annotations

from dataclasses import dataclass
import math
from typing import Iterable, Iterator, overload


class LandmarkValidationError(ValueError):
    """Raised when a Hand Landmarker result cannot form a valid sample."""


@dataclass(frozen=True, slots=True)
class HandObservation:
    """63-value iterable consumed by the existing RecognitionSession."""

    landmarks: tuple[float, ...]
    handedness: str
    timestamp_seconds: float

    def __post_init__(self) -> None:
        if len(self.landmarks) != 63:
            raise LandmarkValidationError("a hand observation requires 21 xyz landmarks")
        if self.handedness not in {"Left", "Right"}:
            raise LandmarkValidationError("handedness must be Left or Right")
        if not math.isfinite(self.timestamp_seconds):
            raise LandmarkValidationError("timestamp must be finite")
        if any(not math.isfinite(value) for value in self.landmarks):
            raise LandmarkValidationError("landmark values must be finite")

    def __iter__(self) -> Iterator[float]:
        return iter(self.landmarks)

    def __len__(self) -> int:
        return len(self.landmarks)

    @overload
    def __getitem__(self, index: int) -> float: ...

    @overload
    def __getitem__(self, index: slice) -> tuple[float, ...]: ...

    def __getitem__(self, index: int | slice) -> float | tuple[float, ...]:
        return self.landmarks[index]


def flatten_landmarks(landmarks: Iterable[object], width: int,
                      height: int) -> tuple[float, ...]:
    """Convert 21 MediaPipe image landmarks to 63 aspect-corrected floats.

    x and z are scaled by width/height so their units match the normalized y
    coordinate for geometry computed in the mirrored frame.
    """
    if width <= 0 or height <= 0:
        raise LandmarkValidationError("frame dimensions must be positive")
    try:
        points = list(landmarks)
    except TypeError as exc:
        raise LandmarkValidationError("landmarks must be iterable") from exc
    if len(points) != 21:
        raise LandmarkValidationError("expected exactly 21 landmarks")

    aspect = width / height
    values: list[float] = []
    for point in points:
        try:
            x, y, z = (float(getattr(point, axis)) for axis in ("x", "y", "z"))
        except (AttributeError, TypeError, ValueError) as exc:
            raise LandmarkValidationError("each landmark must contain numeric x, y, z") from exc
        if not all(math.isfinite(value) for value in (x, y, z)):
            raise LandmarkValidationError("landmark values must be finite")
        values.extend((x * aspect, y, z * aspect))
    return tuple(values)


def make_hand_observation(landmarks: Iterable[object], handedness: str,
                          width: int, height: int,
                          timestamp_seconds: float) -> HandObservation:
    return HandObservation(
        flatten_landmarks(landmarks, width, height), handedness, timestamp_seconds)
