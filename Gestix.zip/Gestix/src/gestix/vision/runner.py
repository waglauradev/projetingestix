"""Local webcam preview; never promotes its visual candidate to session output."""

from __future__ import annotations

import argparse
from pathlib import Path
import importlib
import sys
import time
from typing import Any

from gestix.recognition.consistency_check import OpenAIConfig, OpenAIConsistencyVerifier
from gestix.recognition.gesture_rules import GestureRuleClassifier
from gestix.recognition.result import RecognitionResult
from gestix.recognition.session import RecognitionSession
from .mediapipe_camera import CameraReadError, OpenCVMediapipeCamera, VisionSetupError


WINDOW_NAME = "Gestix - Gesture Preview"


def process_observation(observation: Any | None,
                        preview_classifier: GestureRuleClassifier,
                        official_classifier: GestureRuleClassifier,
                        session: RecognitionSession
                        ) -> tuple[RecognitionResult, RecognitionResult]:
    if observation is None:
        preview_classifier.reset()
        official_classifier.reset()
        return (RecognitionResult.not_recognized("tracking_lost"),
                session.process([]))
    preview = preview_classifier.preview(observation)
    official = session.process(observation)
    return preview, official


def render_hud(cv_module: Any, frame: Any, official: RecognitionResult,
               preview: RecognitionResult, fps: float) -> None:
    official_value = official.gesture_id or official.reason_code or "-"
    preview_value = preview.gesture_id or preview.reason_code or "-"
    confidence = (f"{preview.confidence:.2f}" if preview.confidence is not None else "-")
    lines = (
        f"OFFICIAL: {official.status.value.upper()} | {official_value}",
        f"PREVIEW: {preview.status.value.upper()} | {preview_value}",
        f"CANDIDATE SCORE (heuristic): {confidence}",
        f"FPS: {fps:.1f} | q: quit",
    )
    y = 28
    for line in lines:
        cv_module.putText(frame, line, (12, y), cv_module.FONT_HERSHEY_SIMPLEX,
                          0.62, (255, 255, 255), 2, cv_module.LINE_AA)
        y += 27


def run_loop(capture: Any, session: RecognitionSession,
             preview_classifier: GestureRuleClassifier,
             official_classifier: GestureRuleClassifier,
             cv_module: Any, *, max_frames: int | None = None) -> RecognitionResult:
    previous = time.monotonic()
    frame_count = 0
    latest_official = RecognitionResult.unavailable("starting")
    last_visible_candidate: RecognitionResult | None = None
    last_candidate_time: float | None = None
    try:
        while max_frames is None or frame_count < max_frames:
            item = capture.read()
            preview, latest_official = process_observation(
                item.observation, preview_classifier, official_classifier, session)
            now = time.monotonic()
            if preview.status.value == "recognized":
                last_visible_candidate = preview
                last_candidate_time = now
            elif (last_visible_candidate is not None and last_candidate_time is not None
                  and now - last_candidate_time <= 0.60):
                preview = last_visible_candidate
            else:
                last_visible_candidate = None
                last_candidate_time = None
            fps = 1.0 / (now - previous) if now > previous else 0.0
            previous = now
            render_hud(cv_module, item.frame, latest_official, preview, fps)
            cv_module.imshow(WINDOW_NAME, item.frame)
            frame_count += 1
            if cv_module.waitKey(1) & 0xFF == ord("q"):
                break
    except CameraReadError as exc:
        latest_official = RecognitionResult.unavailable("camera_unavailable")
        print(f"UNAVAILABLE: {exc}", file=sys.stderr)
    except Exception as exc:
        latest_official = RecognitionResult.unavailable("vision_runtime_error")
        print(f"UNAVAILABLE: vision runtime error ({type(exc).__name__})", file=sys.stderr)
    finally:
        try:
            capture.close()
        except Exception:
            pass
        try:
            cv_module.destroyAllWindows()
        except Exception:
            pass
    return latest_official


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Gestix webcam gesture preview")
    parser.add_argument("--camera", type=int, default=0, help="OpenCV camera index")
    parser.add_argument("--model", type=Path,
                        default=Path("models/hand_landmarker.task"),
                        help="MediaPipe Hand Landmarker task asset")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        cv_module = importlib.import_module("cv2")
        capture = OpenCVMediapipeCamera(args.camera, args.model, cv_module=cv_module)
    except (ImportError, VisionSetupError) as exc:
        print(f"UNAVAILABLE: {exc}", file=sys.stderr)
        return 2

    official_classifier = GestureRuleClassifier()
    preview_classifier = GestureRuleClassifier()
    verifier = OpenAIConsistencyVerifier(OpenAIConfig.from_env())
    session = RecognitionSession(official_classifier, verifier)
    run_loop(capture, session, preview_classifier, official_classifier, cv_module)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
