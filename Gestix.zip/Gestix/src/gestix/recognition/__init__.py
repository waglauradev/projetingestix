"""Fail-safe gesture recognition boundaries for Gestix."""

from .result import RecognitionResult, RecognitionStatus

__all__ = ["RecognitionResult", "RecognitionStatus"]
