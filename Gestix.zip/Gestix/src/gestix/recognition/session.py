"""Session orchestration. Gesture rules and segmentation are injected policies."""

from typing import Any, Callable

from .consistency_check import OpenAIConsistencyVerifier
from .input_validation import validate_processed_input
from .result import RecognitionResult, RecognitionStatus

Classifier = Callable[[Any], RecognitionResult]


class RecognitionSession:
    def __init__(self, classifier: Classifier | None,
                 verifier: OpenAIConsistencyVerifier | None) -> None:
        self._classifier = classifier
        self._verifier = verifier

    def process(self, sample: Any) -> RecognitionResult:
        if self._classifier is None or self._verifier is None:
            return RecognitionResult.unavailable("recognizer_unavailable")
        validation = validate_processed_input(sample)
        if not validation.valid:
            return RecognitionResult.not_recognized(validation.reason_code or "invalid_input")
        try:
            candidate = self._classifier(sample)
        except Exception:
            return RecognitionResult.unavailable("recognizer_unavailable")
        if not isinstance(candidate, RecognitionResult):
            return RecognitionResult.unavailable("invalid_classifier_result")
        if candidate.status is not RecognitionStatus.RECOGNIZED:
            return candidate
        check = self._verifier.verify(candidate.gesture_id or "", repr(sample))
        if check.status == "consistent":
            return candidate
        if check.status == "inconsistent":
            return RecognitionResult.not_recognized(check.reason_code or "llm_inconsistent")
        return RecognitionResult.unavailable(check.reason_code or "llm_unavailable")
