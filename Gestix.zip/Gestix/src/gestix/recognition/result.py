"""Logical recognition result contract; contains no Unity command fields."""

from dataclasses import dataclass
from enum import StrEnum
import math


class RecognitionStatus(StrEnum):
    RECOGNIZED = "recognized"
    NOT_RECOGNIZED = "not_recognized"
    UNAVAILABLE = "unavailable"


@dataclass(frozen=True, slots=True)
class RecognitionResult:
    status: RecognitionStatus
    gesture_id: str | None = None
    confidence: float | None = None
    reason_code: str | None = None

    def __post_init__(self) -> None:
        if self.status is RecognitionStatus.RECOGNIZED:
            if not self.gesture_id or not self.gesture_id.strip():
                raise ValueError("recognized results require a gesture_id")
        elif self.gesture_id is not None:
            raise ValueError("non-actionable results must not contain gesture_id")
        if self.confidence is not None and not math.isfinite(self.confidence):
            raise ValueError("confidence must be finite")

    @classmethod
    def not_recognized(cls, reason_code: str) -> "RecognitionResult":
        return cls(RecognitionStatus.NOT_RECOGNIZED, reason_code=reason_code)

    @classmethod
    def unavailable(cls, reason_code: str) -> "RecognitionResult":
        return cls(RecognitionStatus.UNAVAILABLE, reason_code=reason_code)
