"""Generic validation that does not assume the pending upstream schema."""

from dataclasses import dataclass
import math
from typing import Any


@dataclass(frozen=True, slots=True)
class InputValidation:
    valid: bool
    reason_code: str | None = None


def validate_processed_input(sample: Any) -> InputValidation:
    """Check basic structure and finite numeric values without reshaping data."""
    if sample is None:
        return InputValidation(False, "invalid_input")
    if isinstance(sample, (str, bytes, bytearray, dict)):
        return InputValidation(False, "invalid_input")
    try:
        values = list(sample)
    except (TypeError, ValueError):
        return InputValidation(False, "invalid_input")
    if not values:
        return InputValidation(False, "insufficient_data")
    for value in values:
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            return InputValidation(False, "invalid_input")
        if not math.isfinite(value):
            return InputValidation(False, "invalid_input")
    return InputValidation(True)
