"""Opt-in OpenAI API consistency verifier with injectable, testable transport.

No model, endpoint, payload, SDK, or response schema is selected here. Those
choices remain gated by project approvals. The default configuration can never
send a request.
"""

from dataclasses import dataclass, field
import json
import os
from typing import Any, Callable
from urllib.error import URLError
from urllib.request import Request, urlopen


@dataclass(frozen=True, slots=True)
class CheckResult:
    status: str  # consistent | inconsistent | unavailable
    reason_code: str | None = None


@dataclass(frozen=True, slots=True)
class OpenAIConfig:
    enabled: bool = False
    transmission_approved: bool = False
    payload_approved: bool = False
    api_key: str | None = field(default=None, repr=False)
    model: str | None = None
    api_url: str | None = None
    timeout_seconds: float | None = None

    @classmethod
    def from_env(cls) -> "OpenAIConfig":
        def flag(name: str) -> bool:
            return os.getenv(name, "").strip().lower() in {"1", "true", "yes"}

        timeout = os.getenv("OPENAI_TIMEOUT_SECONDS")
        try:
            parsed_timeout = float(timeout) if timeout else None
        except ValueError:
            parsed_timeout = None
        return cls(
            enabled=flag("GESTIX_OPENAI_ENABLED"),
            transmission_approved=flag("GESTIX_OPENAI_TRANSMISSION_APPROVED"),
            payload_approved=flag("GESTIX_OPENAI_PAYLOAD_APPROVED"),
            api_key=os.getenv("OPENAI_API_KEY"),
            model=os.getenv("OPENAI_MODEL"),
            api_url=os.getenv("OPENAI_API_URL"),
            timeout_seconds=parsed_timeout,
        )

    @property
    def ready(self) -> bool:
        return bool(
            self.enabled and self.transmission_approved and self.payload_approved
            and self.api_key and self.model and self.api_url
            and self.timeout_seconds is not None and self.timeout_seconds > 0
        )


Transport = Callable[[str, dict[str, Any], float], Any]
PayloadBuilder = Callable[[str, str], dict[str, Any]]
ResponseParser = Callable[[Any], str]


def _http_transport(api_key: str, payload: dict[str, Any], timeout: float,
                    api_url: str) -> Any:
    body = json.dumps(payload).encode("utf-8")
    request = Request(api_url, data=body, headers={
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
    })
    with urlopen(request, timeout=timeout) as response:
        return json.loads(response.read().decode("utf-8"))


class OpenAIConsistencyVerifier:
    def __init__(self, config: OpenAIConfig | None = None, *,
                 payload_builder: PayloadBuilder | None = None,
                 response_parser: ResponseParser | None = None,
                 transport: Transport | None = None) -> None:
        self._config = config or OpenAIConfig.from_env()
        self._payload_builder = payload_builder
        self._response_parser = response_parser
        self._transport = transport

    def verify(self, gesture_id: str, candidate_data: str) -> CheckResult:
        config = self._config
        if not config.ready or not all((self._payload_builder, self._response_parser)):
            return CheckResult("unavailable", "llm_unavailable")
        try:
            payload = self._payload_builder(gesture_id, candidate_data)  # type: ignore[misc]
            if not isinstance(payload, dict):
                return CheckResult("unavailable", "invalid_response")
            if "model" in payload and payload["model"] != config.model:
                return CheckResult("unavailable", "invalid_response")
            payload = {**payload, "model": config.model}
            if self._transport is None:
                response = _http_transport(config.api_key or "", payload,
                                           config.timeout_seconds or 0,
                                           config.api_url or "")
            else:
                response = self._transport(config.api_key or "", payload,
                                           config.timeout_seconds or 0)
            verdict = self._response_parser(response)  # type: ignore[misc]
            if verdict == "consistent":
                return CheckResult("consistent")
            if verdict == "inconsistent":
                return CheckResult("inconsistent", "llm_inconsistent")
            return CheckResult("unavailable", "invalid_response")
        except (TimeoutError, URLError):
            return CheckResult("unavailable", "llm_timeout")
        except Exception:
            # Never expose provider errors, response bodies, or secrets to callers.
            return CheckResult("unavailable", "llm_unavailable")
