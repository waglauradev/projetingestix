"""Pure geometric preview rules for the two approved Gestix gestures.

This module has no camera/UI/API dependencies. Scores indicate threshold margin,
not calibrated statistical probabilities. The rules implement gesture-rules-v1
in specs/003-webcam-gesture-preview/spec.md.
"""

from __future__ import annotations

from collections import deque
import math
import time
from typing import Any, Deque

from .result import RecognitionResult, RecognitionStatus


class GestureRuleClassifier:
    MIN_SAMPLES = 5
    PALM_HOLD_SECONDS = 0.12
    CUT_MIN_SECONDS = 0.10
    CUT_MAX_SECONDS = 0.55
    CUT_REARM_SECONDS = 0.15
    CUT_DISTANCE_WIDTHS = 1.25
    CUT_MAX_VERTICAL_WIDTHS = 0.60
    CUT_MAX_VERTICAL_PATH_WIDTHS = 0.90
    CUT_MIN_STRAIGHTNESS = 0.75
    CUT_MIN_DIRECTION_RATIO = 0.75
    FINGER_STRAIGHT_DEGREES = 155.0
    THUMB_GAP_WIDTHS = 0.45
    PALM_NORMAL_MIN_COS = math.cos(math.radians(40.0))

    def __init__(self) -> None:
        self._history: Deque[Any] = deque(maxlen=90)
        self._latched: str | None = None
        self._palm_release_count = 0

    def reset(self) -> None:
        self._history.clear()
        self._latched = None
        self._palm_release_count = 0

    def __call__(self, sample: Any) -> RecognitionResult:
        return self.preview(sample)

    def preview(self, sample: Any, timestamp_seconds: float | None = None) -> RecognitionResult:
        try:
            values = tuple(float(value) for value in sample)
        except (TypeError, ValueError):
            self.reset()
            return RecognitionResult.not_recognized("invalid_input")
        if len(values) != 63 or not all(math.isfinite(value) for value in values):
            self.reset()
            return RecognitionResult.not_recognized("invalid_input")

        timestamp = timestamp_seconds
        if timestamp is None:
            timestamp = getattr(sample, "timestamp_seconds", None)
        if timestamp is None:
            timestamp = time.monotonic()
        handedness = getattr(sample, "handedness", None)
        if handedness not in {"Left", "Right"} or not math.isfinite(timestamp):
            self.reset()
            return RecognitionResult.not_recognized("invalid_input")
        if self._history and timestamp <= self._timestamp(self._history[-1]):
            self.reset()

        self._history.append(sample)
        while len(self._history) > self.MIN_SAMPLES and (
            timestamp - self._timestamp(self._history[0]) > self.CUT_MAX_SECONDS
        ):
            self._history.popleft()

        if self._latched:
            if self._latched == "PALM_FORWARD":
                if self._palm_geometry(sample) is None:
                    self._palm_release_count += 1
                else:
                    self._palm_release_count = 0
                if self._palm_release_count < self.MIN_SAMPLES:
                    return RecognitionResult.not_recognized("gesture_latched")
                self._latched = None
                self._palm_release_count = 0
                self._history.clear()
                self._history.append(sample)
            elif self._stable_rearm():
                self._latched = None
                self._history.clear()
                self._history.append(sample)
            else:
                return RecognitionResult.not_recognized("gesture_latched")

        cut = self._cut_geometry()
        if cut is not None:
            self._latched = "HORIZONTAL_CUT"
            return RecognitionResult(RecognitionStatus.RECOGNIZED,
                                     "HORIZONTAL_CUT", cut)

        palm = self._sustained_palm()
        if palm is not None:
            self._latched = "PALM_FORWARD"
            return RecognitionResult(RecognitionStatus.RECOGNIZED,
                                     "PALM_FORWARD", palm)
        return RecognitionResult.not_recognized("unknown_gesture")

    @staticmethod
    def _coords(sample: Any) -> tuple[float, ...]:
        return tuple(sample)

    @classmethod
    def _point(cls, sample: Any, index: int) -> tuple[float, float, float]:
        values = cls._coords(sample)
        offset = index * 3
        return values[offset], values[offset + 1], values[offset + 2]

    @staticmethod
    def _timestamp(sample: Any) -> float:
        return float(getattr(sample, "timestamp_seconds", 0.0))

    @staticmethod
    def _distance2(a: tuple[float, ...], b: tuple[float, ...]) -> float:
        return math.hypot(a[0] - b[0], a[1] - b[1])

    @classmethod
    def _palm_width(cls, sample: Any) -> float:
        return cls._distance2(cls._point(sample, 5), cls._point(sample, 17))

    @staticmethod
    def _angle(a: tuple[float, ...], b: tuple[float, ...],
               c: tuple[float, ...]) -> float:
        first = tuple(a[i] - b[i] for i in range(3))
        second = tuple(c[i] - b[i] for i in range(3))
        norm_first = math.sqrt(sum(v * v for v in first))
        norm_second = math.sqrt(sum(v * v for v in second))
        if norm_first <= 1e-9 or norm_second <= 1e-9:
            return 0.0
        cosine = sum(first[i] * second[i] for i in range(3)) / (norm_first * norm_second)
        return math.degrees(math.acos(max(-1.0, min(1.0, cosine))))

    @classmethod
    def _palm_geometry(cls, sample: Any) -> float | None:
        handedness = getattr(sample, "handedness", None)
        if handedness not in {"Left", "Right"}:
            return None
        width = cls._palm_width(sample)
        if width <= 1e-6:
            return None
        fingers = ((5, 6, 8), (9, 10, 12), (13, 14, 16), (17, 18, 20))
        angles = [cls._angle(cls._point(sample, mcp), cls._point(sample, pip),
                             cls._point(sample, tip)) for mcp, pip, tip in fingers]
        if min(angles) < cls.FINGER_STRAIGHT_DEGREES:
            return None
        thumb_gap = cls._distance2(cls._point(sample, 4), cls._point(sample, 8))
        if thumb_gap < cls.THUMB_GAP_WIDTHS * width:
            return None

        wrist = cls._point(sample, 0)
        index_mcp = cls._point(sample, 5)
        pinky_mcp = cls._point(sample, 17)
        first = tuple(index_mcp[i] - wrist[i] for i in range(3))
        second = tuple(pinky_mcp[i] - wrist[i] for i in range(3))
        normal_z = first[0] * second[1] - first[1] * second[0]
        cross_x = first[1] * second[2] - first[2] * second[1]
        cross_y = first[2] * second[0] - first[0] * second[2]
        normal_length = math.sqrt(cross_x**2 + cross_y**2 + normal_z**2)
        if normal_length <= 1e-9:
            return None
        facing = normal_z / normal_length
        expected_sign = -1.0 if handedness == "Right" else 1.0
        signed_facing = facing * expected_sign
        if signed_facing < cls.PALM_NORMAL_MIN_COS:
            return None
        angle_margin = min(1.0, min(angles) / 180.0)
        thumb_margin = min(1.0, thumb_gap / (cls.THUMB_GAP_WIDTHS * width))
        orientation_margin = min(1.0, signed_facing)
        return max(0.0, min(angle_margin, thumb_margin, orientation_margin))

    def _sustained_palm(self) -> float | None:
        if len(self._history) < self.MIN_SAMPLES:
            return None
        samples = list(self._history)[-self.MIN_SAMPLES:]
        duration = self._timestamp(samples[-1]) - self._timestamp(samples[0])
        if duration < self.PALM_HOLD_SECONDS:
            return None
        scores = [self._palm_geometry(sample) for sample in samples]
        if any(score is None for score in scores):
            return None
        centers = [self._point(sample, 9) for sample in samples]
        width = self._palm_width(samples[-1])
        if width <= 1e-6 or max(self._distance2(center, centers[-1])
                                 for center in centers) > 0.15 * width:
            return None
        return min(float(score) for score in scores if score is not None)

    def _cut_geometry(self) -> float | None:
        samples = list(self._history)
        for start in range(len(samples) - self.MIN_SAMPLES + 1):
            window = samples[start:]
            if len(window) < self.MIN_SAMPLES:
                continue
            duration = self._timestamp(window[-1]) - self._timestamp(window[0])
            if not (self.CUT_MIN_SECONDS <= duration <= self.CUT_MAX_SECONDS):
                continue
            width = self._palm_width(window[0])
            if width <= 1e-6:
                continue
            centers = [self._point(sample, 9) for sample in window]
            dx = centers[-1][0] - centers[0][0]
            dy = centers[-1][1] - centers[0][1]
            horizontal_steps = [centers[i + 1][0] - centers[i][0]
                                for i in range(len(centers) - 1)]
            moving_steps = [step for step in horizontal_steps if abs(step) >= 0.01 * width]
            if not moving_steps:
                continue
            direction_ratio = sum(1 for step in moving_steps if step * dx > 0) / len(moving_steps)
            horizontal_path = sum(abs(step) for step in horizontal_steps)
            straightness = abs(dx) / horizontal_path if horizontal_path else 0.0
            vertical_path = sum(abs(centers[i + 1][1] - centers[i][1])
                                for i in range(len(centers) - 1))
            if (abs(dx) < self.CUT_DISTANCE_WIDTHS * width
                    or abs(dy) > self.CUT_MAX_VERTICAL_WIDTHS * width
                    or vertical_path > self.CUT_MAX_VERTICAL_PATH_WIDTHS * width
                    or straightness < self.CUT_MIN_STRAIGHTNESS
                    or direction_ratio < self.CUT_MIN_DIRECTION_RATIO):
                continue
            displacement_margin = min(1.0, abs(dx) / (self.CUT_DISTANCE_WIDTHS * width))
            vertical_margin = max(0.0, 1.0 - abs(dy) /
                                  (self.CUT_MAX_VERTICAL_WIDTHS * width))
            return min(displacement_margin, vertical_margin, straightness, direction_ratio)
        return None

    def _stable_rearm(self) -> bool:
        if len(self._history) < self.MIN_SAMPLES:
            return False
        all_samples = list(self._history)
        end_time = self._timestamp(all_samples[-1])
        start_index = len(all_samples) - 1
        while (start_index > 0
               and end_time - self._timestamp(all_samples[start_index])
               < self.CUT_REARM_SECONDS):
            start_index -= 1
        samples = all_samples[start_index:]
        duration = end_time - self._timestamp(samples[0])
        if len(samples) < self.MIN_SAMPLES:
            return False
        width = self._palm_width(samples[-1])
        if duration < self.CUT_REARM_SECONDS or width <= 1e-6:
            return False
        centers = [self._point(sample, 9) for sample in samples]
        total_path = sum(self._distance2(centers[i], centers[i + 1])
                         for i in range(len(centers) - 1))
        return total_path < 0.25 * width
