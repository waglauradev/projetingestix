# Backlog do Projeto GESTIX

**Status:** catálogo de planejamento; atividades não representam funcionalidades implementadas.  
**Base:** `.specify/memory/constitution.md`, `specs/002-reconhecimento-gestos/` e o contexto oficial do projeto desta revisão.  
**Escopo:** jogo 3D de ritmo e ação em primeira pessoa. O jogo não depende de narrativa, introdução cinematográfica, CRUD, veículos, histórico de usuários ou aplicação web para inicializar.

Cada item descreve uma entrega. A Constitution 4.0.0 consta como candidata a ratificação; este catálogo segue a sequência documentada e não presume que a proposta esteja ratificada. RF e CA reiniciam por item e são referenciados com seu ID BKL. “Pendente” exige decisão antes de fechar a Spec ou iniciar implementação. A ordem segue as fases da Constitution; fases posteriores aguardam evidência e aprovação formal da Fase 1.

## Épicos

| ID | Épico | Escopo | Fase |
|---|---|---|---|
| EP-01 | Captura e Processamento de Movimentos | Câmera, detecção e preparação de dados | 1 |
| EP-02 | Reconhecimento de Gestos | Dados de validação, classificação e resultado seguro | 1 |
| EP-03 | Integração entre Sistemas | Contrato de eventos entre Python e Unity | 2 |
| EP-04 | Representação Visual e Combate | Experiência em primeira pessoa, equipamentos, animações, chefes e combate | 3 a 5 |
| EP-05 | Música e Sincronização | Reprodução musical e avaliação temporal | 6 |
| EP-06 | Pontuação e Progressão | Precisão, pontuação, combos e evolução | 7 |
| EP-07 | Testes e Validação | Integração completa, jogadores e otimização | 8 |

## Backlogs

Não havia um registro canônico de épicos no repositório. Os sete épicos EP-01 a EP-07 são a nova organização do backlog, alinhada às oito fases da Constitution; as fases 3 a 5 compartilham o épico de representação e combate.

### BKL-01 — Capturar vídeo da câmera
- **Épico:** EP-01 — Captura e Processamento de Movimentos
- **Problema:** sem quadros da câmera, o sistema não observa os movimentos usados no reconhecimento.
- **Objetivo:** capturar quadros durante uma sessão e tratar estados de acesso e falha.
- **Requisitos funcionais:**
  - **RF01:** Iniciar leitura quando a câmera estiver disponível e acesso concedido.
  - **RF02:** Interromper leitura ao encerrar captura ou ocorrer falha impeditiva.
  - **RF03:** Comunicar câmera indisponível, acesso negado ou quadro inválido ao consumidor.
- **Critérios de aceite:**
  - **CA01:** Com permissão e câmera disponível, quadros são entregues à etapa seguinte.
  - **CA02:** Acesso negado/câmera ausente não reporta sucesso e gera estado de falha definido na Spec.
  - **CA03:** Encerrar captura interrompe novos quadros; frames brutos não são persistidos sem aprovação específica.
- **Dependências:** ciclo de sessão e ambiente suportado; alimenta BKL-02.
- **Spec Kit:** Feature de captura necessária; inexistente.
- **Estado:** planejado; plataforma e feedback pendentes.

### BKL-02 — Detectar e rastrear mãos
- **Épico:** EP-01 — Captura e Processamento de Movimentos
- **Problema:** quadros de vídeo não fornecem as posições das mãos necessárias para classificar movimentos.
- **Objetivo:** detectar mãos e pontos-chave com MediaPipe, comunicando ausência, perda e recuperação de tracking.
- **Requisitos funcionais:**
  - **RF01:** Receber quadros da captura OpenCV e obter pontos-chave das mãos usando MediaPipe.
  - **RF02:** Indicar ausência de mãos ou pontos inválidos para consumo.
  - **RF03:** Disponibilizar pontos/estado de tracking sem classificar gestos.
- **Critérios de aceite:**
  - **CA01:** Quadro com mão detectável produz pontos-chave no formato acordado.
  - **CA02:** Ausência/perda de tracking nunca é comunicada como gesto reconhecido.
  - **CA03:** Após recuperação, novos dados seguem para preparação sem reutilizar gesto parcial anterior.
- **Dependências:** BKL-01; contratos com BKL-03 e BKL-05.
- **Spec Kit:** Feature de captura/detecção necessária; inexistente.
- **Estado:** planejado; schema, frequência e condições pendentes.

### BKL-03 — Preparar características do movimento
- **Épico:** EP-01 — Captura e Processamento de Movimentos
- **Problema:** pontos-chave podem estar incompletos, desordenados ou incompatíveis com as regras do reconhecedor.
- **Objetivo:** validar e preparar observações espaciais/temporais para consumo consistente.
- **Requisitos funcionais:**
  - **RF01:** Validar estrutura, tracking e referência temporal das observações.
  - **RF02:** Calcular/organizar características espaciais e temporais aprovadas.
  - **RF03:** Sinalizar entradas inválidas/insuficientes e disponibilizar apenas saída válida.
- **Critérios de aceite:**
  - **CA01:** Entrada válida conforme contrato produz dados no formato acordado com BKL-05.
  - **CA02:** Amostra ausente, truncada ou fora do domínio não é enviada como válida.
  - **CA03:** Coordenadas, unidades, campos temporais e transformação ficam documentados e reproduzíveis.
- **Dependências:** BKL-02; contrato upstream da Spec de reconhecimento.
- **Spec Kit:** Feature de preparação necessária; Spec 002 contém apenas contrato lógico de resultado.
- **Estado:** planejado; schema upstream pendente.

### BKL-04 — Preparar dados rotulados para validação
- **Épico:** EP-02 — Reconhecimento de Gestos
- **Problema:** sem amostras rotuladas e condições registradas não se verifica diferenciação ou falsos positivos.
- **Objetivo:** manter conjunto de validação para gestos aprovados e casos negativos com origem e rótulos verificáveis.
- **Requisitos funcionais:**
  - **RF01:** Identificar rótulo, estado, versão dos critérios e condições de cada amostra.
  - **RF02:** Incluir casos positivos, inválidos, incompletos e movimentos fora do catálogo inicial.
  - **RF03:** Não armazenar/transmitir frames brutos ou dados identificáveis sem finalidade, acesso, retenção e aprovação documentados.
- **Critérios de aceite:**
  - **CA01:** Cada amostra usada em avaliação tem rótulo e metadados suficientes para reproduzir o teste.
  - **CA02:** A matriz cobre gestos iniciais e casos negativos previstos pela Spec.
  - **CA03:** Armazenamento está descrito e aprovado conforme a Constitution.
- **Dependências:** dados/privacidade aprovados e catálogo inicial de gestos/criterios de rotulo definido na Spec; nao depende da implementacao do classificador.
- **Spec Kit:** pode ficar na Spec de reconhecimento; T009 já cria fixtures sintéticas/processadas. Este backlog considera conjunto rotulado mais amplo; não autoriza persistência nem armazenamento de frames brutos. Separar apenas se curadoria/armazenamento virar entrega independente.
- **Estado:** planejado; origem, armazenamento e retenção pendentes.

### BKL-05 — Reconhecer e diferenciar gestos iniciais
- **Épico:** EP-02 — Reconhecimento de Gestos
- **Problema:** o jogo não pode reagir com segurança sem distinguir ataque, defesa e movimentos inválidos.
- **Objetivo:** classificar gestos aprovados matematicamente e publicar estados lógicos seguros após as verificações exigidas.
- **Requisitos funcionais:**
  - **RF01:** Avaliar dados preparados usando critérios geométricos/temporais e limiar aprovados, começando por regras matemáticas.
  - **RF02:** Diferenciar corte horizontal (ataque com espada) e palma estendida para a frente (defesa); rejeitar movimento desconhecido, ambíguo, incompleto ou abaixo do limiar.
  - **RF03:** Evitar duplicatas e publicar somente `recognized`, `not_recognized` ou `unavailable`; os dois últimos não contêm ID acionável.
  - **RF04:** Aplicar somente o provedor secundário definido na Constitution ratificada e na Spec aprovada; chamadas externas/transmissão permanecem desabilitadas até aprovação específica de execução, payload e privacidade.
- **Critérios de aceite:**
  - **CA01:** Amostras válidas rotuladas produzem classes distintas segundo critérios aprovados.
  - **CA02:** Entradas inválidas, ambíguas, desconhecidas, insuficientes ou sem tracking não geram resultado acionável.
  - **CA03:** Inconsistência resulta em `not_recognized`; falha/timeout em `unavailable`; nenhuma falha vira reconhecimento positivo.
  - **CA04:** Execução única publica no máximo um reconhecimento segundo segmentação aprovada.
- **Dependências:** BKL-02, BKL-03, BKL-04 e decisões da Spec 002; sua aprovação de saída libera fases posteriores.
- **Spec Kit:** existente em `specs/002-reconhecimento-gestos/` (spec, plano, tarefas, contrato e modelo). Corresponde às três histórias existentes; não duplicar.
- **Estado:** especificado, não implementado. Critérios geométricos, schema, limiar, segmentação, desempenho, modelo/configuração, timeout, custos/limites, payload e privacidade da OpenAI API pendentes. Chamadas reais permanecem desabilitadas até aprovação específica.

### BKL-06 — Avaliar ML como alternativa condicional
- **Épico:** EP-02 — Reconhecimento de Gestos
- **Problema:** regras matemáticas podem não alcançar critérios aprovados, mas não há evidência atual para justificar classificador treinado.
- **Objetivo:** decidir com evidências se ML é necessário sem substituir antecipadamente a abordagem matemática.
- **Requisitos funcionais:**
  - **RF01:** Comparar resultados reproduzíveis das regras aos critérios aprovados antes de propor ML.
  - **RF02:** Se houver insuficiência demonstrada, documentar dados, treinamento, avaliação, dependências e impacto para aprovação.
  - **RF03:** Modelo não aprovado não integra o jogo.
- **Critérios de aceite:**
  - **CA01:** Evidências registram se as regras atendem aos limites definidos.
  - **CA02:** Sem insuficiência demonstrada e aprovação, nenhuma dependência/modelo ML é introduzido.
  - **CA03:** Proposta aprovada define métricas e comparação reproduzível antes da implementação.
- **Dependências:** BKL-05; aprovação da equipe.
- **Spec Kit:** nenhum até o gatilho técnico e aprovação.
- **Estado:** condicional; implementação não autorizada agora.

### BKL-07 — Integrar eventos Python ao Unity
- **Épico:** EP-03 — Integração entre Sistemas
- **Problema:** resultados lógicos não alteram o jogo sem comunicação e contrato seguros.
- **Objetivo:** transmitir eventos reconhecidos ao Unity e validar recebimento sem executar ação por estado inválido.
- **Requisitos funcionais:**
  - **RF01:** Traduzir somente IDs reconhecidos e comandos aprovados para mensagens do contrato Python–Unity.
  - **RF02:** Unity valida mensagens e descarta estados/campos desconhecidos ou inválidos.
  - **RF03:** Tratar falha, interrupção e confirmação conforme protocolo escolhido no plano técnico.
- **Critérios de aceite:**
  - **CA01:** ID aprovado produz exatamente um evento aceito pelo Unity.
  - **CA02:** Estado não reconhecido/indisponível, ID desconhecido ou mensagem inválida não aciona gameplay.
  - **CA03:** Teste de interrupção observa falha/recuperação documentada sem reportar entrega não confirmada.
- **Dependências:** aprovação formal Fase 1 e BKL-05; início apenas na Fase 2.
- **Spec Kit:** Feature Python–Unity necessária; protocolo ainda não escolhido.
- **Estado:** planejado e bloqueado pelo gate constitucional da Fase 1.

### BKL-08 — Comunicar o estado do gesto ao jogador
- **Épico:** EP-03 — Integração entre Sistemas
- **Problema:** em primeira pessoa, o jogador precisa entender se o gesto foi reconhecido, rejeitado ou indisponível.
- **Objetivo:** apresentar feedback em Unity coerente com o estado e sem sugerir sucesso indevido.
- **Requisitos funcionais:**
  - **RF01:** Apresentar reconhecimento, não reconhecimento e indisponibilidade conforme a Spec.
  - **RF02:** Relacionar feedback ao evento recebido; ausência de ação não pode ser apresentada como ataque/defesa bem-sucedidos.
- **Critérios de aceite:**
  - **CA01:** Demonstração permite distinguir os três estados lógicos.
  - **CA02:** Evento ausente/inválido não é apresentado como ação executada.
  - **CA03:** Feedback é conferido na perspectiva em primeira pessoa e nos fluxos afetados.
- **Dependências:** BKL-07; UX, acessibilidade e representação visual definidos na Spec.
- **Spec Kit:** incluir na Feature futura de integração/feedback; não duplicar saída lógica da Spec 002.
- **Estado:** planejado; solução visual e acessibilidade pendentes.

### BKL-09 — Representar mãos e equipamentos em primeira pessoa
- **Épico:** EP-04 — Representação Visual e Combate
- **Problema:** ataques e defesas precisam de representação visual coerente para serem compreensíveis em primeira pessoa.
- **Objetivo:** apresentar mãos virtuais e espada/equipamento aprovado no enquadramento do jogador.
- **Requisitos funcionais:**
  - **RF01:** Posicionar representação visual relativamente à câmera conforme regras aprovadas.
  - **RF02:** Preparar/importar modelos 3D do Blender, se usados, segundo convenções definidas para Unity.
- **Critérios de aceite:**
  - **CA01:** Mãos e equipamento aprovados são visíveis durante a cena de gameplay no enquadramento definido.
  - **CA02:** Equipamento corresponde ao tipo aprovado e não oculta indevidamente a área necessária à interação.
  - **CA03:** Ativo importado mantém escala, orientação e aparência verificadas na cena-alvo.
- **Dependências:** integração da Fase 2; decisões de design e assets.
- **Spec Kit:** Feature de representação visual necessária.
- **Estado:** planejado; modelos, equipamentos e critérios visuais pendentes.

### BKL-10 — Reproduzir animações de ataque e defesa
- **Épico:** EP-04 — Representação Visual e Combate
- **Problema:** sem resposta animada vinculada ao evento, o jogador não confirma a execução visual do comando.
- **Objetivo:** acionar animações correspondentes aos comandos de ataque e defesa aprovados.
- **Requisitos funcionais:**
  - **RF01:** Associar comando de ataque à animação aprovada.
  - **RF02:** Associar comando de defesa à animação aprovada.
  - **RF03:** Impedir animação indevida ou duplicada por eventos inválidos/repetidos.
- **Critérios de aceite:**
  - **CA01:** Evento válido de ataque inicia a animação de ataque uma vez.
  - **CA02:** Evento válido de defesa inicia a animação de defesa uma vez.
  - **CA03:** Evento rejeitado/indisponível ou sem mapeamento não inicia essas animações.
- **Dependências:** BKL-07 a BKL-09; mapeamento de comandos confirmado.
- **Spec Kit:** incluir em Feature futura de representação/integração; transições definidas no plano.
- **Estado:** planejado; tempos e transições pendentes.

### BKL-11 — Implementar ciclo básico de combate
- **Épico:** EP-04 — Representação Visual e Combate
- **Problema:** os gestos integrados não formam confronto jogável sem estados e consequências para ataque/defesa.
- **Objetivo:** habilitar ciclo básico entre jogador e chefe com estados e condições de resultado aprovados.
- **Requisitos funcionais:**
  - **RF01:** Representar estados de combate necessários para ataque, defesa, dano e encerramento conforme Spec.
  - **RF02:** Aplicar resultados de comandos válidos ao estado de combate.
  - **RF03:** Apresentar vitória/derrota somente quando suas condições forem atingidas.
- **Critérios de aceite:**
  - **CA01:** Demonstração percorre os estados documentados e cada transição tem entrada e resultado observável.
  - **CA02:** Ataque/defesa válidos afetam o combate conforme regras aprovadas; estados não acionáveis não o alteram.
  - **CA03:** Condições de vitória/derrota são verificadas com regras definidas na Spec.
- **Dependências:** BKL-07 e BKL-10; regras de dano, vida e encerramento. BKL-12 amplia os padrões de chefe após a base de combate.
- **Spec Kit:** Feature de combate básico necessária.
- **Estado:** planejado; estados, dano, HP e condições de vitória/derrota pendentes.

### BKL-12 — Definir e executar padrões de ataque de chefes
- **Épico:** EP-04 — Representação Visual e Combate
- **Problema:** um confronto exige ataques identificáveis e tratáveis, mas os padrões de comportamento não estão definidos.
- **Objetivo:** apresentar ataques de chefe e sinais de resposta documentados.
- **Requisitos funcionais:**
  - **RF01:** Identificar padrões e condições de início/fim na Spec.
  - **RF02:** Comunicar visualmente o ataque segundo sinais aprovados.
  - **RF03:** Aplicar a resposta de defesa conforme regra aprovada para o padrão.
- **Critérios de aceite:**
  - **CA01:** Cada padrão especificado pode iniciar e terminar sob condições reproduzíveis.
  - **CA02:** Demonstração apresenta o sinal do ataque e a janela de resposta definida.
  - **CA03:** Respostas válidas e inválidas produzem resultados conforme regra aprovada.
- **Dependências:** BKL-11; regras de chefe, temporização e defesa.
- **Spec Kit:** incluir na Feature de combate ou separar se o planejamento estabelecer escopo autônomo.
- **Estado:** planejado; quantidade, padrões e parâmetros pendentes.

### BKL-13 — Incorporar esquiva e habilidades especiais
- **Épico:** EP-04 — Representação Visual e Combate
- **Problema:** a Constitution prevê fase posterior de esquiva/especial, mas gestos, efeitos e regras ainda não foram definidos.
- **Objetivo:** ampliar o combate com essas ações após aprovação dos comandos e efeitos.
- **Requisitos funcionais:**
  - **RF01:** Definir gestos/movimentos e identificadores na Spec antes de implementar.
  - **RF02:** Executar somente efeitos associados a comandos reconhecidos e aprovados.
  - **RF03:** Rejeitar gesto inválido ou sem mapeamento sem alterar o combate.
- **Critérios de aceite:**
  - **CA01:** Cada ação aprovada liga gesto, comando e resultado observável em contrato documentado.
  - **CA02:** Casos válidos e inválidos podem ser demonstrados conforme critérios da Spec.
  - **CA03:** Sem aprovação, nenhuma ação entra no catálogo de execução.
- **Dependências:** Fases 1 e 2 aprovadas; BKL-11; decisões de gestos e efeitos.
- **Spec Kit:** necessário se aprovado; não ampliar Spec 002 sem refinamento.
- **Estado:** planejado e bloqueado por sequência constitucional e decisões de design.

### BKL-14 — Integrar música ao jogo
- **Épico:** EP-05 — Música e Sincronização
- **Problema:** mecânicas de ritmo precisam de referência musical reproduzível para relacionar movimentos aos tempos da partida.
- **Objetivo:** disponibilizar reprodução e referência temporal musical consultável pelo gameplay.
- **Requisitos funcionais:**
  - **RF01:** Unity inicia, mantém e encerra reprodução conforme ciclo de partida aprovado.
  - **RF02:** Gameplay consulta a referência temporal definida na Feature.
- **Critérios de aceite:**
  - **CA01:** Faixa aprovada inicia/encerra nos estados de jogo especificados.
  - **CA02:** Referência temporal progride com a reprodução e reinicia/encerra conforme política documentada.
  - **CA03:** Pausa, reinício e interrupção são testados quando esses estados forem definidos.
- **Dependências:** aprovação da Fase 5 e decisões de música, estado e relógio.
- **Spec Kit:** Feature de música necessária.
- **Estado:** planejado; faixa e comportamento de pausa/reinício pendentes.

### BKL-15 — Avaliar precisão temporal do gesto
- **Épico:** EP-05 — Música e Sincronização
- **Problema:** reconhecimento isolado não informa se o movimento ocorreu no momento musical esperado.
- **Objetivo:** comparar o instante do evento com a referência musical e classificar precisão conforme regras aprovadas.
- **Requisitos funcionais:**
  - **RF01:** Obter instante do evento reconhecido e referência temporal definida.
  - **RF02:** Classificar precisão usando janelas/categorias aprovadas.
  - **RF03:** Manter reconhecimento e avaliação temporal como responsabilidades distintas.
- **Critérios de aceite:**
  - **CA01:** Eventos antes, dentro e depois das janelas de teste têm classificação definida na Spec.
  - **CA02:** Timestamp inválido ou relógio ausente não recebe classificação inventada.
  - **CA03:** Medição registra a relação temporal entre gesto, evento e música.
- **Dependências:** BKL-07 e BKL-14; aprovação de relógio e janelas.
- **Spec Kit:** compartilhar Feature com música ou pontuação conforme fronteiras aprovadas.
- **Estado:** planejado; janelas, tolerâncias e categorias pendentes.

### BKL-16 — Calcular pontuação e combos
- **Épico:** EP-06 — Pontuação e Progressão
- **Problema:** jogador precisa de retorno sobre desempenho e continuidade dos acertos, mas os critérios de pontuação não foram definidos.
- **Objetivo:** registrar desempenho e apresentar pontuação/combos segundo regras aprovadas.
- **Requisitos funcionais:**
  - **RF01:** Atualizar pontuação com eventos de combate e precisão definidos na Spec.
  - **RF02:** Manter contagem de acertos consecutivos e interrompê-la conforme regras aprovadas.
  - **RF03:** Apresentar resultado reconciliável com eventos registrados.
- **Critérios de aceite:**
  - **CA01:** Sequência de eventos de teste produz pontuação/combo iguais ao cálculo especificado.
  - **CA02:** Evento não acionável não recebe pontos nem aumenta combo, salvo decisão explícita.
  - **CA03:** Resultado pode ser reconciliado aos eventos e regras aplicados.
- **Dependências:** BKL-11 e BKL-15; regras de pontuação e combo.
- **Spec Kit:** Feature de pontuação necessária; decidir se precisão/sincronização ficam agrupadas.
- **Estado:** planejado; pesos, resets e sequência pendentes.

### BKL-17 — Implementar barra de especial e progressão
- **Épico:** EP-06 — Pontuação e Progressão
- **Problema:** barra de especial e evolução foram planejadas sem regras de ganho, gasto ou desbloqueio aprovadas.
- **Objetivo:** aplicar progressão e disponibilidade de habilidades conforme condições definidas pela equipe.
- **Requisitos funcionais:**
  - **RF01:** Atualizar barra segundo ganho/consumo estabelecidos na Spec.
  - **RF02:** Aplicar apenas desbloqueios e mudanças de dificuldade aprovados.
  - **RF03:** Mostrar estado sem sugerir disponibilidade quando a condição não foi cumprida.
- **Critérios de aceite:**
  - **CA01:** Casos de ganho, consumo e indisponibilidade seguem as regras especificadas.
  - **CA02:** Desbloqueios são reproduzíveis a partir de eventos/condições documentados.
  - **CA03:** Sem regras aprovadas, nenhum valor ou liberação automática é presumido.
- **Dependências:** BKL-13 e BKL-16; definições de especial/progressão.
- **Spec Kit:** Feature própria ou parte da pontuação após delimitação.
- **Estado:** planejado; regras pendentes.

### BKL-18 — Validar reconhecimento com testes reproduzíveis
- **Épico:** EP-07 — Testes e Validação
- **Problema:** presença de classificador não prova diferenciação sob variações de execução.
- **Objetivo:** produzir evidência reproduzível da qualidade da Fase 1.
- **Requisitos funcionais:**
  - **RF01:** Cobrir gestos positivos/negativos, ambiguidades, ausência/perda de tracking, duplicidade e variações aprovadas de velocidade, posição e iluminação.
  - **RF02:** Registrar condições, conjunto, versão de critérios, métricas e resultados observados.
  - **RF03:** Verificar os oito critérios constitucionais sem presumir aprovação.
- **Critérios de aceite:**
  - **CA01:** Cada execução tem instruções, entradas e condições suficientes para repetição.
  - **CA02:** Resultados são comparados aos limites aprovados e falhas permanecem registradas até reteste.
  - **CA03:** Aprovação da Fase 1 só é proposta com evidências de todos os critérios aplicáveis.
- **Dependências:** BKL-01 a BKL-05 e decisões de avaliação.
- **Spec Kit:** coberto por `specs/002-reconhecimento-gestos/tasks.md` e `quickstart.md`; não duplicar Feature.
- **Estado:** especificado parcialmente; execução/evidências pendentes. O repositório não contém implementação/testes do produto.

### BKL-19 — Testar sincronização, integração e fluxo completo
- **Épico:** EP-07 — Testes e Validação
- **Problema:** testes isolados não provam funcionamento conjunto entre câmera, reconhecimento, Unity, música e avaliação temporal.
- **Objetivo:** validar fronteiras integradas e registrar falhas antes de avançar fases.
- **Requisitos funcionais:**
  - **RF01:** Cobrir captura, preparação, reconhecimento, evento Python–Unity e ação observável conforme fases implementadas.
  - **RF02:** Com música/pontuação, testar relação entre evento, relógio, ação e classificação temporal.
  - **RF03:** Registrar latência, perda, duplicidade, indisponibilidade e erros nas condições aprovadas.
- **Critérios de aceite:**
  - **CA01:** Roteiro é executado com entradas conhecidas e resultado comparado à expectativa documentada.
  - **CA02:** Falhas relevantes não reportam sucesso e ficam registradas.
  - **CA03:** Este backlog não libera fase sem gate formal e evidências constitucionais.
- **Dependências:** Specs e implementações das fronteiras; fases anteriores autorizadas.
- **Spec Kit:** Feature integrada necessária, planejada por fase/gate para não duplicar testes existentes.
- **Estado:** planejado; condições e limites pendentes.

### BKL-20 — Validar experiência com jogadores
- **Épico:** EP-07 — Testes e Validação
- **Problema:** teste técnico não demonstra se a experiência em primeira pessoa é compreensível e executável por jogadores.
- **Objetivo:** observar sessões e registrar dificuldades de interação, feedback e resposta aos gestos.
- **Requisitos funcionais:**
  - **RF01:** Definir roteiro, build, condições e dados de avaliação antes das sessões.
  - **RF02:** Coletar observações sem armazenar dados pessoais/vídeo sem aprovação.
  - **RF03:** Vincular achados a backlog ou decisão de design para triagem.
- **Critérios de aceite:**
  - **CA01:** Sessões seguem roteiro documentado e produzem resultados registrados.
  - **CA02:** Consentimento, acesso, finalidade e retenção estão definidos antes da coleta.
  - **CA03:** Achados são classificados como defeito, ajuste de design ou decisão pendente.
- **Dependências:** build jogável e protocolo de avaliação/privacidade aprovado.
- **Spec Kit:** necessária quando houver build e objetivo de avaliação definido.
- **Estado:** futuro; método e critérios pendentes.

### BKL-21 — Otimizar resposta em tempo real
- **Épico:** EP-07 — Testes e Validação
- **Problema:** atraso, fila ou perda entre captura e ação pode comprometer gestos no ritmo da partida.
- **Objetivo:** medir caminho do gesto à ação e corrigir gargalos sem degradar reconhecimento ou segurança.
- **Requisitos funcionais:**
  - **RF01:** Medir latência por componente e ponta a ponta, taxa, fila/perdas e recursos.
  - **RF02:** Preservar critérios aprovados de reconhecimento, entrega e sincronização durante otimizações.
  - **RF03:** Registrar comparação antes/depois e testes das fronteiras afetadas.
- **Critérios de aceite:**
  - **CA01:** Relatório identifica ambiente, hardware, versões, método e distribuição das métricas.
  - **CA02:** Resultados atendem aos limites aprovados ou registram falhas/impedimentos.
  - **CA03:** Retestes não introduzem regressões de classificação, duplicidade ou execução.
- **Dependências:** fluxo implementado e metas de latência/taxa aprovadas.
- **Spec Kit:** medição parcial em Spec 002; otimização ponta a ponta requer Feature futura.
- **Estado:** planejado; limites numéricos pendentes.

## Relação entre épicos, backlogs e Spec Kits

| Spec existente | Backlog relacionado | Situação |
|---|---|---|
| `specs/002-reconhecimento-gestos/` | BKL-05; validação relacionada BKL-18 | Única Feature técnica do jogo com Spec/plano/tarefas. Draft, sem implementação; decisões e gate da Fase 1 pendentes. |
| `specs/001-pesquisa-base-narrativa/` e `spec.md` na raiz | Pesquisa criativa opcional, fora do backlog funcional | Manter como referência auxiliar; não é gate técnico nem pré-requisito de gameplay. |

### Spec Kits necessários

- **Captura/preparação:** BKL-01 a BKL-03, agrupáveis se fronteiras e critérios ficarem explícitos.
- **Dados de validação:** BKL-04 pode integrar a Spec 002; separar apenas se persistência/curadoria for independente.
- **Integração e feedback Unity:** BKL-07 e BKL-08, depois do gate da Fase 1.
- **Representação visual:** BKL-09 e BKL-10, coordenada à integração.
- **Combate e chefes:** BKL-11 e BKL-12; definir dano, estados, ataques e encerramento.
- **Esquiva/especial:** BKL-13 após aprovação de gestos e efeitos.
- **Música/sincronização:** BKL-14 e BKL-15; agrupar ou separar conforme fronteiras aprovadas.
- **Pontuação/progressão:** BKL-16 e BKL-17; decidir a fronteira da barra especial.
- **Qualidade/avaliação:** BKL-19 a BKL-21; organizar por gate e evitar repetir testes já cobertos.
- **Modelo ML (BKL-06):** nenhuma Spec até evidência de insuficiência matemática e aprovação formal.

## Dependências e ordem

1. **Fase 1:** BKL-01 → BKL-02 → BKL-03 → BKL-05; BKL-04 oferece amostras e BKL-18 produz evidência. Fase 2 aguarda aprovação formal.
2. **Fase 2:** BKL-07 estabelece integração; BKL-08 apresenta estados.
3. **Fases 3–5:** BKL-09/BKL-10 representação e animações; BKL-11/BKL-12 combate; BKL-13 ações especiais sob aprovação.
4. **Fase 6:** BKL-14 fornece referência musical; BKL-15 avalia sincronização.
5. **Fase 7:** BKL-16 usa eventos/precisão; BKL-17 depende de progressão aprovada.
6. **Fase 8:** BKL-19 testa integração, BKL-20 valida experiência e BKL-21 mede/otimiza, respeitando gates.

## Registros antigos reavaliados

Os itens GES-01 a GES-12 eram a única lista de backlogs explícita identificada. Os grupos GES-01 a GES-12 foram preservados na tabela abaixo; os sete épicos são novos porque não havia cadastro formal anterior de épicos.

`output/GESTIX_Backlog_do_Projeto.docx` continha 12 itens GES derivados do diagrama de monitoria/web e está preservado em `output/archive/` como registro histórico, não como backlog vigente.

| Registro antigo | Tratamento | Justificativa |
|---|---|---|
| GES-01 usuários; GES-02 veículos; GES-03 histórico | Retirados do backlog de produto vigente | CRUD não faz parte do escopo oficial de gameplay nem das fases constitucionais. |
| GES-04 câmera | Reorganizado em BKL-01 | Captura OpenCV, encerramento e falhas explícitos. |
| GES-05 detecção | Reorganizado em BKL-02 | MediaPipe detecta; não classifica gesto. |
| GES-06 processamento | Reorganizado em BKL-03 | Preparação separada; schema pendente. |
| GES-07 reconhecimento | Reorganizado em BKL-05 | Alinhado à Spec 002 e aos gates da Constitution. |
| GES-08 validar/apresentar resultado | Separado entre BKL-05, BKL-08 e BKL-18 | Estado lógico, feedback Unity e evidência têm responsabilidades diferentes. |
| GES-09 ação Unity | Reorganizado em BKL-07 | Contrato e gate de fase explícitos. |
| GES-10/11 monitoria e resultados web | Não migrados como web; necessidade de feedback coberta em BKL-08 | Diagrama não confirma web como parte do jogo. |
| GES-12 backend/banco | Retirado do backlog vigente | PostgreSQL/CRUD não foram aprovados como componentes do jogo; aplicabilidade web/PostgreSQL está pendente na Constitution. |

## Pendências transversais

- Ratificação da candidata constitucional 4.0.0. O solicitante declara que o grupo aprovou OpenAI API no lugar do Gemini; nenhum registro formal foi localizado. Chamadas externas permanecem desligadas até aprovações de modelo, payload, ambiente, custos, segurança e privacidade.
- Critérios geométricos/temporais, confiança, segmentação e deduplicação dos gestos iniciais.
- Contrato de landmarks entre BKL-02, BKL-03 e BKL-05; origem/armazenamento/retenção do BKL-04.
- Hardware, sistema operacional, runtime e metas de latência, taxa, precisão, estabilidade e recursos.
- Protocolo, schema, confirmação, falhas e reconexão Python–Unity.
- Equipamentos, animações, estados/dano/vida, regras de chefe, vitória/derrota, esquiva/especial.
- Música, referência temporal, janelas, precisão, pontuação, combo, progressão e barra especial.
- Método, consentimento e dados de validação com jogadores.

## Limites do catálogo

O diagrama `Diagrama de arquitetura - Gestix.png` é uma referência existente que ainda mostra CRUD, veículos, monitoria web, PostgreSQL e Gemini; não foi atualizado nesta revisão. A candidata constitucional 4.0.0 propõe OpenAI API como verificador secundário, mas permanece sem ratificação e sem chamadas/transmissão habilitadas. Web/PostgreSQL não estão confirmados. O catálogo inclui capacidades do jogo confirmadas no contexto e na sequência constitucional; não declara nenhuma delas implementada.
