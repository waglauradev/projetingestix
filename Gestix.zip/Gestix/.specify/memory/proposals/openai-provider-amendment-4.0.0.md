# Proposta provisória de emenda constitucional — provedor OpenAI API

**Status:** proposta documental; não é Constituição ratificada nem registro de ratificação.  
**Versão candidata indicada no workspace:** 4.0.0 (MAJOR).  
**Data deste registro:** 2026-11-11.

## Estado da base normativa

- A Constituição 3.3.0 existente está marcada como candidata/em revisão, não ratificada.
- O próprio arquivo constitucional informa que 3.0.0 é a última versão ratificada, mas o texto 3.0.0 não foi localizado entre os arquivos existentes.
- O workspace não contém metadados Git; não foi possível pesquisar histórico, tags ou branches para recuperar a versão ratificada.
- A candidata 4.0.0 existente em `.specify/memory/constitution.md` foi preservada sem alterações. Ela declara carregar texto da 3.3.0 e, portanto, não pode ser tratada como cópia verificada da 3.0.0 nem como versão ratificada.

## Declaração de aprovação recebida

O solicitante declara que o grupo aprovou substituir Gemini pela plataforma de API da OpenAI como provedora do LLM de verificação de inconsistências. A busca local por atas, registro de votação ou outro artefato formal não encontrou evidência dessa aprovação. Esta nota atribui a declaração ao solicitante e não inventa data da decisão, participantes, votos ou assinaturas. A declaração não constitui ratificação da Constituição 4.0.0.

## Emenda proposta

1. Alterar os princípios II, IV, V e XII para designar a plataforma de API da OpenAI como provedora do LLM usado exclusivamente para sinalizar inconsistências numa classificação inicial já produzida por regras matemáticas em Python.
2. Manter Python como única autoridade sobre a classe matemática e proibir que o LLM crie/altere gestos, classes, comandos ou ações de combate.
3. Preservar os estados `recognized`, `not_recognized` e `unavailable`. `recognized` só pode conter identificador após classificação matemática elegível e verificação aprovada/habilitada sem inconsistência. Inconsistência resulta em `not_recognized`; API desabilitada, ausência, falha de comunicação, timeout ou resposta inválida resulta em `unavailable`, sempre sem identificador acionável.
4. Manter chamadas reais e transmissão de dados desabilitadas até aprovação específica de modelo, payload, ambiente/configuração, timeouts, falhas, custos/limites, segurança e privacidade.
5. Manter reconhecimento na Fase 1 e transporte/integração Python–Unity na Fase 2.

Esses pontos resumem a proposta e a candidata 4.0.0 presente; não reconstroem os princípios restantes da versão 3.0.0 ausente. A mudança de provedor é tratada como candidata MAJOR porque redefine um papel tecnológico constitucional, conforme a regra de versionamento registrada na candidata atual. A sequência oficial após 3.0.0 deve ser confirmada na ratificação, pois as versões 3.1.0–3.3.0 não estão marcadas como ratificadas.

## Pendências independentes

- Recuperar a cópia exata da Constituição 3.0.0 ratificada para verificar e preservar todos os princípios não afetados.
- Vincular evidência formal da decisão declarada pelo solicitante quando estiver disponível; esta proposta não presume que a declaração seja uma ata.
- Submeter o texto constitucional completo baseado na 3.0.0 para aprovação/ratificação pelo grupo e registrar data e evidência formais.
- Aprovar separadamente modelo OpenAI, payload, ambiente/configuração, timeout, tratamento de falhas, custos/limites, segurança, privacidade e autorização de transmissão antes de qualquer chamada real.

## Rastreabilidade

Esta proposta acompanha a solicitação recebida em 2026-11-11 e a análise Speckit Analyze mais recente, que identificou conflito crítico ao tratar a exigência de Gemini na versão 3.3.0 em revisão como baseline ratificada. A análise não foi salva como arquivo separado; seu resultado está no histórico desta conversa. A proposta não altera captura, MediaPipe, classificação matemática, contrato de Unity ou transporte.
