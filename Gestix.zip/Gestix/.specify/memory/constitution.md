<!-- Sync Impact Report
Version change (candidate): 3.3.0 → 4.0.0 (major provider-role change; pending ratification)
Modified principles: II (OpenAI API technology role); IV (LLM limited to inconsistency verification and fail-closed states); V (no actionable output on failed verification); XII (API/transmission approval gate)
Added principles: none
Added sections: none
Modified sections: Contexto e Status das Decisões do Projeto; Restrições Adicionais; Sequenciamento Obrigatório das Fases; Governança
Removed sections: none
Carry-forward from 3.3.0: prior modifications to principles I–X are retained; principles XI (music synchronization) and XII (privacy/security) were added; context, constraints, workflow and governance updates remain in force; no prior sections were removed.
Follow-up TODOs: The team approved 3.3.0 as working text and approved this amendment as candidate only; neither fact ratifies 3.3.0 or 4.0.0. The full ratified 3.0.0 text remains unrecovered. API model, SDK, payload, endpoint, parameters, security, privacy, configuration and cost approvals remain pending. Gesture confidence threshold, Python-Unity protocol, gameplay rules and applicability of web/PostgreSQL diagram elements remain pending. Ratification date remains pending.
-->
# GESTIX Constitution

## Core Principles

### I. Organização e Qualidade do Código
O código MUST ser organizado em componentes com responsabilidades identificáveis e compatíveis
com a arquitetura documentada. Cada mudança MUST indicar os componentes afetados e relacioná-los
a requisitos ou critérios de aceitação. Entradas inválidas e falhas nas fronteiras entre componentes
MUST ter tratamento explícito. Novas dependências, camadas ou abstrações MUST ser justificadas no
plano da feature; a revisão MUST conseguir localizar a implementação e sua responsabilidade sem
inferir convenções não documentadas.

Captura, processamento de pontos de referência, reconhecimento, comunicação com Unity e execução
das ações no jogo MUST ter responsabilidades documentadas e separáveis. Alterações MUST evitar
acoplamento que impeça testar ou evoluir cada fronteira de forma identificável.

### II. Preservação da Arquitetura e das Funcionalidades
Mudanças MUST preservar os fluxos e as tecnologias confirmadas pelo grupo e pelos artefatos do
projeto: Python para reconhecer movimentos e produzir eventos; OpenCV para captura de câmera;
MediaPipe para detecção das mãos e dos pontos corporais; plataforma de API da OpenAI exclusivamente
como verificador secundário de inconsistências na classificação de gestos; Unity para desenvolvimento
e execução do jogo; e Blender para produção de elementos conforme necessário. Blender não integra
automaticamente o fluxo de execução.

As Specs e os planos MUST atribuir responsabilidades às tecnologias apenas conforme decisões
documentadas. Novas ferramentas, dependências ou substituições MUST incluir justificativa e aprovação
da equipe; nenhuma tecnologia ou integração adicional pode ser tratada como obrigatória por
inferência.

O processamento local MUST ser o padrão para captura, pontos de referência e reconhecimento. O
planejamento de cada feature MUST documentar e justificar qualquer envio de dados a serviços
externos, inclusive à API da OpenAI. Chamadas reais à API e transmissão de dados MUST permanecer
desabilitadas até aprovação específica da equipe para segurança, privacidade, configuração e custos.

Alterações em limites, contratos, tecnologias ou comportamentos existentes MUST ser descritas na
especificação, incluindo componentes consumidores e impacto funcional. Critérios de aceitação MUST
verificar fluxos afetados e regressões relevantes. Nenhuma funcionalidade existente pode ser removida
ou ter seu comportamento alterado sem requisito aprovado. Detalhes de integração não definidos nos
artefatos do projeto MUST NOT ser presumidos.

### III. Captura da Câmera e Detecção das Mãos
O fluxo de captura MUST usar OpenCV e encaminhar os frames necessários à detecção das mãos e dos
pontos corporais com MediaPipe. Python MUST orquestrar o reconhecimento de movimentos conforme a
especificação da fase autorizada. Cada feature que altere esse fluxo MUST
definir os resultados esperados para situações relevantes, como câmera indisponível, acesso negado,
frame inválido ou mão não detectada, conforme aplicável. O comportamento esperado e o feedback ao
jogador MUST ser registrados nos critérios da feature, sem presumir soluções ainda não definidas.

Um estado sem detecção válida MUST NOT ser comunicado como gesto reconhecido. Frames brutos MUST
NOT ser persistidos sem requisito aprovado que defina finalidade e retenção.

### IV. Reconhecimento e Validação dos Gestos
O reconhecimento MUST tratar de gestos comuns selecionados pelo grupo para interação com o jogo; o
projeto MUST NOT ser descrito como sistema de reconhecimento ou tradução de Libras.

As regras matemáticas em Python MUST ser a autoridade da classificação inicial, com base nos critérios
e no nível de confiança aprovados para a feature. A plataforma de API da OpenAI MUST atuar somente
como verificador secundário de inconsistências nessa classificação. O LLM MUST NOT escolher ou
modificar a classe, criar gestos, inventar comandos nem determinar ações de combate. Modelo específico,
SDK, payload, endpoint e parâmetros permanecem decisões pendentes e MUST ser definidos no plano após
aprovação da equipe.

O resultado MUST usar exatamente um destes estados: `recognized`, `not_recognized` ou `unavailable`.
`recognized` só pode conter um gesto aprovado quando as regras matemáticas o classificarem com
confiança suficiente e o verificador habilitado não apontar inconsistência. Uma inconsistência MUST
resultar em `not_recognized`; falha, timeout, resposta inválida ou API desabilitada MUST resultar em
`unavailable`. `not_recognized` e `unavailable` MUST NOT conter gesto, comando ou identificador
acionável. Quando a API estiver desabilitada, nenhum candidato pode ser publicado como `recognized`.

Na fase inicial, os gestos obrigatórios são o corte horizontal, correspondente ao ataque com espada,
e a palma estendida para a frente, correspondente à defesa. Os critérios verificáveis de cada gesto,
incluindo direção, deslocamento, velocidade, configuração dos dedos e orientação da palma, MUST ser
documentados na especificação antes da implementação.

O reconhecimento inicial MUST usar regras matemáticas sobre os pontos de referência e o movimento
detectado. Modelos de aprendizado de máquina só podem ser propostos se resultados de testes
documentados demonstrarem que as regras matemáticas não atendem aos critérios de aceitação; a adoção
depende de justificativa e aprovação no plano da feature.

O reconhecimento MUST distinguir os gestos e comandos definidos pela equipe de movimentos inválidos,
incluindo movimentos incompletos, perda de rastreamento e casos ambíguos, e MUST impedir a emissão de
eventos duplicados para um único gesto. Um resultado abaixo do nível de confiança definido na Spec
MUST ser tratado como não reconhecido e não pode gerar comando. O limite de confiança e o mapeamento
de gesto para comando MUST ser definidos e justificados nas Specs, não fixados nesta Constitution.

Respostas ausentes, malformadas ou ambíguas, bem como gestos desconhecidos ou não reconhecidos, MUST
ser tratados como resultado não válido para gerar comando. Critérios de aceitação MUST cobrir os
gestos e resultados de reconhecimento afetados pela feature.

### V. Integração entre Reconhecimento e Jogo
Somente gestos reconhecidos, validados e associados a comandos aprovados MUST acionar ações no jogo.
O mapeamento gesto-comando-ação e o comportamento para resultado inválido ou indisponível MUST estar
documentados nos artefatos da feature.

Um gesto desconhecido, ambíguo, não reconhecido ou sem comando aprovado MUST NOT disparar ação de
jogo. A comunicação entre o sistema de visão computacional e Unity MUST ter contrato documentado e
testável. A Spec e o plano MUST definir como serão avaliados latência, confiabilidade de entrega,
erros, interrupções e recebimento de eventos, sem presumir protocolo antes do planejamento técnico.
Os estados `not_recognized` e `unavailable` MUST NOT conter gesto ou comando acionável. A Fase 1
produz e valida o resultado lógico do reconhecedor; a comunicação com Unity pertence à Fase 2, que
permanece bloqueada até a aprovação baseada em evidências da Fase 1.
Mudanças na integração MUST verificar o contrato de entrada e a ação observável resultante na
fronteira afetada.

### VI. Testes e Critérios de Qualidade
Toda feature MUST declarar critérios de aceitação observáveis antes da implementação, contemplando
sucesso e falhas relevantes aos componentes alterados. Mudanças MUST incluir verificações automatizadas
ou reproduzíveis para o comportamento e as fronteiras afetadas; alterações em captura, detecção,
reconhecimento, jogo ou persistência MUST verificar a integração correspondente.

Critérios aplicáveis MUST passar antes de a mudança ser considerada concluída. Verificações não
executadas MUST ser registradas com motivo e responsável pelo acompanhamento. A conclusão de uma
fase MUST ser sustentada por resultados de testes e evidências documentadas; a existência de código,
por si só, não comprova funcionamento nem autoriza avanço. Conforme aplicável ao componente, o plano
MUST prever testes unitários, testes de reconhecimento, testes de integração, testes de sincronização
musical e validação do fluxo completo entre captura, evento e ação em Unity. Testes unitários não
substituem verificações de integração.

### VII. Acessibilidade e Experiência do Jogador
A interação MUST comunicar ao jogador, de forma compreensível e definida na especificação, quando
um gesto foi reconhecido, não reconhecido ou não pode gerar uma ação. A feature MUST definir como o
jogador percebe o resultado da interação e como são apresentados os estados ou falhas que a afetam.
A revisão MUST conferir os critérios de feedback declarados.

Features de interação MUST considerar a perspectiva em primeira pessoa e validar se o feedback e a
resposta visual correspondem ao comando reconhecido, sem impor uma solução visual não aprovada.

Necessidades de acessibilidade e opções alternativas de interação MUST ser avaliadas e registradas
na especificação pertinente, sem presumir mecanismos que ainda não estejam definidos no projeto.
O reconhecimento de gestos MUST ser descrito como interação do jogo, não como tradução de Libras.

### VIII. Desempenho do Reconhecimento em Tempo Real
Features que alterem o caminho entre captura e comando MUST definir antes da implementação as
condições de avaliação e os limites aceitáveis de latência e taxa de processamento. A verificação
MUST medir e registrar essas métricas sob as mesmas condições e compará-las com os limites definidos.
Na fase de reconhecimento, os testes MUST cobrir diferentes velocidades de execução, posições das
mãos e condições de iluminação, além de verificar que cada evento reconhecido corresponde ao
movimento realmente executado pelo jogador. O fluxo completo MUST avaliar a relação temporal entre o
gesto, o evento, a ação de combate e o tempo musical quando a feature envolver sincronização.

Esta Constitution não estabelece metas numéricas globais. Qualquer limite MUST ser justificado e
aprovado nos artefatos da feature antes de servir como critério de qualidade.

### IX. Documentação e Manutenção
Mudanças em arquitetura, contratos, gestos suportados, mapeamento de comandos, tecnologias ou operação
MUST atualizar a documentação correspondente na mesma alteração. Decisões que divergem dos artefatos
vigentes MUST registrar motivo, impacto e componentes afetados.

Requisitos, critérios e instruções MUST permitir que outra pessoa localize o fluxo e repita as
verificações sem depender de conhecimento não registrado.

### X. Desenvolvimento Sequencial e Bloqueio de Fases
A implementação MUST seguir a ordem obrigatória definida em “Sequenciamento Obrigatório das Fases”.
O reconhecimento de gestos é a primeira prioridade e um pré-requisito bloqueante: nenhuma
funcionalidade de fase posterior pode ser implementada até que a Fase 1 atenda a todos os critérios
de conclusão desta Constitution e sua conclusão seja formalmente aprovada com base em evidências.

O término de uma tarefa ou a presença de código funcional MUST NOT ser interpretado como autorização
para iniciar a fase seguinte. A equipe e a IA de desenvolvimento MUST trabalhar somente na fase
autorizada, apresentar os critérios atendidos e os resultados dos testes para revisão e aguardar
aprovação explícita antes de avançar. Se qualquer critério falhar ou não tiver evidência suficiente,
a fase permanece aberta; os problemas devem ser corrigidos e os testes pertinentes repetidos. Testes
nunca podem ser simulados nem seus resultados presumidos.

Cada fase MUST ter dependências e critérios de saída registrados em sua Spec e tarefas. A revisão
deve conferir as evidências verificáveis antes de autorizar a fase dependente.

### XI. Sincronização Musical
Features que relacionem combate, avaliação do jogador ou progressão ao ritmo MUST definir na Spec a
referência temporal, os critérios observáveis de sincronização e como serão verificados. As regras de
tempo, janelas de acerto e efeitos na pontuação MUST ser aprovadas nos artefatos da feature antes da
implementação; esta Constitution não fixa valores nem regras de gameplay. Testes MUST relacionar o
tempo do evento reconhecido e a avaliação produzida às condições musicais definidas para a feature.

### XII. Privacidade e Segurança
Captura de câmera e dados de movimento MUST ser tratados para a finalidade documentada da feature,
com processamento local como padrão. Frames brutos, dados identificáveis e histórico MUST NOT ser
armazenados ou transmitidos sem requisito explícito, finalidade, acesso e retenção documentados e
aprovados. Falhas de acesso, transmissão ou persistência MUST ser tratadas sem reportar sucesso
indevido; dados temporários MUST ser descartados conforme o ciclo de vida documentado.

## Sequenciamento Obrigatório das Fases
As fases MUST ser executadas nesta ordem, com o bloqueio e a aprovação definidos no Princípio X.
Esta lista define áreas e ordem de trabalho, não regras detalhadas de gameplay. Estados, atributos,
condições, janelas de tempo, critérios de pontuação, equipamentos e progressão MUST ser definidos e
aprovados nas Specs correspondentes antes da implementação:

1. **Fase 1 — Reconhecimento de gestos:** configurar e validar captura de vídeo com OpenCV;
   detectar e rastrear mãos com MediaPipe; reconhecer corte horizontal (ataque com espada) e palma
   estendida para a frente (defesa); diferenciar gestos válidos e inválidos; tratar movimentos
   incompletos, perda de rastreamento e ambiguidades; prevenir eventos duplicados; testar diferentes
   velocidades, posições das mãos e condições de iluminação; validar correspondência com os
   movimentos realizados. Deve satisfazer os oito critérios de conclusão abaixo.
2. **Fase 2 — Comunicação entre Python e Unity:** iniciar somente após a aprovação baseada em
   evidências da Fase 1; definir o contrato e escolher o protocolo durante o planejamento técnico;
   transmitir eventos reconhecidos; validar recebimento; tratar erros e interrupções.
3. **Fase 3 — Representação visual em primeira pessoa:** criar mãos virtuais e representação da
   espada; reproduzir animações de ataque e defesa; validar correspondência entre eventos e animações.
4. **Fase 4 — Sistema básico de combate:** implementar estados e ataques dos chefes, dano e pontos
   de vida, regras de defesa e condições básicas de vitória e derrota.
5. **Fase 5 — Esquiva e habilidades especiais:** definir gestos ou movimentos nas respectivas
   especificações; implementar e validar seu reconhecimento; integrar ações ao combate.
6. **Fase 6 — Sistema musical:** integrar reprodução musical, sincronizar ações com ritmo e definir
   janelas de tempo para ações de combate.
7. **Fase 7 — Pontuação e sequência de acertos:** implementar pontuação, registro de acertos e erros,
   sequências e progressão ou desbloqueio de habilidades conforme regras aprovadas.
8. **Fase 8 — Testes integrados e otimização:** validar funcionalidades em conjunto, medir latência,
   precisão e estabilidade, corrigir problemas e documentar resultados.

A Fase 1 só pode ser concluída quando todas as condições abaixo forem satisfeitas e documentadas:

1. Todos os gestos previstos para a fase inicial estão implementados.
2. Cada gesto tem critérios de reconhecimento documentados e verificáveis.
3. Testes de reconhecimento válido e inválido foram executados.
4. A diferenciação entre ataque e defesa foi validada.
5. Problemas críticos de reconhecimento foram corrigidos.
6. Resultados dos testes estão documentados, sem resultados simulados ou presumidos.
7. Critérios de aceitação da especificação foram atendidos.
8. A conclusão foi confirmada com evidências de testes, não somente pela existência do código.

Se uma condição não for atendida, a Fase 1 permanece ativa; problemas devem ser corrigidos e os
testes necessários repetidos. Sistemas musicais, pontuação, sequências de acertos, chefes completos e
animações finais não fazem parte da Fase 1. A arquitetura deve permitir integração futura sem
reconstrução desnecessária do reconhecimento. Python reconhece movimentos e produz eventos; Unity
permanece responsável pela representação visual e regras do jogo nas fases autorizadas.

## Contexto e Status das Decisões do Projeto
A apresentação “GESTIX — Apresentação do Projeto” descreve o GESTIX como um jogo 3D de ritmo e
ação, em que gestos comuns com as mãos interagem com o jogo e a música orienta desafios contra
bosses. Esse contexto registra a direção apresentada pelo projeto; não fixa mecânicas detalhadas,
regras de combate ou conteúdo narrativo que ainda não tenham sido aprovados pelo grupo.

O escopo técnico atual é um jogo 3D de ritmo e ação, desenvolvido no Unity e apresentado em primeira
pessoa. O jogo MUST poder inicializar e executar sem narrativa, história de personagens ou aprovação
de conteúdo narrativo. Documentação narrativa e visual pode apoiar decisões criativas, mas MUST NOT
ser pré-requisito de inicialização nem bloquear as fases técnicas do jogo.

A apresentação descreve um fluxo planejado de câmera, detecção das mãos, processamento e
reconhecimento de gestos, encaminhamento de eventos ao jogo e atualização do combate. Python está
confirmado para reconhecimento matemático de movimentos e produção de eventos. Nesta candidata 4.0.0,
a plataforma de API da OpenAI fica restrita à verificação secundária de inconsistências; nenhum
protocolo ou detalhe de integração é presumido.

Sincronização com música, precisão dos gestos, pontuação, combos, barra de especial, padrões de
ataque de bosses e progressão de dificuldade são itens planejados na apresentação. As ações exatas
de cada gesto, as regras de vitória e derrota, plataforma, fases e quantidade de bosses permanecem
decisões a definir nas especificações pertinentes; a menção nesta seção não as aprova.

A apresentação descreve Rayan como personagem masculino de perfil estratégico, com referências
visuais a Soren/Sorem e características inspiradas em Drake, “O Estratégico”. Ela cita como
referência de aparência roupas predominantemente pretas, detalhes vermelhos e cinza, capuz integrado,
calça cargo, bolsos e acessórios táticos; estratégia, planejamento, precisão, controle emocional,
liderança e visão tática são características apresentadas para esse conceito.

A apresentação descreve Vex como personagem feminina de perfil “A Estrela”, com referências visuais
a Vex e características inspiradas em Luna, “A Estrela”. Ela cita como referência de aparência
cabelo azul, roupas pretas com detalhes azuis, acessórios modernos e estilo marcante; carisma,
confiança, presença de palco, conexão com a música, energia e inspiração são características
apresentadas para esse conceito.

As duas imagens fornecidas pelo criador são identificadas na apresentação como referências visuais;
o texto diz que não devem ser substituídas e que modelos 3D podem adaptar os conceitos preservando
suas características principais. Nomes, perfis, características, inspirações e esta orientação de
preservação são registrados aqui como referências provisórias da apresentação até que sua aprovação
pelo grupo esteja explicitamente registrada. A relação de Rayan e Vex com personagens citados em
outros materiais narrativos permanece a definir. Esta Constitution não cria habilidades, seleção de
personagem nem efeitos dessas características na jogabilidade; a apresentação informa que tais pontos
ainda não foram definidos.

A apresentação também informa um planejamento de 16 sprints e uma previsão de entrega para o início
de maio de 2027. Esses dados são registrados como previsões do documento de apresentação, não como
compromissos aprovados ou critérios permanentes desta Constitution.

## Restrições Adicionais
O diagrama de arquitetura existente apresenta OpenCV para captura de câmera, MediaPipe para detecção
das mãos e dos pontos corporais, uma etapa de processamento, Gemini API e Unity. A presente candidata
4.0.0 substitui Gemini pela plataforma de API da OpenAI somente como verificador secundário de
inconsistências. O diagrama não foi alterado; sua atualização requer uma mudança documental separada.
Python permanece responsável pelas regras matemáticas de classificação inicial. Unity será usada
para desenvolver e executar o jogo, e Blender para produzir elementos conforme necessário; Blender
não integra automaticamente o fluxo de execução.

Python, OpenCV, MediaPipe, plataforma de API da OpenAI, Unity e Blender são as tecnologias e
ferramentas descritas para os papéis acima nesta candidata 4.0.0. O reconhecimento inicial usa regras
matemáticas sobre pontos de referência e movimento; modelos de aprendizado de máquina dependem de
evidência de necessidade nos testes e de aprovação no plano da feature. Versões, protocolos, formatos
de contrato e detalhes internos de integração não definidos nos artefatos MUST NOT ser presumidos.
Captura, pontos de referência e reconhecimento devem ser processados localmente por padrão. Chamadas
reais à API da OpenAI e qualquer transmissão de dados MUST permanecer desabilitadas até aprovação
específica da equipe para segurança, privacidade, configuração e custos. Modelo, SDK, payload,
endpoint e parâmetros permanecem pendentes. Dados pessoais, histórico, dados de gesto e imagens MUST
ser usados ou persistidos apenas para comportamento documentado, com validação de entradas e sem
indicar sucesso quando uma operação de persistência falhar.

O diagrama existente também apresenta uma aplicação chamada “A Monitoria”, uma interface web e
PostgreSQL para dados de usuários, veículos e histórico. A aplicabilidade desses componentes ao jogo
GESTIX não está confirmada pelos demais artefatos consultados. Eles MUST NOT ser tratados como
componentes obrigatórios do jogo até que a equipe confirme e atualize a documentação de arquitetura.
O fluxo de câmera, MediaPipe, processamento, verificação secundária pela plataforma de API da OpenAI
e Unity é o fluxo proposto nesta candidata. A figura existente ainda identifica Gemini até que seja
atualizada em mudança separada aprovada.

Perspectiva em primeira pessoa, combate, bosses, equipamentos, pontuação e progressão podem orientar
Specs de gameplay. Esta Constitution não define regras, atributos, condições de vitória, dano,
desbloqueios ou comportamento de equipamentos; cada regra MUST ser aprovada e testável na Spec da
feature correspondente.

O documento “GESTIX — O Mundo Além da Melodia: História em desenvolvimento” é referência narrativa
em elaboração. Elementos de história, personagens, motivações, acontecimentos e desfecho MUST NOT
ser tratados como requisitos imutáveis com base nesse material. Elementos narrativos só passam a
orientar uma feature quando forem explicitamente aprovados e registrados nos artefatos da feature
ou em referência narrativa aprovada.

## Fluxo de Desenvolvimento
O fluxo Spec-Driven Development MUST manter requisitos, especificação, plano, tarefas, implementação
e verificações coerentes. Cada proposta MUST indicar objetivo, componentes e dados afetados,
critérios de aceitação, falhas relevantes e verificações previstas.

Cada Spec e conjunto de tarefas MUST indicar a fase a que pertence, suas dependências, critérios de
saída e evidências requeridas. O plano e a implementação MUST respeitar o bloqueio do Princípio X:
nenhuma tarefa de fase posterior pode ser implementada antes da aprovação baseada em evidências da
fase anterior. Concluir tarefas não remove esse bloqueio.

Decisões técnicas não confirmadas pelos artefatos do projeto MUST ser registradas como propostas nos
documentos da feature antes de orientar a implementação. A revisão MUST avaliar os princípios
aplicáveis e registrar exceções com justificativa, escopo e condição de encerramento.

## Governança
Esta Constitution rege as especificações, planos, implementação e revisão do GESTIX. A versão
3.0.0 é identificada nos registros disponíveis como a última versão aprovada, mas seu texto integral
não foi recuperado; esta Constitution não presume seu conteúdo. As versões 3.1.0, 3.2.0 e 3.3.0
foram revisões pendentes. A equipe aprovou explicitamente o uso da 3.3.0 como texto de trabalho e
aprovou a presente emenda para candidata 4.0.0; isso não ratifica a 3.3.0 nem a 4.0.0. A versão
4.0.0 permanece **candidata à ratificação pelo grupo**. Até a ratificação formal, 3.0.0 permanece a
última versão aprovada conforme os registros, embora sua cópia não esteja disponível. Isso não declara
aprovação do professor. A data formal de ratificação permanece pendente e MUST ser registrada somente
quando definida.

Alterações nesta Constitution MUST ser revisadas como mudanças de governança e atualizar versão,
data de emenda e relatório de impacto. Redefinição incompatível de princípio incrementa MAJOR;
adição de princípio ou expansão material incrementa MINOR; esclarecimentos sem alteração de obrigação
incrementam PATCH. Revisões de features MUST apontar evidências verificáveis de conformidade com
os princípios afetados. Exceções MUST registrar justificativa, escopo e condição para remoção.

**Version**: 4.0.0 | **Status**: Candidata à ratificação pelo grupo | **Ratified**: TODO(RATIFICATION_DATE): data formal pendente | **Last Amended**: 2026-10-29




