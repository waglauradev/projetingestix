# Tasks: Reconhecimento e Diferenciação de Gestos

**Input**: [spec.md](spec.md), [plan.md](plan.md), [research.md](research.md), [data-model.md](data-model.md), [contracts/recognition-result.md](contracts/recognition-result.md), [quickstart.md](quickstart.md)  
**Feature Directory**: `specs/002-reconhecimento-gestos` (identificador de Feature; workspace sem branch Git verificável)  
**Fase**: Fase 1 — Reconhecimento de gestos.  
**Backlog de produto**: [BKL-05 e BKL-18](../../backlog/README.md).  
**Testes**: Incluídos porque FR-013 exige validação reproduzível e o usuário pediu testes unitários/de integração/desempenho. Nenhum teste foi executado ao gerar esta lista.

## Phase 1: Setup

**Purpose**: confirmar o ambiente inexistente e preparar a estrutura proposta no plano, sem introduzir dependências não aprovadas.

- [x] T001 Confirmar versão/runtime Python e convenções de empacotamento do projeto e registrar a decisão ou bloqueio em `specs/002-reconhecimento-gestos/plan.md`. Nenhum runtime/convenção do Gestix existia; Python 3.12.14 bundled foi usado apenas para validação local, sem designá-lo runtime suportado.
- [x] T002 Criar o pacote inicial de reconhecimento conforme a estrutura aprovada em `src/gestix/__init__.py` e `src/gestix/recognition/__init__.py`.
- [x] T003 Criar a estrutura de testes da biblioteca padrão e instruções de fixtures em `tests/recognition/__init__.py` e `tests/recognition/fixtures/README.md`.

## Phase 2: Foundational — contratos e decisões bloqueantes

**Purpose**: registrar decisões que bloqueiam componentes específicos e testes de saída; cada tarefa espera apenas pelas decisões das quais depende.

- [ ] T004 Aprovar e registrar critérios de direção, deslocamento, velocidade, configuração dos dedos e orientação da palma para os dois gestos em `specs/002-reconhecimento-gestos/spec.md`.
- [ ] T005 Acordar com a Feature upstream o schema de landmarks, estado de tracking, coordenadas/unidades, timestamp, ordenação e frequência e atualizar `specs/002-reconhecimento-gestos/contracts/recognition-result.md`.
- [ ] T006 Aprovar escala/limiar de confiança, janela, neutralidade, rearme e deduplicação e registrar os valores no contrato/modelo em `specs/002-reconhecimento-gestos/data-model.md`.
- [ ] T007 Registrar a ratificação da candidata constitucional 4.0.0 quando houver evidência e aprovar modelo OpenAI, payload, ambiente/configuração, timeout, falhas, custos/limites, segurança, privacidade e autorização de transmissão em `specs/002-reconhecimento-gestos/research.md`; nenhuma chamada real ou envio fica habilitado antes dessas aprovações.
- [ ] T008 Aprovar hardware/SO/runtime de avaliação, condições, protocolo e limites numéricos de latência, taxa, precisão/erro, estabilidade e recursos em `specs/002-reconhecimento-gestos/quickstart.md`.

**Checkpoint**: T001–T008 concluídos e bloqueios/aprovações registrados antes das tarefas dependentes. T004–T006 bloqueiam classificação/sessão que dependam dos critérios; T007 bloqueia o adaptador OpenAI e qualquer chamada/transmissão; T008 bloqueia avaliação final de desempenho. Enquanto o verificador estiver desabilitado, nenhum caminho de execução pode produzir `recognized`.

## Phase 3: User Story 1 — Reconhecer e diferenciar os gestos (P1)

**Goal**: classificar corte horizontal e palma estendida por regras matemáticas e rejeitar entradas que não atendem aos critérios aprovados.

**Independent Test**: amostras rotuladas de cada gesto e casos negativos produzem IDs distintos corretos, ou `not_recognized` sem ID acionável, segundo critérios/limiar aprovados.

- [ ] T009 [US1] Criar fixtures sintéticas/processadas rotuladas para os dois gestos e casos negativos, sem frames brutos, em `tests/recognition/fixtures/`.
- [ ] T010 [P] [US1] Escrever testes de entrada válida, ausente, inválida, truncada e insuficiente conforme o schema aprovado em `tests/recognition/test_input_validation.py`.
- [ ] T011 [P] [US1] Escrever testes positivos/negativos de regras por gesto, diferenciação, baixa confiança e mapeamento semântico aprovado em `tests/recognition/test_gesture_rules.py`.
- [ ] T012 [P] [US1] Implementar validação de amostras e estados de tracking sem converter ausência em gesto em `src/gestix/recognition/input_validation.py`.
- [ ] T013 [P] [US1] Implementar catálogo versionado com IDs estáveis e o mapeamento aprovado corte horizontal→ataque com espada e palma à frente→defesa em `src/gestix/recognition/catalog.py`.
- [ ] T014 [US1] Implementar regras matemáticas espaciais/temporais aprovadas, limiar e resultado `not_recognized` para desconhecido/insuficiente/inválido em `src/gestix/recognition/rules.py`.

## Phase 4: User Story 2 — Verificação LLM e reconhecimento contínuo (P1)

**Goal**: aguardar o verificador LLM antes de publicar sucesso, tratar inconsistência/falhas e prevenir eventos duplicados durante a sessão.

**Independent Test**: com regras e verificador determinísticos, só uma classificação elegível seguida de resultado consistente publica `recognized`; inconsistência produz `not_recognized`, falha/timeout produz `unavailable`, e uma execução não duplica evento.

- [x] T015 [P] [US2] Escrever testes do verificador com stub determinístico para `consistent`, `inconsistent`, resposta inválida, ausência e timeout em `tests/recognition/test_consistency_check.py`.
- [ ] T016 [P] [US2] Escrever testes da sessão para gate síncrono, ausência/perda/recuperação de tracking, reinício, oscilação e deduplicação em `tests/recognition/test_session.py`.
- [ ] T017 [US2] Implementar o adaptador lógico do verificador da OpenAI API conforme modelo/payload/configuração aprovados em T007, mantendo chamadas reais desabilitadas por padrão e falhando fechado em resposta inválida, timeout, indisponibilidade ou erro de comunicação, em `src/gestix/recognition/consistency_check.py`.
- [ ] T018 [US2] Implementar fluxo de sessão que combina validação, regras, verificador síncrono, estados de falha e no máximo um resultado por execução em `src/gestix/recognition/session.py`.
- [ ] T019 [US2] Executar e registrar testes de verificação/sessão sem rede ou credenciais reais, incluindo verificador desabilitado, erro, timeout e resposta malformada, em `specs/002-reconhecimento-gestos/quickstart.md`.
- [ ] T020 [US2] Após T007 e T017, testar o adaptador com transporte simulado e respostas válidas/inválidas conforme contrato OpenAI aprovado, sem credenciais, rede real ou transmissão de dados, em `tests/recognition/test_openai_adapter.py`.

## Phase 5: User Story 3 — Disponibilizar resultado lógico consistente (P1)

**Goal**: fornecer ao consumidor um estado tipado e estável, sem implementar transporte nem ações no Unity.

**Independent Test**: testes de contrato demonstram que `recognized` inclui exatamente um ID aprovado e que `not_recognized`/`unavailable` não contêm ID acionável; consumidor pode validar os três estados sem reinterpretar landmarks.

- [x] T021 [P] [US3] Escrever testes de invariantes do resultado para `recognized`, `not_recognized` e `unavailable`, campos condicionais e estado/motivo inválido em `tests/recognition/test_result_contract.py`.
- [x] T022 [US3] Implementar tipo de resultado e validação dos invariantes lógicos, sem campo de comando Unity, em `src/gestix/recognition/result.py`.
- [ ] T023 [US3] Atualizar o contrato lógico com nomes/campos finais do runtime aprovado, mapeamento semântico e responsabilidades do consumidor em `specs/002-reconhecimento-gestos/contracts/recognition-result.md`.

## Phase 6: Polish, validação de fronteiras e gate da Fase 1

**Purpose**: reunir evidências reproduzíveis do reconhecedor e submeter apenas os critérios atendidos à revisão formal.

- [x] T024 Executar a suíte unitária reproduzível com o runtime local e registrar comandos/resultados reais em `specs/002-reconhecimento-gestos/quickstart.md`. O runtime do produto continua pendente.
- [ ] T025 Quando as Features upstream estiverem disponíveis, testar a fronteira com amostras OpenCV/MediaPipe/preparação e estados de câmera/tracking em `tests/recognition/test_vision_boundary.py`; registrar dependências e condições em `specs/002-reconhecimento-gestos/quickstart.md`.
- [ ] T026 Quando o uso real da OpenAI API estiver aprovado e habilitado, medir latência total incluindo LLM, tempos separados de regras/verificador, frequência, fila/perdas e métricas de classificação sob condições aprovadas e registrar dados permitidos em `specs/002-reconhecimento-gestos/quickstart.md`; se continuar desabilitado, registrar a medição do provedor como pendente, sem simular resultado real.
- [ ] T027 Medir CPU/memória/GPU durante repouso e carga com ferramentas aprovadas e registrar dispositivo, método e resultados em `specs/002-reconhecimento-gestos/quickstart.md`.
- [ ] T028 Corrigir falhas de reconhecimento encontradas, repetir apenas os testes afetados e registrar cada resultado sem presumir sucesso em `specs/002-reconhecimento-gestos/quickstart.md`.
- [ ] T029 Conferir os oito critérios constitucionais de saída da Fase 1, identificar evidências upstream que faltam e registrar a situação real em `specs/002-reconhecimento-gestos/quickstart.md`.
- [ ] T030 Solicitar aprovação formal de saída somente se todos os critérios aplicáveis tiverem evidência e registrar a decisão em `specs/002-reconhecimento-gestos/quickstart.md`.

## Dependencies & Execution Order

- **Setup (Phase 1)**: T001 confirma ambiente; T002/T003 criam esqueletos em arquivos diferentes e podem ocorrer em paralelo depois de T001.
- **Foundational (Phase 2)**: T004–T008 bloqueiam os componentes que dependem dessas decisões; T007 bloqueia adaptador e qualquer chamada/transmissão, não a implementação isolada das regras matemáticas. T005 depende de acordo upstream; T008 depende de limites aprovados, não inventados.
- **US1**: T009 precede fixtures; T010/T011 podem ser escritos em paralelo após critérios/schema; T012/T013 são arquivos independentes e podem ser paralelos; T014 depende da validação e catálogo.
- **US2**: T015/T016 são testes em arquivos distintos e podem ser paralelos após os contratos aplicáveis; T017 e T020 dependem das aprovações de T007; T018 depende de US1 e T017; T019 depende de T015–T018; T020 valida o adaptador sem rede real.
- **US3**: T021 pode ser desenvolvido em paralelo com T015/T016 após aprovação do contrato; T022 segue o teste; T023 fecha o contrato com a implementação.
- **Gate**: T024–T030 dependem das stories. T025 depende de captura/detecção/preparação upstream; sem esses componentes, a cobertura de integração da Fase 1 permanece pendente. A fase só avança após evidência e aprovação formal.
- **Unity**: não há tarefas de protocolo Python–Unity, recepção de comandos ou execução de ações nesta lista. São Fase 2 e permanecem bloqueadas pela saída aprovada da Fase 1; T023 deixa a fronteira lógica documentada.

## Parallel Opportunities

- T002 e T003 podem ocorrer após T001 em diretórios distintos.
- T010 e T011 (testes independentes) podem ser escritos em paralelo após T004/T005; T012 e T013 (validação/catálogo) podem ser implementados em arquivos diferentes.
- T015 e T016 são arquivos de teste separados; T021 é independente após o contrato lógico estar aprovado. T020 segue T007/T017 e usa apenas transporte simulado.
- Não paralelizar alterações na mesma spec/contrato nem decisões de T004–T008 que dependam de aprovação conjunta.

## Implementation Strategy

**Incremento de validação inicial**: US1 comprova os classificadores matemáticos e casos negativos em fixtures. Isso não libera resultado reconhecido nem encerra a Feature: US2 é obrigatório para a verificação LLM síncrona, e US3 para a saída estável. Depois, as fronteiras upstream e as métricas reais devem produzir evidência.

**MVP da Feature**: US1 + US2 + US3 concluídas e verificadas. A Feature ainda não conclui sozinha a Fase 1 constitucional se captura/detecção/preparação e critérios globais não tiverem evidência. Não incluir Unity/Fase 2 até aprovação formal da Fase 1.

## Pendências e escopo não incluído

- Critérios geométricos, input schema, confidence/segmentação, modelo/payload/configuração/timeouts/custos/privacidade OpenAI, ambiente e limites de desempenho aparecem como bloqueios em T004–T008; nenhum valor foi inventado.
- Implementação da câmera/OpenCV, detecção/rastreamento MediaPipe e preparação pertence às Features upstream; este plano só testa a fronteira quando esses componentes existirem.
- OpenAI API é o provedor-alvo declarado; a candidata constitucional 4.0.0 continua sem ratificação e a 3.0.0 não foi localizada. T007 registra essa dependência sem alterar a Constitution. Chamadas/transmissão ficam desligadas até aprovações específicas.
- Protocolo Python–Unity, recebimento/ack/retry/reconexão, feedback visual e ações no jogo são da Feature/Fase 2. Não implementar antes da aprovação da Fase 1.
- O plano propõe `src/gestix/recognition/`, mas o repositório não contém ainda código, runtime ou convenções Python; T001 deve confirmar antes de criar módulos.

## Format Validation

Todas as 30 tarefas usam checkbox, ID sequencial, `[P]` apenas em atividades paralelizáveis, `[US1]`/`[US2]`/`[US3]` nas fases de histórias e caminho concreto. Tarefas Setup, Fundacionais e Gate não levam etiqueta de história.


