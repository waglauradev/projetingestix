# Research: Reconhecimento e Diferenciação de Gestos

## Fontes consultadas

- `.specify/memory/constitution.md` — candidata 4.0.0, ainda não ratificada; registra a proposta OpenAI API. O próprio documento informa que a base 3.0.0 ratificada não foi recuperada. A ausência de `.git` impede verificar histórico, tags e branches.
- `specs/002-reconhecimento-gestos/spec.md` — requisitos atuais e respostas do Clarify; fonte de verdade desta Feature.
- `Diagrama de arquitetura - Gestix.png` — referência visual existente que ainda mostra OpenCV → MediaPipe → Processamento → Gemini API → Unity. Não foi alterada; a candidata constitucional propõe OpenAI API e a divergência deve ser resolvida em atualização visual separada. Também mostra monitoria web/PostgreSQL, cuja aplicabilidade ao jogo não está confirmada.
- `backlog/README.md` — catálogo vigente com BKL-05 para reconhecimento e BKL-18 para validação. O Word anterior foi preservado em `output/archive/` como registro histórico, não como plano vigente.
- `specs/001-pesquisa-base-narrativa/spec.md` — Feature existente sem equivalência de reconhecimento.
- O repositório não contém código Python, projeto Unity, `src/`, configuração de dependências ou testes de runtime; contém documentação, Spec Kit, diagrama e backlog documental.
- A leitura do estado Git falhou porque o workspace não tem metadados `.git`; `002-reconhecimento-gestos` é o identificador da Feature/diretório retornado pelo Spec Kit, não uma branch Git verificada.
- `sdd-demo/` — cópia demonstrativa do Spec Kit; não é estrutura de código do produto.

## Clarificações aplicadas

- A equipe aprovou para esta Feature o mapeamento corte horizontal → ataque com espada e palma estendida para a frente → defesa. Isso não ratifica a Constitution 3.3.0 inteira.
- As regras matemáticas classificam. O LLM só sinaliza inconsistências; o resultado positivo espera a checagem LLM. Inconsistência impede reconhecimento; falha/timeout impede emissão de resultado acionável.
- A Feature fornece estados lógicos; a Feature Unity/integração apresenta reconhecimento/não reconhecimento/indisponibilidade ao jogador.
- Metas numéricas continuam pendentes conforme a Spec. Formato de landmarks e protocolo Python–Unity são interfaces de Features dependentes.
- O solicitante declara que o grupo aprovou substituir Gemini pela plataforma de API da OpenAI como provedor do verificador. A busca no repositório não localizou evidência formal; nenhum dado sobre data, participantes ou votação foi inferido. A candidata constitucional 4.0.0 nomeia OpenAI API, mas não está ratificada e a versão-base 3.0.0 não foi recuperada.
- O alvo documental para a Feature é OpenAI API. Modelo, payload, ambiente/configuração, timeouts, falhas, custos/limites, segurança, privacidade e transmissão continuam pendentes. Chamadas reais e envio de dados permanecem desabilitados até aprovação específica.

## Decisions

### D-001: Regras matemáticas são a fonte da classificação

Aplicar regras espaciais/temporais aprovadas sobre landmarks processados para produzir classe e confiança. Não escolher nem treinar ML. O LLM não classifica, não escolhe ações e não pode elevar entrada rejeitada.

**Rationale**: atende à regra vigente da Constitution de começar por matemática, mantém comportamento determinístico testável e evita inferir classes/comandos de uma resposta generativa.

### D-002: LLM como verificador síncrono de inconsistência

Para uma classificação matemática elegível, consultar de forma síncrona o verificador OpenAI quando a configuração estiver aprovada e habilitada. Só publicar `recognized` após resposta válida sem inconsistência. Inconsistência resulta `not_recognized`; timeout, ausência, falha de comunicação, resposta inválida ou verificador desabilitado resulta `unavailable`. O tempo de espera faz parte da latência observada. A chamada real permanece desligada até as aprovações específicas.

**Rationale**: segue as respostas do Clarify e evita publicar comando válido antes do resultado do componente obrigatório. O tempo limite numérico e detalhes da resposta ainda dependem de aprovação.

### D-003: Sem chamada externa habilitada sem decisão de privacidade

O diagrama legado mostra Gemini API; o alvo declarado pela equipe é OpenAI API. O fluxo/payload não está documentado e o processamento local permanece padrão. O papel lógico é registrado; chamadas/transmissão não podem ser habilitadas até aprovação de ambiente, dados processados, finalidade, falhas, segurança, privacidade, custos e proteção. Não persistir frames/landmarks brutos.

**Rationale**: a tecnologia está confirmada pelo baseline, mas isso não autoriza transmissão de movimento. Esta decisão mantém explícito o gate, em vez de presumir API local ou remota.

### D-004: OpenAI API como provedor-alvo declarado, sujeita à ratificação e configuração

O solicitante declara que o grupo aprovou substituir Gemini pela plataforma de API da OpenAI. Nenhum registro formal foi localizado; esta origem é atribuída ao solicitante, sem inventar data/participantes/votos. A candidata 4.0.0 já presente no workspace registra a mudança, mas não está ratificada; a Constituição 3.0.0 ratificada e o histórico Git não foram recuperados. O modelo, SDK, endpoint, payload, ambiente, parâmetros, custo e política de dados não foram selecionados. Nenhuma chamada real ou transmissão fica habilitada.

### D-005: Contratos lógicos separados do transporte

Entrada exige amostra processada e estado de tracking, mas schema/coordenação/tempo/frequência vêm da Feature upstream. Saída é `RecognitionResult`; protocolo, serialização, garantia de entrega e recuperação Python–Unity pertencem à Fase 2. Nenhum protocolo foi escolhido.

### D-006: Mapeamento aprovado, comando de transporte pendente

O mapa semântico aprovado é corte horizontal → ataque com espada e palma à frente → defesa. A Feature identifica o gesto; o consumidor Unity traduz para eventos/ações no protocolo aprovado. IDs wire e nomes de comandos ainda não foram aprovados.

### D-007: Testes sem nova dependência runtime

Propor `unittest` da biblioteca padrão para regras, validação, sessão e contrato. Um stub determinístico e mocks do adaptador OpenAI simulam respostas sem rede ou dados reais. Teste real com OpenAI só após aprovação de modelo, payload, ambiente, credenciais, custos, segurança, privacidade e transmissão. Não há projeto/test runner atual; confirmar convenções quando o código for criado.

## Alternativas consideradas

- **LLM escolhe classe e matemática valida**: rejeitada; contradiz Clarify, que atribui a classificação às regras e restringe o LLM a sinalizar inconsistências.
- **Publicar classe matemática antes da resposta LLM**: rejeitada; Clarify exige aguardar, pois ação poderia ser publicada antes de uma inconsistência conhecida.
- **Selecionar protocolo de rede agora**: adiado; comunicação Python–Unity é Fase 2 e contrato upstream/runtime ausentes.
- **Escolher modelo específico da OpenAI API**: adiado até decisão aprovada; a escolha do provedor não determina modelo, endpoint ou parâmetros.
- **Adicionar ML/framework de teste**: não justificado pelo repositório ou evidência de testes; regras matemáticas e biblioteca padrão bastam para o desenho atual.

## Decisões e dependências pendentes

- Ratificação da candidata constitucional 4.0.0 e recuperação da base 3.0.0 ratificada ou registro formal de sua indisponibilidade. O solicitante declarou aprovação do grupo para trocar Gemini por OpenAI API, sem evidência formal encontrada localmente.
- Modelo OpenAI, payload mínimo, ambiente/configuração, timeout, falhas, custos/limites, acesso/segurança/privacidade e autorização para transmissão. Chamadas reais permanecem desabilitadas.
- Critérios geométricos e temporais completos dos dois gestos; escala/limiar de confiança; segmentação, neutralidade e rearme.
- Schema upstream dos landmarks, coordenadas/unidades, timestamps, ordenação e frequência.
- Hardware/SO/runtime suportados e limites aprovados de latência, taxa, falsos positivos/negativos, estabilidade e recursos.
- Contrato serializado, protocolo, entrega/ack/retry para Python–Unity na Feature de integração.
- Estrutura e runtime Python/test runner reais quando o código da aplicação existir.
- Consulta externa ao Bit não foi possível na etapa de criação; a ausência de duplicação foi verificada apenas nas Specs locais.
