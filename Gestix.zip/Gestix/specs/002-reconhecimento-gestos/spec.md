# Feature Specification: Reconhecimento e Diferenciação de Gestos

**Feature Branch**: `002-reconhecimento-gestos`  
**Created**: 2026-10-29  
**Status**: Draft — documentação da Fase 1; implementação depende de aprovações e evidências  
**Backlog**: [BKL-05 e BKL-18](../../backlog/README.md)  
**Input**: User description: Especificar reconhecimento em tempo real dos gestos comuns definidos pela equipe, receber dados processados da visão computacional, diferenciar resultados, rejeitar entradas sem confiança suficiente e disponibilizar um resultado consistente ao componente de integração.

## User Scenarios & Testing

### User Story 1 — Reconhecer os gestos comuns da fase inicial (Priority: P1)

Como jogador, quero que o sistema reconheça os gestos da fase inicial enquanto jogo, para que movimentos válidos possam ser disponibilizados como eventos identificáveis.

**Why this priority**: Reconhecimento e diferenciação são a Fase 1 bloqueante da Constitution candidata 4.0.0 no workspace. A base ratificada 3.0.0 não foi recuperada; esta documentação não afirma que 4.0.0 foi ratificada. Sem essa capacidade validada, as fases posteriores não podem ser implementadas.

**Independent Test**: Reproduzir entradas processadas rotuladas para cada gesto da fase inicial e para movimentos inválidos, comparar classificação/estado retornado com o rótulo esperado e registrar as condições da execução.

**Acceptance Scenarios**:

1. **Given** uma sequência de dados processados válida que corresponde ao corte horizontal definido pela equipe, **When** as regras matemáticas classificam o movimento e o LLM conclui a verificação sem sinalizar inconsistência, **Then** o reconhecedor devolve o identificador estável do gesto de corte horizontal e um resultado válido conforme o limiar aprovado.
2. **Given** dados processados válidos que correspondem à palma estendida para a frente, **When** as regras matemáticas classificam o movimento e o LLM conclui a verificação sem sinalizar inconsistência, **Then** o reconhecedor devolve o identificador estável desse gesto e o estado de reconhecimento válido conforme o limiar aprovado.
3. **Given** movimentos válidos de ambos os gestos, **When** forem avaliados sob as condições documentadas, **Then** os resultados identificam gestos distintos e não trocam suas classes nos casos cobertos pelos testes aprovados.
4. **Given** uma entrada incompleta, inválida, ambígua ou abaixo do limiar aprovado, **When** ela for avaliada, **Then** o resultado não é um gesto válido e não pode gerar comando.

### User Story 2 — Manter reconhecimento contínuo e estável durante a partida (Priority: P1)

Como jogador, quero que o reconhecimento acompanhe a entrada continuamente durante um confronto, para que a análise não dependa de uma única amostra e não emita eventos duplicados ou inconsistentes.

**Why this priority**: A experiência de tempo real é necessária à Fase 1 e a Constituição exige lidar com diferentes velocidades, posições, iluminação, perda de rastreamento e duplicidade.

**Independent Test**: Reproduzir sessões contínuas documentadas contendo execuções válidas e inválidas, variações de velocidade/posição/iluminação e pausas de detecção; verificar estados, transições e eventos emitidos.

**Acceptance Scenarios**:

1. **Given** uma sessão ativa e entradas processadas sucessivas, **When** cada entrada chegar, **Then** o reconhecedor mantém avaliação contínua e emite resultados identificáveis sem depender do Unity.
2. **Given** ausência temporária das mãos ou perda de rastreamento, **When** ocorrer, **Then** o estado não é reportado como gesto reconhecido, não gera comando e pode voltar a reconhecer após dados válidos.
3. **Given** observações inconsistentes ou ambíguas para um mesmo movimento, **When** o reconhecedor não conseguir confirmar um resultado, **Then** retorna não reconhecido/insuficiente e não emite duplicata.
4. **Given** uma execução única de gesto, **When** seus dados forem avaliados ao longo da janela de reconhecimento, **Then** no máximo um evento válido referente àquela execução é disponibilizado, conforme a regra de segmentação aprovada.

### User Story 3 — Consumir resultado de reconhecimento com formato consistente (Priority: P1)

Como componente de integração, quero receber um resultado tipado e consistente do reconhecimento, para que possa decidir o tratamento posterior sem reinterpretar dados de visão computacional.

**Why this priority**: A interface entre reconhecimento e integração deve ser testável, mantendo Unity e transporte fora da responsabilidade desta Feature.

**Independent Test**: Validar resultados reconhecidos, não reconhecidos e indisponíveis contra o contrato lógico desta Feature, incluindo campos obrigatórios, identificadores e tratamento de resposta malformada.

**Acceptance Scenarios**:

1. **Given** um gesto reconhecido e validado, **When** o resultado for publicado ao consumidor, **Then** inclui identificador estável do gesto e os metadados de observação definidos no contrato.
2. **Given** um gesto desconhecido, dados insuficientes, confiança abaixo do limiar ou falha tratável, **When** o resultado for publicado, **Then** o estado deixa claro que nenhum gesto válido está disponível e não fornece identificador de comando.
3. **Given** uma resposta ausente, malformada ou ambígua de uma etapa do fluxo de reconhecimento, **When** ela for processada, **Then** não se converte em gesto válido nem em evento acionável.

### Edge Cases

- Frame/registro processado vazio, nulo, truncado, com dimensão ou valores fora do domínio declarado pela interface de entrada.
- Nenhuma mão detectada, uma mão parcialmente rastreada, perda intermitente e recuperação de rastreamento.
- Mãos sobrepostas, gesto incompleto, movimento entre classes, execução fora do enquadramento ou fora das condições cobertas.
- Movimento não pertencente ao catálogo, combinação ambígua ou sequência cujo estado de confiança oscile ao redor do limiar.
- Entradas duplicadas, fora de ordem ou com identificador temporal ausente; política de ordenação/deduplicação depende do contrato upstream.
- Resultado do LLM ausente, atrasado, inválido, ambíguo ou com sinal de inconsistência; enquanto a verificação não terminar não se publica reconhecimento válido, e falha/timeout resulta em estado não acionável.
- Encerramento/reinício da sessão durante uma janela de reconhecimento; não transportar estado parcial para nova sessão sem regra aprovada.
- Falha de reconhecimento contínuo não interrompe o produtor de captura, cuja recuperação pertence à Feature de captura.

## Clarifications

### Session 2026-10-29

- Q: Quais metas numéricas devem limitar latência, estabilidade e confiabilidade? → A: Permanecem decisões pendentes; esta especificação define métricas e método de medição sem inventar limites.
- Q: Qual deve ser o papel operacional do Gemini e quais dados podem ser enviados a ele? → A: Na sessão de 2026-10-29, ChatGPT/OpenAI foi registrado como substituto pretendido, ainda sujeito a aprovação constitucional. Essa posição histórica foi atualizada pelo adendo de 2026-11-11 abaixo; a decisão registrada não autoriza envio de dados.
- Q: Quais são o formato de entrada processada, a regra temporal de segmentação e o contrato de transporte para o consumidor? → A: O produtor e a integração devem acordar contratos nas Features dependentes; esta Feature define somente o contrato lógico de resultado e registra os detalhes de transporte como pendentes.
- Q: A equipe aprovou para esta Feature o mapeamento da Constitution 3.3.0 — corte horizontal para ataque com espada e palma estendida para defesa? → A: Sim. A equipe aprovou esse mapeamento para esta Feature; isso não ratifica a Constitution 3.3.0 por inteiro nem define outras regras de gameplay.
- Q: No fluxo de reconhecimento, que papel o LLM deve exercer além de ser a tecnologia do projeto? → A: As regras matemáticas classificam o gesto; o LLM apenas sinaliza inconsistências. Uma inconsistência, resposta inválida ou indisponibilidade do LLM não pode produzir um resultado reconhecido.
- Q: O reconhecedor deve aguardar a verificação de consistência do LLM antes de publicar um gesto como reconhecido? → A: Sim. Só publica reconhecimento após as regras matemáticas classificarem o gesto e o LLM concluir a verificação sem inconsistência. Uma inconsistência ou falha/timeout do LLM produz resultado não acionável.
- Q: Onde deve ficar a apresentação ao jogador de reconhecimento, não reconhecimento e indisponibilidade? → A: A Feature de Unity/integração apresenta o feedback; esta Feature fornece os estados lógicos.

### Session 2026-11-11 — adendo sobre o provedor LLM

- O solicitante declara que o grupo aprovou substituir Gemini pela plataforma de API da OpenAI como provedora do verificador de inconsistências. A busca nos arquivos disponíveis não localizou ata ou outro registro formal dessa aprovação; não foram inferidos data da decisão, participantes ou votação.
- A Constitution 4.0.0 disponível no workspace está marcada como candidata à ratificação. A versão 3.0.0 ratificada não foi localizada e não há histórico Git acessível neste workspace. Portanto, esta Spec registra OpenAI API como provedor-alvo declarado, sujeito à ratificação constitucional, sem afirmar que a versão 4.0.0 foi ratificada.
- Modelo, payload, configuração/ambiente, timeout, falhas, custos, limites de uso, privacidade e autorização de transmissão continuam pendentes. Chamadas reais e envio de dados à API permanecem desabilitados até aprovação específica.

## Requirements

### Functional Requirements

- **FR-001**: O reconhecedor MUST receber dados processados de mãos/pontos de referência do componente de visão computacional através de uma interface validável; captura, detecção e preparação desses dados pertencem às Features upstream.
- **FR-002**: O sistema MUST reconhecer os gestos comuns aprovados para a fase inicial: corte horizontal e palma estendida para a frente, usando os critérios geométricos e temporais que forem aprovados antes da implementação.
- **FR-003**: A especificação MUST registrar critérios verificáveis para direção, deslocamento, velocidade, configuração dos dedos e orientação da palma de cada gesto; os valores/limites ainda não definidos permanecem como decisões pendentes, não como critérios inventados.
- **FR-004**: O sistema MUST diferenciar os gestos válidos e atribuir identificadores estáveis e únicos por gesto; IDs identificam gestos e não definem por si sós mapeamento para ações do jogo.
- **FR-005**: O sistema MUST produzir estado não reconhecido quando a entrada for desconhecida, insuficiente, ambígua, inválida ou abaixo do limiar de confiança aprovado.
- **FR-006**: Somente resultado classificado pelas regras matemáticas, validado pelo LLM sem sinal de inconsistência e acima do limiar aprovado pode conter um identificador de gesto válido; enquanto a validação não terminar, outros estados MUST NOT incluir identificador acionável.
- **FR-007**: O sistema MUST fornecer resultados por interface lógica definida em `contracts/recognition-result.md`, para consumo do componente de integração. Esta Feature não apresenta feedback visual ao jogador; a Feature de integração/Unity apresenta os estados reconhecido, não reconhecido e indisponível ao jogador, conforme decisão confirmada pela equipe. Protocolo, transporte, entrega e ação no Unity pertencem à Feature de integração.
- **FR-008**: O reconhecimento MUST funcionar continuamente enquanto a sessão de jogo estiver ativa, processando amostras sucessivas e mantendo estado de sessão isolado.
- **FR-009**: O sistema MUST tratar entrada inválida, ausência temporária das mãos, perda de rastreamento e resultados inconsistentes sem reportar sucesso indevido, com retorno recuperável após entrada válida.
- **FR-010**: O sistema MUST prevenir eventos duplicados para uma execução de gesto, segundo regra de início/fim/retorno à neutralidade a aprovar antes da implementação.
- **FR-011**: O reconhecimento MUST iniciar por regras matemáticas sobre pontos de referência e movimento detectado. Um modelo de aprendizado de máquina só pode ser proposto se testes documentados demonstrarem insuficiência das regras e se o plano receber aprovação da equipe.
- **FR-012**: O provedor-alvo declarado para o verificador de inconsistências é a plataforma de API da OpenAI, conforme declaração do solicitante de que o grupo aprovou a substituição do Gemini; a ratificação constitucional permanece pendente e a evidência formal dessa aprovação não foi localizada no repositório. Python e suas regras matemáticas são a única autoridade de classificação inicial. O LLM MUST apenas sinalizar inconsistências e MUST NOT escolher ou alterar classe, criar gesto, comando ou ação. O reconhecedor MUST aguardar a verificação antes de publicar `recognized`. Inconsistência MUST resultar em `not_recognized`; resposta inválida, ausência, timeout, falha de comunicação ou API desabilitada MUST resultar em `unavailable`, sem identificador acionável. Modelo, payload, ambiente/configuração, timeout, custos, limites de uso, segurança, privacidade e autorização para transmissão continuam pendentes. Chamadas reais e envio de dados à API MUST permanecer desabilitados até aprovação específica e documentação dessas decisões.
- **FR-013**: O reconhecimento MUST ser avaliado por testes reproduzíveis com entradas rotuladas, casos negativos e condições de execução documentadas; nenhum resultado de teste pode ser presumido.
- **FR-014**: A Feature MUST definir os identificadores de gesto sem definir ou alterar associações além das aprovadas: corte horizontal corresponde ao ataque com espada e palma estendida para a frente corresponde à defesa, conforme a equipe confirmou para esta Feature. O transporte do comando e o comportamento observável no Unity pertencem à Feature de integração e às regras de gameplay aprovadas.
- **FR-015**: A Feature MUST NOT implementar captura de vídeo, detecção MediaPipe, preparação/normalização dos dados, treinamento de base/modelo, transporte Python-Unity, feedback visual no jogo ou regras de gameplay.
- **FR-016**: A Feature MUST processar movimento localmente por padrão, não persistir frames brutos e limitar dados temporários à sessão e finalidade de reconhecimento documentadas.

### Non-Functional Requirements

- **NFR-001 Latência**: Medir tempo da disponibilidade da amostra processada até o resultado final, incluindo a espera pela verificação do LLM; registrar também, separadamente, duração das regras matemáticas e duração da verificação do LLM, com distribuições e percentis por gesto/estado, em hardware e condições documentados. Limite aceitável permanece pendente e deve ser aprovado antes dos testes de saída da Fase 1.
- **NFR-002 Taxa de processamento/tempo real**: Registrar frequência de entrada, frequência de resultados, amostras descartadas e atraso acumulado em sessão contínua; comparar com a frequência e o orçamento temporal definidos pela equipe. Metas numéricas pendentes.
- **NFR-003 Confiabilidade**: Em conjunto de teste rotulado, medir matriz de confusão por gesto, precisão, recall, falsos positivos de gesto válido em entradas negativas, falsos negativos e taxa de resultados insuficientes. Limites de aceitação pendentes.
- **NFR-004 Estabilidade**: Executar sessões contínuas sob diferentes velocidades, posições e iluminação, registrar interrupções, oscilações de classe, duplicatas, recuperação após ausência/perda de rastreamento e evolução de latência/recursos. Duração/limites de estabilidade pendentes.
- **NFR-005 Manutenibilidade**: Catálogo, IDs, critérios de gesto, limiar e regra de segmentação devem ser documentados e rastreáveis; alteração em gesto/contrato deve atualizar spec, plano, testes e contrato sem alterar responsabilidades externas.
- **NFR-006 Recursos computacionais**: Medir uso de CPU, memória e, se aplicável, GPU durante repouso e reconhecimento sustentado, registrar dispositivo/configuração e comparar com orçamento a aprovar. Não há orçamento numérico definido.
- **NFR-007 Privacidade e resiliência**: Processar localmente por padrão, não persistir imagens sem requisito aprovado e tratar ausência/falha de componente sem emitir resultado válido indevido. Qualquer dependência de rede deve ser documentada e aprovada.

### Key Entities

- **Entrada processada de mão**: Amostras estruturadas entregues pela Feature upstream; campos, unidades, sistema de coordenadas, frequência e tratamento de timestamps são dependências contratuais pendentes.
- **Catálogo de gestos**: Conjunto versionado de gestos suportados, critérios reconhecíveis aprovados e IDs estáveis.
- **Resultado de reconhecimento**: Estado (`recognized`, `not_recognized`, `unavailable`), identificador de gesto opcional apenas quando válido, confiança opcional e metadados da amostra/sessão conforme contrato lógico.
- **Execução de gesto**: Intervalo de observações tratado como um gesto; regra de início, término, neutralidade e deduplicação pendente de validação.
- **Execução de avaliação**: Registro reproduzível do conjunto rotulado, configuração, ambiente, condições e métricas medidas; não implica persistir frames brutos.

## Success Criteria

### Measurable Outcomes

- **SC-001**: Em testes rotulados aprovados, cada gesto contemplado pelo catálogo produz o ID previsto nos casos que satisfazem os critérios geométricos e temporais aprovados; a cobertura de casos e resultados é registrada.
- **SC-002**: Testes com cada par de gestos distintos contemplados verificam separação de IDs, e os erros por par ficam registrados em matriz de confusão; limites de erro permanecem pendentes de aprovação.
- **SC-003**: 100% dos casos de entrada desconhecida, insuficiente, inválida, ambígua e abaixo do limiar no conjunto negativo de teste retornam estado não acionável e nenhum ID válido.
- **SC-004**: 100% dos resultados publicados nos testes obedecem ao contrato lógico, incluindo estados reconhecido/não reconhecido/indisponível e regras de campos opcionais.
- **SC-005**: Cada cenário de validação pode ser reproduzido a partir de entradas rotuladas e condições/configuração documentadas, com resultados e métricas arquivados sem presumir aprovação.
- **SC-006**: O relatório de avaliação de tempo real registra latência total até o resultado (incluindo LLM), tempos separados de regras e verificação do LLM, taxa de processamento, falhas/perda, duplicatas e recursos computacionais em condições documentadas, e compara os resultados com limites previamente aprovados; os próprios limites numéricos seguem pendentes.
- **SC-007**: A saída da Fase 1 só é proposta quando houver evidência dos oito critérios de conclusão da Constitution; esta documentação não declara a Fase 1 implementada nem aprovada.

## Assumptions

- O catálogo inicial limita-se aos dois gestos previstos no texto constitucional candidato 4.0.0: corte horizontal e palma estendida para a frente. A versão 3.3.0 é histórica e permaneceu em revisão; 3.0.0 é a última versão ratificada registrada, mas seu texto não foi recuperado. A aplicabilidade das decisões ao texto ratificado precisa ser confirmada antes da aprovação formal da Fase 1.
- A apresentação de backlog local contém GES-07 (reconhecer), GES-08 (validar/apresentar resultado) e GES-09 (acionar Unity); esta Feature detalha GES-07/08 e mantém GES-09 fora de escopo. Essas histórias no backlog não são uma spec equivalente.
- Para esta Feature, a equipe confirmou o mapeamento corte horizontal → ataque com espada e palma estendida para a frente → defesa, conforme a Constitution 3.3.0. Isso não aprova o restante da versão 3.3.0 nem cria outros mapeamentos.
- Python mantém as regras matemáticas e a autoridade da classificação inicial; a plataforma de API da OpenAI é o provedor-alvo declarado para verificação secundária, sujeito à ratificação constitucional e às aprovações operacionais. O modelo específico e qualquer chamada real permanecem pendentes.
- Formato concreto dos landmarks de entrada, confiança, limiares, segmentação, hardware suportado, metas quantitativas, modelo, payload, configuração, timeout, custos, segurança, privacidade e política de transmissão ainda não foram aprovados.
- A interface do componente consumidor será validada logicamente; transporte e garantias de entrega serão especificados pela Feature de integração.
- A equipe confirmou que a apresentação ao jogador dos estados reconhecido, não reconhecido e indisponível pertence à Feature de integração/Unity; essa Feature deverá atender à Constitution.

## Dependencies, Phase & Exit Criteria

- **Fase**: Fase 1 — Reconhecimento de gestos, prioritária e bloqueante.
- **Dependências**: captura OpenCV, detecção/rastreamento MediaPipe, processamento/preparação de dados e critérios de gameplay aprovados; seus contratos de entrada são pré-requisitos e não são implementados aqui. O consumidor desta saída pertence à futura Feature de integração Python-Unity.
- **Decisões bloqueantes**: ratificação constitucional da candidata 4.0.0; critérios mensuráveis dos dois gestos; contrato de entrada; limiar de confiança; política de segmento/deduplicação; limites de desempenho; modelo OpenAI, payload, configuração, timeout, custos, segurança, privacidade e autorização de transmissão. Até as aprovações operacionais, chamadas reais à API permanecem desabilitadas e o sistema não pode publicar `recognized` sem verificação habilitada e consistente.
- **Saída**: somente após evidências dos oito critérios de conclusão da Constitution (gestos implementados, critérios documentados, testes positivos/negativos, diferenciação validada, problemas críticos corrigidos, resultados registrados, aceitação atendida e aprovação formal baseada em evidências). Esta Feature não autoriza a Fase 2.
