# Guia de validação: Reconhecimento de Gestos

Este roteiro separa verificações locais executadas do que ainda depende de integrações/decisões externas. Os limites em aberto devem ser aprovados antes de usar resultados como gate da Fase 1.

## Pré-condições

1. Verificar o estado da candidata constitucional 4.0.0 e registrar a evidência de ratificação quando existir. O solicitante declarou aprovação do grupo para OpenAI API, mas nenhum registro formal foi localizado no repositório; a Constituição 3.0.0 ratificada também não foi recuperada.
2. Aprovar critérios espaciais/temporais dos dois gestos, mapeamento de confiança, segmentação, neutralidade, rearme e deduplicação.
3. Aprovar schema upstream de landmarks/status/timestamp, coordenadas, unidades, frequência e ordenação.
4. Antes de qualquer teste real, aprovar modelo OpenAI, payload mínimo, ambiente/configuração, timeout, falhas, custos/limites, segurança, privacidade e autorização de transmissão. Chamadas reais e envio de dados à API permanecem desabilitados até essas aprovações.
5. Aprovar hardware/SO/runtime, corpus/roteiro, duração, condições e limites numéricos de latência, taxa, erro e recursos.
6. O workspace não define runtime Python de produto ou convenção de empacotamento. Nesta implementação local, os testes foram executados com Python 3.12.14 do runtime bundled do Codex e `PYTHONPATH=src`; isto não estabelece o runtime suportado do Gestix. Com `python` disponível no ambiente do produto, PowerShell: `$env:PYTHONPATH = (Join-Path (Get-Location) 'src'); python -m unittest discover -s tests/recognition -v`.

## Testes previstos

### 1. Validação e regras matemáticas (isolados)

- Usar fixtures rotuladas de landmarks sintéticos/processados, sem frames brutos.
- Cobrir corte horizontal, palma estendida, outros movimentos, gesto incompleto, orientação/dedos incorretos, casos ambíguos e abaixo do limiar.
- Verificar IDs distintos e o mapeamento aprovado (corte→ataque com espada, palma→defesa) sem enviar ação Unity.
- Registrar matriz de confusão, precisão/recall, falsos positivos/negativos, contagens e distribuição dos rótulos.

### 2. Contrato do verificador LLM

- Injetar verificador determinístico nos testes: resposta consistente permite continuar; inconsistência impede ID; resposta ausente/timeout/malformada retorna `unavailable`.
- Confirmar que o resultado só publica `recognized` após resposta do verificador e que ele não pode alterar classe/comando.
- Não usar serviço real/credenciais em testes unitários. Testar respostas do adaptador somente com substituto/mocks determinísticos. Teste real só após aprovação de modelo, payload, configuração, custos, transmissão e condições de segurança/privacidade.

### 3. Sessão contínua

- Reproduzir amostras em sequência com velocidades, posições e condições de iluminação aprovadas.
- Incluir ausência/perda/recuperação de tracking, ruído, oscilações de confiança, repetição e reinício da sessão.
- Verificar máximo de um evento por execução, descarte de segmento parcial e retorno seguro após falha.

### 4. Fronteira da visão computacional

- Quando as Features upstream existirem, validar entrada real/replay OpenCV→MediaPipe→preparação→reconhecedor e câmera indisponível/frame inválido.
- Registrar precisão e condições de captura; não guardar frames brutos sem requisito aprovado.
- No repositório atual, esses módulos não existem; esta integração não foi executada e depende das Features de captura/detecção/preparação.

### 5. Fronteira Unity (fase posterior)

- Nesta Feature, validar somente resultado lógico e mapeamento semântico aprovado.
- Na Fase 2, testar protocolo escolhido, recebimento/acknowledgement, interrupção/reconexão e que cada ID válido causa a ação correspondente uma vez.
- Não simular recebimento ou execução Unity como evidência desta Fase 1.

## Protocolo de medição

Cada execução registra revisão do código, catálogo/critério, versões de runtime, CPU/memória/GPU, SO, câmera/configuração, condições de luz/distância/oclusão, posição e velocidade, lote rotulado, roteiro/repetições e falhas observadas.

| Métrica | Medição | Limite |
|---|---|---|
| Latência total | Tempo monotônico desde amostra processada até resultado final, incluindo a espera do LLM; registrar distribuição/percentis. | Pendente |
| Latência dos componentes | Medir separadamente validação/regras e verificação LLM. | Pendente |
| Taxa e backlog | Entradas/resultados por segundo, descartes/fila e atraso acumulado em sessão contínua. | Pendente |
| Precisão/confiabilidade | Matriz de confusão, precisão/recall, falsos positivos/negativos e resultados insuficientes por gesto, com contagens/denominadores. | Pendente |
| Estabilidade | Trocas indevidas, duplicatas, perda/recuperação, falhas consecutivas e evolução da latência em sessão prolongada. | Pendente |
| Recursos | CPU/memória/GPU em repouso e carga sustentada, média/pico e método de amostragem. | Pendente |

Repetir sob configuração igual para comparar. Nenhum limite numérico está aprovado; a equipe deve defini-los a partir de medições piloto antes dos testes de saída. O protocolo mede o verificador porque ele participa da decisão antes de publicar o gesto.

Enquanto a OpenAI API estiver desabilitada, resultados de latência do provedor não podem ser medidos nem presumidos; os testes determinísticos validam apenas o contrato e o comportamento fail-closed. Medições reais do LLM dependem das aprovações e da configuração de teste documentadas nas pré-condições.

## Registro de evidência

**Execução/código/configuração**: execução local em 2026-11-11; Python 3.12.14 bundled do Codex; `PYTHONPATH=src`; sem dependências externas, credenciais, rede ou envio à API.  
**Resultado**: `python -m unittest discover -s tests/recognition -v` — 14 testes passaram. Testes unitários do contrato de configuração/verificação usam transporte fake; não validam a API real nem critérios geométricos dos gestos.  
**Tentativa inicial**: a mesma descoberta sem `PYTHONPATH=src` falhou ao importar `gestix`; corrigida a invocação conforme o layout `src/`.  
**Conjunto e condições**: pendente  
**Resultados e comparação com limites aprovados**: pendente  
**Falhas, correções e retestes**: pendente  
**Evidências dos oito critérios constitucionais**: pendente  
**Aprovação formal da Fase 1**: pendente. Sem aprovação, não iniciar a Fase 2.
