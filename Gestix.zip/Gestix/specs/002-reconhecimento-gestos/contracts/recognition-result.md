# Contrato lógico: entrada do reconhecedor e resultado

O documento define semântica interna entre pipeline Python de visão/preparação, reconhecedor e futuro consumidor. Não define API remota, protocolo de rede, encoding, nomes wire nem serialização Python–Unity.

## Entrada processada (dependência upstream)

O produtor fornece amostras sucessivas contendo landmarks e estado explícito de tracking. Campo obrigatório em nível semântico: landmarks ou status que explique por que landmarks não estão disponíveis. Coordenadas, unidades, timestamp, handedness, ordem dos pontos, frequência e schema concreto devem ser acordados com a Feature upstream antes da implementação. Entrada inválida não deve ser corrigida silenciosamente.

## Verificação de consistência do LLM

1. As regras matemáticas classificam a amostra e aplicam o limiar aprovado.
2. Só uma classificação elegível passa ao verificador. O verificador recebe somente dados processados mínimos que a equipe aprovar; o payload concreto ainda não está definido.
3. A consulta é síncrona para emissão de um resultado positivo: o consumidor aguarda a resposta. O LLM não escolhe/edita o `gesture_id` nem associa comandos.
4. `consistent` permite publicar a classificação matemática; `inconsistent` rejeita a classificação. Sem resposta, timeout ou resposta malformada não publica gesto válido.
5. O provedor-alvo declarado para o verificador é a plataforma de API da OpenAI, conforme declaração do solicitante de aprovação do grupo. A Constitution 4.0.0 no workspace é candidata à ratificação; a base ratificada 3.0.0 não foi localizada. Modelo, payload, ambiente/configuração, timeout, custos, segurança, privacidade e transmissão permanecem pendentes. Chamadas reais ficam desabilitadas até aprovação específica. Sem verificador aprovado e habilitado, o resultado é `unavailable` e não contém ID acionável.

## Resultado lógico

| Campo | Obrigatório | Semântica |
|---|---|---|
| `status` | Sim | `recognized`, `not_recognized` ou `unavailable`. |
| `gesture_id` | Condicional | Exatamente um ID aprovado só em `recognized`; ausente nos outros estados. IDs candidatos: `HORIZONTAL_CUT`, `PALM_FORWARD`. |
| `confidence` | Pendente | Confiança das regras matemáticas; escala/limiar por aprovar. Não usar confiança do LLM como classe. |
| `observed_at` | Pendente | Referência temporal upstream ou tempo do resultado; unidade/formato dependem do contrato de origem. |
| `reason_code` | Recomendado | Categoria controlada: `unknown_gesture`, `insufficient_data`, `low_confidence`, `ambiguous`, `llm_inconsistent`, `invalid_input`, `llm_unavailable`, `tracking_lost`. Enum final precisa ser compatibilizado com integração. |
| `event_id` | Pendente | Unicidade/escopo serão definidos com consumidor se necessários à deduplicação entre processos. |

### Mapeamento semântico aprovado

| `gesture_id` | Ação aprovada |
|---|---|
| `HORIZONTAL_CUT` | Ataque com espada |
| `PALM_FORWARD` | Defesa |

O output deste componente mantém ID de gesto; a Feature Python–Unity mapeia o ID a uma representação wire/comando. Não criar comando para estados não reconhecidos/indisponíveis.

## Regras dos estados

- `recognized`: regra matemática Python identifica uma classe do catálogo e cumpre limiar/parâmetros; somente após resposta consistente do verificador OpenAI aprovado e habilitado pode conter `gesture_id`. O LLM não altera a classificação.
- `not_recognized`: entrada inválida/insuficiente conforme FR-005, movimento desconhecido ou incompleto/ambíguo, abaixo do limiar, ou verificador aponta inconsistência. Sem ID acionável.
- `unavailable`: fonte/reconhecedor/verificador indisponível ou desabilitado, falha de comunicação, timeout, resposta ausente ou malformada que impede a validação. Sem ID acionável.
- Falta de mão/tracking não equivale a gesto. Representação final entre `not_recognized`/`unavailable` depende do estado upstream acordado.
- No máximo um reconhecimento por execução segundo política de segmentação/rearme ainda pendente.

## Fora deste contrato

Schema wire, transporte, versão serializada, ordenação, retries, acknowledgements, reconexão e confirmação de ação Unity pertencem à Feature de integração (Fase 2). Interface visual de feedback pertence à Feature Unity/integração.
