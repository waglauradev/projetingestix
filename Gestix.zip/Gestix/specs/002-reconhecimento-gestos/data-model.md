# Modelo de dados: Reconhecimento de Gestos

Modelo lógico em memória e para teste. Não define schema serializado, banco de dados ou persistência de movimento.

## ProcessedHandSample (entrada dependente)

Produzida pelo pipeline OpenCV/MediaPipe/preparação, fora do escopo do reconhecedor. O contrato upstream ainda não existe no repositório.

| Campo lógico | Regra/pendência |
|---|---|
| `landmarks` | Sequência estruturada de pontos da mão; dimensões, nomes, ordenação, coordenadas, unidades e domínios dependem do contrato upstream. |
| `tracking_status` | Estado explícito: válido, sem mão, tracking parcial/perdido ou falha da fonte. Nunca inferir gesto de ausência. Enum concreto pendente. |
| `observed_at` | Timestamp/referência monotônica necessária às regras temporais; origem/unidade/formato pendentes. |
| `hand_identity` | Lado/identidade somente se critérios aprovados precisarem; não coletar além da finalidade. |
| `detector_confidence` | Opcional e distinto da confiança das regras; escala/significado upstream pendentes. |

## GestureDefinition

| Campo | Regra |
|---|---|
| `gesture_id` | Identificador estável e único da classe; candidatos atuais `HORIZONTAL_CUT` e `PALM_FORWARD`, finais após aprovação do catálogo. |
| `catalog_version` | Versão do catálogo/critério aplicado. |
| `spatial_criteria` | Direção, configuração dos dedos, orientação da palma e posição conforme critérios aprovados. |
| `temporal_criteria` | Deslocamento, velocidade, janela, neutralidade e rearme conforme critérios aprovados. |
| `approved_action` | Mapeamento semântico aprovado para esta Feature: corte horizontal → ataque com espada; palma à frente → defesa. Os nomes wire ficam na Feature de integração. |

## RuleClassification

Resultado determinístico das regras matemáticas sobre amostras válidas.

| Campo | Regra |
|---|---|
| `candidate_gesture_id` | Classe reconhecida pela regra ou ausente para desconhecido. |
| `rule_confidence` | Métrica/escala pendente; só é elegível ao verificador quando cumpre limiar aprovado. |
| `reason_code` | Motivo para rejeição (unknown, insufficient, low confidence, invalid sample etc.); vocabulário final pendente. |
| `segment_id` | Identidade interna da execução para evitar duplicata; algoritmo e escopo pendentes. |

## LLMConsistencyResult

Resposta volátil do verificador provido pela plataforma de API da OpenAI, alvo declarado para esta Feature. O modelo e schema específicos permanecem pendentes. Ambiente/configuração, timeout, tratamento de falhas, custos/limites de uso, segurança, privacidade, payload e autorização de transmissão também aguardam aprovação. Chamadas reais e transmissão ficam desabilitadas até ratificação constitucional e aprovações específicas.

| Campo | Regra |
|---|---|
| `consistency_status` | `consistent`, `inconsistent` ou `unavailable`; schema efetivo do fornecedor pendente. |
| `reason` | Categoria resumida de inconsistência/falha sem persistir payload bruto. Texto/schema do fornecedor pendente. |
| `checked_at` | Tempo monotônico local para métricas; relógio/serialização não é contrato externo. |

O LLM não produz nem altera `gesture_id` ou ação. A resposta `consistent` apenas permite que uma classificação matemática elegível siga para publicação.

## RecognitionResult

Ver [contrato lógico](contracts/recognition-result.md). Estado sempre presente; só `recognized` contém ID. É publicado como reconhecido depois de regra elegível e resposta LLM consistente; inconsistência → `not_recognized`, falha/timeout LLM → `unavailable`.

## RecognitionSession

Estado efêmero por sessão: janela mínima de amostras para critérios temporais, estado de tracking, segmento ativo e controle de rearme/deduplicação. Janela, neutralidade, retenção temporal e limpeza pendentes. Ao encerrar/reiniciar, descartar estado parcial e landmarks temporários.

## EvaluationRun

Metadados para repetição: revisão de código e catálogo, versão/configuração, lote rotulado de landmarks processados, hardware/SO/runtime, iluminação/distância/posição/velocidade, roteiro, resultados e métricas. Sem frames brutos por padrão; acesso/retenção de dados de participantes dependem de aprovação de privacidade.
