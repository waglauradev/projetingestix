# Implementation Plan: Reconhecimento e Diferenciação de Gestos

**Branch**: Não verificável (workspace sem metadados Git) | **Feature Directory**: `specs/002-reconhecimento-gestos` | **Date**: 2026-10-29 | **Spec**: [spec.md](spec.md)

## Summary

**Rastreabilidade do backlog**: esta Feature corresponde a [BKL-05 e BKL-18](../../backlog/README.md). BKL-01 a BKL-04 são dependências upstream; BKL-07 pertence à Fase 2.

Planejar o componente Python da Fase 1 que recebe amostras processadas de mãos, classifica o corte horizontal e a palma estendida para a frente por regras matemáticas, consulta o LLM de forma síncrona para sinalizar inconsistências e publica o estado lógico após essa verificação. A equipe confirmou o mapeamento corte horizontal → ataque com espada e palma estendida → defesa. O reconhecedor publica IDs de gesto; o transporte e as ações no Unity permanecem na Feature de integração.

O provedor-alvo declarado para verificação é a plataforma de API da OpenAI, conforme declaração do solicitante de que o grupo aprovou a substituição de Gemini. A Constitution 4.0.0 presente no workspace é candidata à ratificação; a base ratificada 3.0.0 não foi localizada e não há histórico Git disponível. Este plano registra o alvo declarado sem afirmar ratificação. Nenhuma chamada real ou transmissão de dados pode ser habilitada até aprovação específica de segurança, privacidade e configuração. O repositório não contém projeto Unity ou dependências/runtime de produto. Nesta execução foram criados componentes Python genéricos e fail-closed para validar entrada numérica, validar resultados lógicos, orquestrar classificação/verificação por dependências injetadas e configurar um transporte HTTP explicitamente opt-in; isso não implementa regras gestuais, contrato de payload OpenAI ou integração Unity, nem conclui a Fase 1.

## Technical Context

**Language/Version**: Python, versão pendente de confirmação quando o projeto de aplicação for criado.  
**Primary Dependencies**: OpenCV para captura (componente upstream); MediaPipe para detecção/rastreamento (upstream); Python para regras de reconhecimento/eventos; plataforma de API da OpenAI como provedor-alvo declarado para verificação secundária de inconsistências, sujeita à ratificação constitucional e a aprovações específicas de execução. Modelo, SDK, payload, endpoint, configuração, timeouts e custos não foram definidos. Nenhuma chamada real ou envio de dados fica habilitado por este plano.  
**Storage**: Sem persistência de frames ou landmarks brutos. Catálogo/configuração são artefatos versionados; relatórios de teste armazenam métricas agregadas e configuração, sujeitos às regras de privacidade.  
**Testing**: `unittest` da biblioteca padrão; 14 testes unitários locais passaram em Python 3.12.14 bundled do Codex com `PYTHONPATH=src`. Esse runtime foi usado para validação, não escolhido como runtime do produto. Fixtures gestuais reais/processadas dependem do schema e dos critérios aprovados; nenhuma foi inventada.  
**Target Platform**: Execução local do Gestix; sistema operacional, hardware mínimo, câmera e ambiente Unity ainda não estão descritos por um projeto executável no repositório.  
**Project Type**: Módulo local Python acoplado por interfaces ao pipeline de visão e à futura Feature Python–Unity.  
**Performance Goals**: Nenhum limite numérico aprovado. Medir latência do recebimento de amostra até evento publicável, incluindo verificação LLM síncrona; medir separadamente regras e LLM, distribuição/percentis, taxa/atraso, perdas, falsos positivos/negativos, estabilidade e CPU/memória/GPU. Limites devem ser aprovados antes da avaliação de saída da Fase 1.  
**Constraints**: Regras matemáticas são o classificador inicial; LLM somente sinaliza inconsistência e não cria classes/comandos; não reconhecer Libras; processamento local por padrão; sem envio externo sem aprovação documentada; sem captura/preparação/Unity visual/transporte nesta Feature.  
**Scale/Scope**: Dois gestos iniciais, sujeitos aos critérios geométricos e temporais pendentes: corte horizontal e palma estendida para a frente.

## Constitution Check

### Gate inicial

- **Princípios I–II**: responsabilidades separáveis; Python classifica; OpenCV captura; MediaPipe detecta; a plataforma de API da OpenAI é o provedor-alvo declarado apenas para verificar inconsistências; Unity executa o jogo. A Constituição 4.0.0 está candidata à ratificação e a base 3.0.0 não foi recuperada. Nenhuma chamada real, transmissão, modelo ou integração adicional é aprovada por inferência.
- **Princípio III**: captura com OpenCV e detecção/rastreamento MediaPipe são dependências de outras Features. Esta Feature consome estado explícito de amostra/mão; ausência não equivale a gesto. O repositório atual não contém esses componentes.
- **Princípio IV**: gestos comuns, sem Libras; corte horizontal e palma para a frente; regras matemáticas em Python são a autoridade da classificação; o LLM da OpenAI API apenas sinaliza inconsistências e nunca cria ou altera classe/gesto/comando/ação. A consulta é síncrona antes de `recognized`; inconsistência resulta `not_recognized`; resposta inválida, timeout, falha, ausência ou verificador desabilitado resulta `unavailable` sem ID acionável. Confiança, critérios gestuais e deduplicação permanecem pendentes na Spec.
- **Princípio V**: a saída lógica contém estado e ID do gesto; o mapeamento aprovado é documentado abaixo. Transporte/entrega Python–Unity e execução das ações são da Fase 2/Feature de integração. Feedback dos estados ao jogador pertence à Feature Unity/integração, conforme Clarify.
- **Princípios VI–VIII**: prever testes de regra, fronteira, sessão e fluxo local; testar estados positivos/negativos e condições de iluminação/posição/velocidade. Medir latência incluindo LLM, taxa e recursos. Não há metas numéricas aprovadas.
- **Princípios IX–X**: atualizar documentação com contratos; este componente integra a Fase 1 bloqueante, mas não encerra sozinho a Fase 1 da Constitution, que também exige evidência das fronteiras upstream, testes e aprovação formal. Este plano não autoriza Fase 2.
- **Princípios XI–XII**: reconhecimento não decide janela musical/pontuação. Dados são processados localmente por padrão; frames não são persistidos. Chamadas reais à OpenAI API e qualquer envio continuam desabilitados até aprovação específica de finalidade, payload, execução, segurança, privacidade, custos e falhas.
- **Governança**: o solicitante declara aprovação do grupo para substituir Gemini pela OpenAI API, mas nenhum registro formal de aprovação foi localizado; não se inferem data, participantes ou votação. A candidata 4.0.0 já existe no workspace e não está ratificada; a Constituição 3.0.0 e o histórico Git não foram encontrados. A ratificação da candidata é um gate documental, não uma autorização para transmissão.
- **Gate**: o desenho documental está alinhado às responsabilidades confirmadas. Implementação e saída da Fase 1 permanecem bloqueadas por critérios de gesto, schema upstream, confiança/segmentação, métricas aprovadas e decisões de LLM/privacidade.

### Recheck após desenho

O desenho mantém captura, preparação, reconhecimento, publicação e execução de ações separáveis; Python mantém a classificação e o LLM da OpenAI API só verifica inconsistências. O alvo do provedor é registrado como declaração do solicitante e permanece sujeito à ratificação da Constituição candidata 4.0.0. Chamadas reais e transmissão permanecem desabilitadas até decisões de modelo, payload, ambiente, timeout, falhas, custos, segurança e privacidade. Nenhum protocolo, meta, ratificação ou evidência de teste é presumido.

## Research & Decisions

Ver [research.md](research.md). Decisões/condições para implementação:

1. Aprovar critérios verificáveis dos gestos (direção, deslocamento, velocidade, dedos e orientação da palma).
2. Definir schema upstream, coordenadas/unidades, timestamp, ordenação, frequência e estado de rastreamento.
3. Definir escala/limiar de confiança, parâmetros de segmentação, neutralidade, rearme e deduplicação.
4. Ratificar a candidata constitucional 4.0.0 e registrar evidência formal da aprovação declarada pelo solicitante; a Constituição 3.0.0 ratificada não foi localizada.
5. Aprovar modelo OpenAI, payload mínimo, ambiente/configuração, timeout, falhas, custos, limites, segurança, privacidade e autorização específica de transmissão. Até essas aprovações, nenhuma chamada real ou envio é permitido e o sistema não pode publicar `recognized` sem verificador habilitado e consistente.
6. Aprovar hardware/ambiente e limites numéricos de latência, taxa, confiabilidade, estabilidade e recursos a partir de medições repetíveis.
7. Confirmar runtime Python e convenções do produto: há módulo inicial em `src/`, mas runtime suportado e empacotamento do Gestix continuam sem definição; o runtime bundled do Codex só executou os testes locais.
8. Definir protocolo, serialização, acknowledgements e recuperação de entrega em planejamento da Fase 2, não nesta Feature.

## Architecture & Responsibilities

| Componente | Responsabilidade prevista | Fora desta Feature / fronteira |
|---|---|---|
| Câmera + OpenCV | Abrir/capturar frames localmente; comunicar câmera indisponível, acesso negado e frame inválido ao pipeline. | Feature de captura. Frames brutos não são persistidos por este plano. |
| MediaPipe | Detectar/rastrear mãos e produzir landmarks/estado de detecção. | Feature de detecção; modelo/configuração e schema concreto não estão no repositório. |
| Preparação de amostras | Validar e fornecer sequência de landmarks, estado de tracking e referência temporal acordados. | Feature upstream de preparação; normalização/unidades/frequência ainda dependem de contrato. |
| Regras matemáticas Python | Aplicar critérios aprovados, calcular classe/candidato e confiança; retornar classe ou não reconhecido. | Núcleo desta Feature. Não captura, detecta nem prepara frames. |
| Verificador da OpenAI API | Receber somente dados processados mínimos que forem aprovados e sinalizar consistente/inconsistente/indisponível. A verificação ocorre antes de publicar `recognized`; não pode alterar classificação ou gesto. | Provedor-alvo declarado, sujeito à ratificação constitucional e aprovações de modelo, ambiente, payload, timeout, custos, segurança e privacidade. Chamadas e transmissão desabilitadas até aprovação. |
| Sessão/resultado | Aplicar limiar e estados, evitar emissão repetida na mesma execução e disponibilizar resultado lógico. | Núcleo desta Feature. Janela/rearme/limiar exigem valores aprovados. |
| Integração Python–Unity | Receber resultado, mapear ID para comando aprovado, transportar, confirmar entrega e tratar reconexão. | Fase 2/Feature de integração; protocolo não escolhido aqui. |
| Unity/experiência | Executar ataque/defesa aprovados e apresentar ao jogador reconhecido/não reconhecido/indisponível. | Feature Unity/integração e gameplay; nenhum código Unity existe no repo atual. |

## Data Flow

```text
OpenCV captura frame localmente (Feature upstream)
  -> MediaPipe detecta/rastreia mãos (Feature upstream)
  -> preparação entrega landmarks + tracking + tempo (Feature upstream)
  -> validador de entrada Python
  -> regras matemáticas classificam gesto + confiança
  -> caso desconhecido/insuficiente/abaixo do limiar: not_recognized, sem chamada acionável
  -> caso candidato válido: verificador da OpenAI API sinaliza inconsistências de forma síncrona, se aprovado e habilitado
       -> inconsistente: not_recognized, sem ID acionável
       -> timeout/resposta ausente/malformada: unavailable, sem ID acionável
       -> sem inconsistência: recognized + gesture_id
  -> consumidor Python–Unity (Fase 2) traduz ID no comando aprovado e transporta
  -> Unity executa a ação e apresenta o estado ao jogador
```

**Mapeamento funcional aprovado para esta Feature**:

| Gesto reconhecido | Ação aprovada | Limite de responsabilidade |
|---|---|---|
| Corte horizontal | Ataque com espada | A Feature publica o ID; o consumidor da Fase 2 encaminha o comando e Unity executa a ação. |
| Palma estendida para a frente | Defesa | A Feature publica o ID; o consumidor da Fase 2 encaminha o comando e Unity executa a ação. |
| Desconhecido, baixa confiança, inconsistente ou indisponível | Nenhuma ação | Não publicar ID/command acionável. |

Os nomes wire de IDs/comandos ainda são provisórios no contrato; a associação semântica acima foi confirmada pela equipe. Não há sincronização musical, pontuação ou regras adicionais nesta Feature.

## Contracts & Failure Behavior

- Entrada lógica: amostra processada com landmarks, estado de detecção/tracking e referência temporal. Schema, sistema de coordenadas, unidades, ordenação e frequência devem ser acordados com as Features upstream antes da implementação.
- Saída lógica: [contrato de resultado](contracts/recognition-result.md), sem protocolo/transporte. `recognized` só é publicado após regras matemáticas acima do limiar e resposta consistente do verificador OpenAI aprovado e habilitado.
- `not_recognized`: entrada inválida ou insuficiente conforme FR-005, gesto fora do catálogo, regra matemática não satisfeita/baixa confiança ou verificador sinalizou inconsistência. Não contém ID acionável.
- `unavailable`: fonte/reconhecedor sem serviço, API/verificador desabilitado ou indisponível, timeout, resposta malformada/falha de comunicação ou falha interna que impede análise. Não contém ID acionável.
- Ausência/perda de mãos: receber estado upstream explícito; não representar como gesto. Recuperação volta a considerar amostras novas, sem reutilizar segmento parcial da sessão anterior.
- Duplicidade: uma execução validada pode publicar no máximo um reconhecimento; regra de neutralidade/rearme e identificador de evento serão definidos com os contratos e parâmetros aprovados.
- Python–Unity: protocolo, schema wire, ordenação, acknowledgement, timeout/retry e reconexão pertencem à Fase 2. O consumidor deve rejeitar estados desconhecidos/ inválidos e não executar ação sem ID mapeado.

## Project Structure Decision

**Estrutura atual verificada**: o repositório contém Specs, templates/scripts do Spec Kit, um diagrama de arquitetura, documentos de backlog e agora o módulo inicial `src/gestix/recognition/` com testes em `tests/recognition/`. Não contém projeto Unity, dependências/runtime de produto ou schema upstream. `sdd-demo/` é outra instalação demonstrativa do Spec Kit, não o produto Gestix.

**Estrutura implementada parcialmente** (módulo genérico; os itens pendentes continuam como plano, não código existente):

```text
src/gestix/recognition/
├── input_validation.py   # validação do contrato upstream
├── rules.py              # pendente: critérios geométricos/temporais aprovados
├── consistency_check.py  # configuração opt-in e transporte com builder/parser injetados; sem schema API escolhido
├── session.py            # orquestração básica; confiança/neutralidade/deduplicação pendentes
└── result.py             # estados e IDs do contrato lógico
tests/recognition/
├── test_input_validation.py
├── test_gesture_rules.py # pendente: critérios e fixtures aprovados
├── test_consistency_check.py
├── test_session.py
└── fixtures/              # landmarks sintéticos/processados, sem frames brutos
```

Essa árvore não afirma que os diretórios existem. Confirmar convenções e runtime do produto antes de criar código. Unity e captura permanecem em seus projetos/Features próprios. Usar `unittest` da biblioteca padrão como proposta para não adicionar dependência de teste; confirmar compatibilidade com o runtime aprovado.

## Validation Strategy

1. **Entrada/regra unitária**: testar landmarks válidos/ausentes/inválidos; cortes/palmas contemplados e negativos; direção, velocidade, posição e iluminação controladas; matriz de confusão, precisão/recall e falso positivo/negativo.
2. **Consistência LLM**: contrato testado com substituto determinístico em testes (sem rede/dados reais): consistente permite continuação; inconsistente impede ID; timeout, ausência, formato inválido, falha de comunicação ou ambiguidade retornam indisponível/não reconhecido. Qualquer teste real da OpenAI API só poderá ocorrer após aprovações de modelo, payload, ambiente, credenciais, custos, segurança e privacidade; chamadas e transmissão ficam desligadas até então.
3. **Sessão contínua**: sequência válida, movimentos desconhecidos, perda/recuperação de tracking, oscilação de confiança, gesto incompleto e repetição; provar no máximo um ID por execução e isolamento após reinício.
4. **Fronteira upstream**: com o contrato de captura/preparação aprovado, executar replay de amostras rotuladas e um ensaio local com OpenCV+MediaPipe nas condições documentadas. Como os módulos não existem no repositório, esta verificação depende de outras Features e não pode ser alegada hoje.
5. **Fronteira Unity**: testes de contrato lógico podem validar IDs/estados; transporte, confirmação de recebimento e ação observável no Unity pertencem à Fase 2 e devem ser planejados/testados lá. Não simular integração como evidência.
6. **Desempenho**: medir do instante da amostra processada ao resultado final, incluindo espera LLM; registrar separadamente regras e verificador, frequência de entrada/saída, descartes/fila, perda/duplicidade e CPU/memória/GPU. Documentar CPU/SO/runtime, câmera/configuração, condições de iluminação, distância, posição, velocidade, conjunto e repetições.
7. **Limites**: latência, taxa, precisão/recall, falsos positivos, estabilidade, duração e orçamento de recursos não têm valores aprovados. A equipe deve defini-los após medições piloto e antes de usar resultados como gate. Esta proposta não inventa limites.

## Phase Gate & Risks

- Este documento planeja o componente de reconhecimento da Fase 1; não declara a Fase 1 completa. Captura OpenCV, detecção MediaPipe e preparação de dados são dependências externas ainda ausentes no repositório.
- A Fase 2 Python–Unity continua bloqueada até haver evidência e aprovação formal dos oito critérios de saída da Fase 1.
- **Risco de governança**: o solicitante declara aprovação do grupo para OpenAI API; não foi localizado registro formal. A candidata 4.0.0 está no workspace sem ratificação; a base 3.0.0 e o histórico Git não foram recuperados.
- **Risco de privacidade/execução**: OpenAI API é provedor-alvo declarado, mas modelo, payload e transmissão não foram aprovados. Sem decisão de segurança/privacidade/configuração, não habilitar chamadas nem publicar `recognized`.
- **Risco de tempo real**: verificação LLM síncrona adiciona latência variável. Ela deve ser medida no total e separadamente; timeout resulta `unavailable`, sem evento.
- **Risco de qualidade**: critérios gestuais, confidence threshold e segmentação pendentes impedem testes de aceitação completos e prevenção demonstrável de falso positivo/duplicata.
- **Risco de contrato**: landmarks, timestamps, frequência, serialização e protocolo não existem no repo. Alinhar upstream antes da implementação e definir protocolo apenas na fase de integração.
- **Risco de rastreabilidade**: T017 e T020 em `tasks.md` cobrem o verificador e seu contrato sob o provedor OpenAI; dependem de decisões de modelo, payload, configuração, falha e privacidade em T007. Chamadas reais seguem bloqueadas até aprovação específica.
- **Risco de escopo**: diagrama mostra monitoria web/PostgreSQL, mas Constitution não confirma esses componentes como parte do jogo; excluídos deste plano.
