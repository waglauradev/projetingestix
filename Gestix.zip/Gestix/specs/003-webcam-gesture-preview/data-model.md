# Data Model: Webcam e Prévia de Gestos

## HandObservation

- Representa uma mão rastreada em um frame de webcam espelhado.
- `landmarks`: tuple de 63 floats finitos, sequência de 21 triplas MediaPipe `(x,y,z)` na ordem fixa 0–20; x e z multiplicados por `frame_width / frame_height`, y mantido em coordenada normalizada.
- `handedness`: `Left` ou `Right` reportado pelo MediaPipe para imagem espelhada.
- `timestamp_seconds`: tempo monotônico do frame, usado somente para janela temporal local.
- É iterável sobre `landmarks`, preservando compatibilidade com `validate_processed_input` e sem acrescentar campos ao `RecognitionResult`.

## GestureCandidate

- `RecognitionResult` provisório produzido pelas regras matemáticas apenas para prévia.
- IDs permitidos `HORIZONTAL_CUT` e `PALM_FORWARD`; confiança é um score da margem heurística, não probabilidade estatística.
- `not_recognized`/`unavailable` têm `gesture_id=None`; não têm ação/comando.
- Nunca é usado pela UI como resultado oficial da sessão.

## Official RecognitionResult

- Usado exatamente conforme `specs/002-reconhecimento-gestos/contracts/recognition-result.md` e o núcleo instalado.
- Com OpenAI desligada/não aprovada: `unavailable`, sem `gesture_id` para qualquer candidata válida.
- Sem mão (`[]`): `not_recognized` por validação de amostra vazia.

## Gesture window and latch

- Uma janela mantém amostras da mesma mão e tempos monotônicos em ordem.
- Corte procura subjanela com pelo menos 5 amostras, duração 0.10–0.55 s, displacement/straightness aprovados.
- Palma exige 5 amostras e 0.12 s sustentados.
- Latch impede duplicata até a regra de estabilidade de 5 amostras/0.15 s; perda de tracking limpa histórico e latch.

## VisionFrame / HUD state

- `VisionFrame` é transitório: BGR frame espelhado, observação opcional, candidatos e estado oficial.
- HUD exibe `official_status`, `official_gesture_id` ou `reason_code`, `preview_status`, `preview_gesture_id`, `preview_confidence` e FPS.
- Frames/dados temporários não são persistidos.
