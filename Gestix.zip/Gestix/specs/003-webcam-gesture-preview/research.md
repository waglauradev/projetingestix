# Research: Webcam e Prévia de Gestos

## Decisions

### MediaPipe Python API

- **Decision**: usar MediaPipe Tasks Hand Landmarker em `VIDEO`, não o legado `mp.solutions.hands`.
- **Reason**: a documentação oficial atual fornece `mp.tasks.vision.HandLandmarker`, `HandLandmarkerOptions`, `RunningMode.VIDEO`, `detect_for_video`, 21 landmarks de imagem/mundo e handedness. A API Solutions foi removida em releases recentes; implementar sobre ela quebraria instalações atuais.
- **Setup**: instalar pacote `mediapipe`, fornecer arquivo `.task` oficial explicitamente em `models/hand_landmarker.task`; não fazer download automático e não versionar o binário.
- **Source**: [MediaPipe Hand Landmarker Python](https://developers.google.com/edge/mediapipe/solutions/vision/hand_landmarker?tab=Python).

### Capture and frame scheduling

- OpenCV `VideoCapture` síncrono com um frame por vez; `RunningMode.VIDEO` recebe timestamp monotônico em milissegundos crescentes. Não introduzir worker/thread/fila sem medida que demonstre necessidade.
- Espelhar frame antes de derivar RGB, detectar e desenhar. O mesmo frame espelhado alimenta a imagem exibida e o Landmarker para handedness e overlay coerentes.
- `num_hands=1` limita ambiguidade e mantém uma sequência de gesture rules. Reavaliar somente se houver requisito para duas mãos.

### Preview and official state

- Reusar `RecognitionSession` e `OpenAIConsistencyVerifier(OpenAIConfig.from_env())` sem alteração; não injetar verifier sintético na aplicação offline.
- Dois objetos independentes de `GestureRuleClassifier` consomem amostras iguais: um fornece a callable da sessão e outro produz candidatas visuais. A UI apresenta ambos em campos separados.
- Sem `payload_builder`/`response_parser` aprovados, o verificador OpenAI existente não pode gerar request válido; mesmo flags habilitadas não completam a configuração. Não adicionar payload/modelo nesta Feature.

### Numeric criteria

- Adotar os valores iniciais explicitamente autorizados em `spec.md` como `gesture-rules-v1`, parâmetros constantes configuráveis. São critérios iniciais de geometria/temporalidade, não limites globais de desempenho.
- Usar a lista padrão MediaPipe em ordem 0–20. Escalar x e z por width/height para obter unidade comparável a y em frames não quadrados.
- Prévia não representa precisão/confiança estatística: confidence é score determinístico de margem relativo aos thresholds e rotulado como **candidata** no HUD.

### Local environment

- Inspeção em 2026-11-25: `py -0p` reportou “No installed Pythons found”; alias `python` aponta para WindowsApps e não inicia; dependências OpenCV/MediaPipe não puderam ser importadas/inspecionadas. Nenhum pacote foi instalado.
- Sem `unittest` executável nesta sessão. A estratégia de teste fica pronta no repositório, mas resultado não pode ser alegado até runtime Python disponível.
