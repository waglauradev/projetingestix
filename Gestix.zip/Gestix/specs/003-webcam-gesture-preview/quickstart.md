# Quickstart: Webcam e Prévia de Gestos

## Install

Use a project Python 3.11+ virtual environment (runtime compatibility still needs local verification):

```powershell
py -3.11 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
python -m pip install -r requirements-vision.txt
```

Obtain the official MediaPipe Hand Landmarker task asset using the current [Google AI Edge Hand Landmarker model link](https://huggingface.co/litert-community/MediaPipe-HandLandmarker-Full/resolve/main/hand_landmarker.task) and save as `models/hand_landmarker.task`. The repo does not download or store the model automatically. Confirm license/asset provenance before distributing it.

## Run offline preview

```powershell
$env:PYTHONPATH = 'src'
python -m gestix.vision.runner --camera 0 --model models/hand_landmarker.task
```

The window mirrors the camera, draws hand points/connections, shows the local `HORIZONTAL_CUT`/`PALM_FORWARD` candidate and its heuristic score, and separately shows official `RecognitionSession` status. With OpenAI off, a valid candidate appears in preview while official status is `unavailable`; no local fake verifier bypass is provided. No hand results in official `not_recognized`. Press `q` to close.

## OpenAI configuration status

The runner creates the existing gated verifier from environment configuration. Do not set the gates or make a live request until the pending Feature 002 decisions for model, payload/parser, environment, timeout, security/privacy, costs, and transmission are approved and implemented. The adapter currently has no approved payload builder or response parser, so enabling flags alone intentionally does not enable a live check. The official result stays `unavailable` until the check is configured and returns valid consistency.

No OpenAI call is made by tests or by default. This Feature does not specify an API payload, model, or new policy.

## Test

```powershell
$env:PYTHONPATH = 'src'
python -m unittest discover -s tests/vision -v
```

The test suite uses synthetic landmarks and fake camera/MediaPipe objects; it does not open a real camera or contact OpenAI. **Attempt on 2026-11-25**: `py -3.11 -m unittest discover -s tests/vision -v` could not start (`No installed Python found!` from the Windows Python launcher). No test result is claimed; run it after a Python 3.11+ runtime is installed.

## Manual measurement record

Log Python version, OS, camera model/index, camera frame size, lighting, hand distance, number of repetitions, observed FPS, capture/detection/rule/session durations, and candidate false positives/negatives. No numerical quality or latency limit is approved by this document.
