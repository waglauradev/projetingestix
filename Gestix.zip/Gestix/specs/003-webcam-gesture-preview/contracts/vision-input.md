# Contract: Webcam to Gesture Session

## Frame boundary

- Input: OpenCV BGR frame read from camera; dimensions must be positive.
- Runner mirrors once using horizontal flip, converts mirrored BGR frame to RGB, creates a MediaPipe `mp.Image(SRGB)`, and calls `HandLandmarker.detect_for_video(image, timestamp_ms)` with strictly increasing monotonic milliseconds.
- Runner draws returned 21 image landmarks and fixed Hand Landmarker connections on the mirrored display frame.

## Sample boundary

- For exactly one detected hand, convert image landmarks #0–20 to `(x * width/height, y, z * width/height)` floats. Require each component finite and preserve handedness label and monotonic timestamp in `HandObservation`.
- `HandObservation` iterates to the 63 float coordinates. This remains the only numeric iterable passed to the existing session/classifier.
- For no detected hand, pass `[]`; existing session input validation returns `not_recognized`, with no ID. For invalid landmarks, pass no actionable sample and display `not_recognized`/`invalid_input`.
- Multiple hands are outside initial contract (`num_hands=1`).

## Classifier boundary

- `GestureRuleClassifier.__call__(sample) -> RecognitionResult` is injected into the existing session; it recognizes only the two approved IDs.
- The local preview calls an independent `GestureRuleClassifier.preview(sample)` and is not an official event.
- Session's official result is displayed verbatim. It is never copied from preview.

## Resource boundary

- Runner owns camera, HandLandmarker, and OpenCV window lifecycle. All are closed in `finally` on quit, open/read failure, or exception.
- No frames, landmarks, logs with coordinates, action commands, or Unity packets are written/transmitted by this boundary.
