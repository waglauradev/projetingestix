# Tasks: Webcam e Prévia de Gestos

**Input**: [spec.md](spec.md), [plan.md](plan.md), [research.md](research.md), [data-model.md](data-model.md), [contracts/vision-input.md](contracts/vision-input.md), [quickstart.md](quickstart.md)  
**Feature**: `003-webcam-gesture-preview`  
**Fase**: ferramenta local da Fase 1; não declara Fase 1 encerrada e não inicia Fase 2.  
**Tests**: incluídos em cada história conforme FR-012.

## Phase 1: Setup

- [x] T001 Criar pacote isolado `src/gestix/vision/`, diretório `tests/vision/` e dependências opcionais em `requirements-vision.txt`, sem alterar `src/gestix/recognition/` já existente.
- [x] T002 [P] Criar fixtures sintéticas e utilitários de mão em `tests/vision/fixtures/` e `tests/vision/helpers.py` sem imagens/frame persistidos.

## Phase 2: Foundational

- [x] T003 Registrar/verificar que o contrato da sessão permanece inalterado; definir `HandObservation` iterável com 63 floats, handedness e tempo em `specs/003-webcam-gesture-preview/contracts/vision-input.md`.
- [x] T004 [P] Criar arquivo `requirements-vision.txt` com OpenCV, NumPy e MediaPipe Tasks e documentar modelo `.task` externo em `specs/003-webcam-gesture-preview/quickstart.md`.

## Phase 3: User Story 1 — Converter entrada de visão (P1)

**Independent Test**: coordenadas sintéticas válidas geram exatamente 63 floats na ordem estável; dimensões/landmarks inválidos são rejeitados, sem OpenCV ou câmera.

- [x] T005 [P] Escrever testes de conversão/validação para ordem, escala do aspect ratio, handedness, dimensão zero, quantidade diferente de 21 e NaN/Inf em `tests/vision/test_landmarks.py`.
- [x] T006 Implementar `HandObservation`, `flatten_landmarks` e validação pura em `src/gestix/vision/landmarks.py`.

## Phase 4: User Story 2 — Pré-visualizar os dois gestos aprovados (P1)

**Independent Test**: fixtures temporais de corte/palma produzem só seus IDs candidatos sob todos os critérios `gesture-rules-v1`; casos negativos, mão ausente, instabilidade e rearm produzem resultado sem ID. Nenhuma nova classe é adicionada.

- [x] T007 [P] Escrever testes positivos/negativos para cada limite, janela, handedness/orientação, dedo dobrado, movimento diagonal, tracking perdido, latch e rearm em `tests/vision/test_gesture_rules.py`.
- [x] T008 Implementar classificador stateful puro/injetável e score candidato em `src/gestix/recognition/gesture_rules.py`, restrito a `HORIZONTAL_CUT` e `PALM_FORWARD`.

## Phase 5: User Story 3 — Usar webcam e HUD com status oficial separado (P1)

**Independent Test**: fakes de OpenCV, MediaPipe Tasks e câmera exercitam frame espelhado, landmarks desenhados, câmera indisponível, ausência da mão, `q`, cleanup e HUD; sessão real com verifier desabilitado apresenta status oficial `unavailable` para candidata válida enquanto preview mantém candidato.

- [x] T009 [P] Escrever testes do runner com fakes, sem câmera/modelo/API reais, em `tests/vision/test_vision_runner.py`.
- [x] T010 Implementar câmera OpenCV + MediaPipe Tasks HandLandmarker `VIDEO`, timestamp monotônico, espelho, detecção e desenho em `src/gestix/vision/mediapipe_camera.py`.
- [x] T011 Implementar loop/HUD com candidata e resultado `RecognitionSession` em campos separados, tratamento de erro/saída e cleanup em `src/gestix/vision/runner.py`.
- [x] T012 Criar ponto de entrada `python -m gestix.vision.runner` e flags `--camera`/`--model`; manter estado OpenAI configurado por `OpenAIConfig.from_env()` em `src/gestix/vision/runner.py`.

## Phase 6: Polish and verification

- [ ] T013 Executar testes unitários da Feature com runtime Python configurado e registrar resultado real em `specs/003-webcam-gesture-preview/quickstart.md`.
- [x] T014 Atualizar instruções de instalação, asset do MediaPipe, modo offline, gates OpenAI e medição manual em `specs/003-webcam-gesture-preview/quickstart.md`.
- [ ] T015 Quando runtime, dependências e asset estiverem instalados, executar demo com webcam real e registrar FPS/latência/condições sem reivindicar metas não aprovadas em `specs/003-webcam-gesture-preview/quickstart.md`.
- [x] T016 Conferir timestamps/escopo: arquivos de documentação da Feature 002 e os quatro módulos do núcleo anteriores mantêm o estado de 2026-11-11; esta implementação não os editou. `git status` não é disponível porque o workspace não tem metadados Git.

## Dependencies & Execution Order

- Setup T001 precede todas as tarefas de código; T002 e T004 podem ser feitos em arquivos distintos.
- T005 precede T006; T007 precede T008. Os módulos de entrada e regras são puros e não dependem das bibliotecas de visão.
- T009 precede T010/T011. Runner integra T006/T008 com a sessão existente e só depois adiciona captura.
- T013 depende das implementações e testes. T015 depende de instalação/runtime/modelo/câmera, podendo continuar pendente mesmo se testes sintéticos forem concluídos.
- Nenhuma tarefa adiciona integração Unity ou chamada real à API.

## Validation Commands

```powershell
$env:PYTHONPATH = 'src'
python -m unittest discover -s tests/vision -v
```

## Implementation Strategy

Implementar a entrada pura e regras com fixtures primeiro; depois integrar a sessão existente e por fim conectar câmera/HUD. Os testes de webcam usam doubles. Sem Python disponível nesta execução, nenhuma tarefa de teste será marcada concluída sem a instalação de runtime.
