# Feature Specification: Webcam e Prévia de Gestos

**Feature Branch**: `003-webcam-gesture-preview`  
**Created**: 2026-11-25  
**Status**: Draft — implementação local de captura, prévia e classificação candidata; sem aprovação de saída da Fase 1  
**Related Feature**: [002-reconhecimento-gestos](../002-reconhecimento-gestos/spec.md), referência de contratos e catálogo; os arquivos 002 permanecem inalterados.  
**Input**: adicionar uma camada de webcam isolada que produza a entrada do reconhecedor, desenhe os landmarks e apresente candidatas locais sem contornar o verificador da sessão.

## User Scenarios & Testing

### User Story 1 — Visualizar mão e landmarks em tempo real (Priority: P1)

Como integrante da equipe, quero ver a imagem espelhada da webcam com os 21 landmarks e conexões MediaPipe, para inspecionar a qualidade do rastreamento localmente.

**Why this priority**: A visão de landmarks permite depurar a entrada do reconhecedor e validar a câmera sem alterar o núcleo ou enviar vídeo para fora da máquina.

**Independent Test**: Com frames e resultados MediaPipe simulados, validar espelhamento, desenho dos landmarks, conversão para amostra e tratamento de câmera indisponível sem hardware real.

**Acceptance Scenarios**:

1. **Given** uma câmera que abre e frames válidos, **When** a aplicação processa cada frame, **Then** exibe o frame espelhado, as conexões e os 21 pontos da mão detectada.
2. **Given** uma mão detectada, **When** os landmarks são convertidos, **Then** a amostra contém 21 triplas finitas na ordem MediaPipe e é iterável como 63 valores numéricos para `validate_processed_input`.
3. **Given** câmera que não abre, frame inválido ou falha durante a leitura, **When** a aplicação tenta capturar, **Then** informa `unavailable` e o motivo no console/HUD quando houver janela, e encerra ou permite saída limpa sem traceback não tratado.

### User Story 2 — Inspecionar candidatas dos gestos aprovados (Priority: P1)

Como integrante da equipe, quero ver uma classificação geométrica local candidata para corte horizontal ou palma estendida para a frente, para avaliar os critérios iniciais sem transformar a prévia em comando de jogo.

**Why this priority**: A classificação candidata torna possível verificar a geometria ao vivo, mantendo a autoridade do `RecognitionSession` e do verificador OpenAI.

**Independent Test**: Fornecer sequências sintéticas de landmarks com rótulos conhecidos; verificar os dois IDs aprovados, movimentos negativos, limiares e rearme sem câmera nem API.

**Acceptance Scenarios**:

1. **Given** sequência que satisfaz os critérios iniciais do corte horizontal, **When** a regra geométrica avalia a janela temporal, **Then** a prévia mostra `HORIZONTAL_CUT` com confiança candidata finita.
2. **Given** mão aberta voltada para a câmera pelo tempo mínimo definido, **When** a regra geométrica avalia os landmarks, **Then** a prévia mostra `PALM_FORWARD` com confiança candidata finita.
3. **Given** candidato local válido e API/verificador desabilitado, **When** a amostra passa por `RecognitionSession`, **Then** a prévia continua mostrando a candidata, enquanto o status oficial permanece `unavailable` sem `gesture_id`.
4. **Given** ausência de mão, amostra inválida, gesto desconhecido ou verificação inconsistente, **When** a sessão é atualizada, **Then** nenhum ID oficial acionável é mostrado.

### User Story 3 — Acompanhar estado e encerrar a demonstração (Priority: P2)

Como integrante da equipe, quero acompanhar o estado oficial, a candidata local, confiança candidata e FPS, e encerrar a janela com `q`, para testar a demonstração sem integração Unity.

**Independent Test**: Testar a composição do HUD e a rotina de encerramento com dependências OpenCV simuladas.

**Acceptance Scenarios**:

1. **Given** execução da demonstração, **When** cada frame é processado, **Then** o HUD mostra status oficial, ID ou motivo, candidata/prévia, confiança candidata e FPS.
2. **Given** usuário pressiona `q`, **When** a aplicação recebe a tecla, **Then** fecha recursos de câmera, MediaPipe e janela mesmo que ocorra erro durante o loop.

## Edge Cases

- Nenhuma mão, múltiplas mãos, landmarks incompletos/não finitos ou handedness ausente.
- Câmera inacessível, índice inválido, leitura interrompida, frame vazio ou dimensão zero.
- Perda e recuperação de tracking durante uma janela de corte ou uma palma sustentada.
- Ruído, oscilação perto dos limiares, mão parcialmente fora do enquadramento, velocidade fora da janela e movimento diagonal.
- Candidata local reconhecida enquanto a API está desabilitada: a prévia pode exibir a candidata, mas o resultado da sessão continua `unavailable`.
- Erro/timeout/resposta inválida do verificador não pode converter a candidata em reconhecimento oficial.
- Janela fechada pelo sistema ou exceção de dispositivo: recursos sempre liberados.

## Clarifications / Decisions

- Esta é uma Feature Spec distinta da 002. Ela reutiliza os documentos anteriores como fonte, sem alterar os arquivos da Feature 002.
- O catálogo permanece estritamente `HORIZONTAL_CUT` e `PALM_FORWARD`; não incluir punho, joinha, paz, apontar nem novos mapeamentos.
- A Feature 003 adiciona captura OpenCV e visualização MediaPipe em camada separada, conforme autorização explícita de 2026-11-25. O núcleo existente permanece sem dependências de vídeo e sem campos de UI/comandos Unity.
- Prévia offline é somente visual/debug. Nenhum verifier local de bypass será usado. Sem OpenAI aprovado/habilitado, `RecognitionSession` mantém `unavailable` para candidata válida.
- Critérios geométricos abaixo são valores iniciais versionados e configuráveis para teste/piloto, não metas de desempenho nem alegação de precisão aprovada.
- Chamadas OpenAI reais, modelo, payload e política de dados continuam sob os gates registrados em 002; esta implementação não as executa nem seleciona esses parâmetros.

## Requirements

### Functional Requirements

- **FR-001**: O runner MUST abrir câmera local via OpenCV, espelhar os frames para visualização e tratar câmera indisponível/falha de leitura como `unavailable` sem ID.
- **FR-002**: A camada de visão MUST detectar uma mão com MediaPipe Hands e desenhar suas conexões e 21 landmarks sobre o frame exibido.
- **FR-003**: A conversão MUST validar 21 landmarks, dimensões positivas e coordenadas finitas; produzir ordem MediaPipe 0–20, cada ponto `(x, y, z)`, total 63 valores finitos. `x` e `z` são escalados pela razão largura/altura para que distâncias no plano sejam comparáveis a `y`; a origem da imagem é a imagem já espelhada.
- **FR-004**: Ausência de mão MUST produzir entrada vazia ao `RecognitionSession`, resultando em `not_recognized` conforme o contrato existente; falha de câmera MUST produzir `unavailable`.
- **FR-005**: A prévia geométrica MUST suportar apenas `HORIZONTAL_CUT` e `PALM_FORWARD`, usando os critérios iniciais definidos abaixo e confiança candidata derivada somente das margens geométricas.
- **FR-006**: O classificador candidato MUST implementar `Callable[[Any], RecognitionResult]` para injeção no `RecognitionSession`; estados não reconhecidos/indisponíveis MUST ter `gesture_id=None` e nenhum comando/ação.
- **FR-007**: A UI MUST manter separados os campos de candidata local e resultado oficial da sessão. Candidata local não pode substituir nem promover o resultado oficial.
- **FR-008**: Com verificador OpenAI desligado/não aprovado, uma candidata válida MUST continuar `unavailable` no resultado oficial; inconsistente deve resultar `not_recognized` e falha/timeout/resposta inválida `unavailable`, de acordo com o núcleo existente.
- **FR-009**: O HUD MUST mostrar estado oficial, ID/motivo oficial, estado/ID candidato, confiança candidata e FPS; `q` e falhas MUST liberar câmera, MediaPipe e janela.
- **FR-010**: A Feature MUST NOT alterar `RecognitionResult`, `RecognitionSession`, `OpenAIConfig` ou invariantes do núcleo existentes; MUST NOT adicionar captura, inferência visual ou UI ao pacote `recognition` já existente.
- **FR-011**: A Feature MUST NOT persistir frames/landmarks, iniciar Unity, transmitir comandos ou executar ações de combate.
- **FR-012**: A Feature MUST fornecer testes sintéticos sem câmera/API real para conversão, regras, estados/sessão, erros e HUD/runner.
- **FR-013**: A integração futura OpenAI permanece desabilitada por padrão e depende de todas as flags/decisões já documentadas; esta Feature não faz chamada real e não define payload/modelo.

### Critérios geométricos/temporais iniciais

Coordenadas são 21 landmarks de imagem MediaPipe, escaladas para unidade proporcional à altura do frame; o centro da palma é o landmark 9 e a largura de referência é a distância 2D entre landmarks 5 e 17. Amostra com largura de palma quase zero é inválida para estas regras.

**`PALM_FORWARD` — palma aberta voltada para a câmera**:

1. Pontos de dedo MediaPipe: ângulos internos em PIP `6,10,14,18`, calculados por `(MCP−PIP)` e `(TIP−PIP)` em 3D, devem ser pelo menos `155°` nos quatro dedos.
2. Polegar aberto: distância 2D entre TIP4 e TIP8 deve ser pelo menos `0.45 × largura da palma`.
3. Plano da palma voltado à câmera: normal `cross(P5−P0, P17−P0)` deve ter projeção absoluta no eixo Z de pelo menos `cos(40°)` do comprimento da normal; o sinal deve concordar com handedness da mão na imagem espelhada (direita: normal Z negativa; esquerda: positiva).
4. A condição deve persistir por pelo menos 5 amostras e `0.12 s`; perda de mão reinicia a janela.

**`HORIZONTAL_CUT` — deslocamento lateral da mão**:

1. Usar uma janela de 5 ou mais amostras, duração entre `0.10 s` e `0.55 s`, com o mesmo track contínuo.
2. Deslocamento horizontal absoluto do landmark 9 deve ser pelo menos `1.25 ×` a largura da palma no início da janela; direita ou esquerda são aceitas.
3. Deslocamento vertical líquido absoluto deve ser no máximo `0.60 ×` a largura inicial; soma de deslocamentos verticais absolutos no percurso deve ser no máximo `0.90 ×` a largura inicial.
4. Retidão horizontal `abs(dx líquido) / soma(abs(dx por passo))` deve ser pelo menos `0.75`; pelo menos 75% dos passos horizontais não nulos devem ter o mesmo sentido.
5. Depois de emitir uma candidata, rearmar somente após pelo menos 5 amostras e `0.15 s` de mão estável com deslocamento total abaixo de `0.25 ×` a largura da palma; perda de tracking também limpa o segmento sem reconhecer.

Estes valores são a versão inicial do critério (`gesture-rules-v1`). Serão parametrizados para testes/piloto; qualquer ajuste deve atualizar esta seção e os testes correspondentes. Não são limites de latência, acurácia global ou aprovação da Fase 1.

### Non-Functional Requirements

- **NFR-001 Latência**: medir separadamente captura/detecção, regra geométrica e ida até resultado oficial; reportar distribuição/percentis em hardware documentado. Limite aprovado continua pendente.
- **NFR-002 Estabilidade**: registrar FPS observado, frames perdidos, perda/recuperação de mão, falsos candidatos e duplicatas em sessão contínua. Metas numéricas permanecem pendentes.
- **NFR-003 Recursos**: medir CPU/memória e, se aplicável, GPU em repouso e webcam ativa; não inventar orçamento numérico.
- **NFR-004 Manutenibilidade**: critérios/IDs ficam em módulo puro de regras, parâmetros versionados, entrada MediaPipe e HUD ficam em pacote de visão/demonstração; núcleo permanece importável sem OpenCV/MediaPipe.
- **NFR-005 Privacidade**: imagem processada localmente, não persistida e não transmitida. Dados enviados ao verificador são dependência do gate OpenAI existente; esta Feature não cria payload.

### Key Entities

- **HandObservation**: amostra iterável de 63 coordenadas finitas, handedness e timestamp monotônico; dados MediaPipe da frame espelhada.
- **GestureCandidate**: resultado geométrico local `RecognitionResult` provisório para HUD; não é evento/comando oficial.
- **RecognitionResult oficial**: produzido somente pelo `RecognitionSession` existente; sem alterações no contrato.
- **VisionFrame**: frame espelhado para exibição, observação opcional e FPS/estado de captura; não persistido.

## Success Criteria

- **SC-001**: testes de fixtures produzem `HORIZONTAL_CUT` para as trajetórias sintéticas que atendem a `gesture-rules-v1` e não o produzem quando cada limiar espacial/temporal falha.
- **SC-002**: testes de fixtures produzem `PALM_FORWARD` somente quando os quatro dedos, polegar, orientação assinada e sustentação satisfazem os critérios iniciais.
- **SC-003**: 100% das entradas sem mão, inválidas ou tracking quebrado não contêm `gesture_id` oficial.
- **SC-004**: com verifier desabilitado, toda fixture geométrica candidata mantém status oficial `unavailable` e sem `gesture_id`, enquanto HUD continua exibindo o candidato local.
- **SC-005**: falha ao abrir/ler câmera e pressionar `q` liberam recursos de modo reproduzível em testes com doubles, sem câmera real.
- **SC-006**: cada amostra válida tem exatamente 63 números finitos e todos os testes da camada de visão/classificador passam sem OpenCV/MediaPipe, webcam ou rede reais.
- **SC-007**: teste manual local documenta versão de Python, câmera, resolução/condições e FPS/latência observados; sem metas de desempenho aprovadas não declara saída da Fase 1.

## Scope Boundary

Esta Feature adiciona somente a ferramenta local de câmera, visualização de landmarks e prévia geométrica. Captura/detecção são responsabilidades desta nova Feature sob a autorização de FR-015; reconhecimento oficial continua delegado ao núcleo 002 e o Unity/transporte permanece fora do escopo.
