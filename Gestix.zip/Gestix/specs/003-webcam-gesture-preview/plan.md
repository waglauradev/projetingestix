# Implementation Plan: Webcam e Prévia de Gestos

**Branch**: `003-webcam-gesture-preview` | **Date**: 2026-11-25 | **Spec**: [spec.md](spec.md)

## Summary

Adicionar runner local Python com OpenCV para webcam espelhada e MediaPipe Tasks Hand Landmarker em modo `VIDEO`; desenhar os 21 landmarks; converter a mão para `HandObservation` de 63 floats finitos; executar as regras de preview v1 injetadas no `RecognitionSession` já existente; mostrar lado a lado candidata geométrica e resultado oficial. Nenhum módulo existente do núcleo 002 será alterado. OpenAI permanece sujeita às aprovações e gates 002; status oficial continua `unavailable` quando desabilitada.

## Technical Context

**Language/Version**: Python 3.11+ (conforme o pedido desta implementação); a máquina não tem `python` instalado no PATH nem `py` com intérprete encontrado, então compatibilidade/testes ainda não puderam ser executados.  
**Primary Dependencies**: `opencv-python` e NumPy para captura/desenho/janela; `mediapipe` Tasks `HandLandmarker` para landmarks 21 pontos, handedness e tracking. API legado `mp.solutions` não será usado.  
**Model Asset**: arquivo oficial de tarefa `hand_landmarker.task` necessário em `models/hand_landmarker.task`; não será incluído nem baixado automaticamente pelo código. O guia oficial atual usa `mp.tasks.vision.HandLandmarker`, modo VIDEO, timestamp monotônico e asset `.task`.  
**Storage**: nenhum frame, landmark ou resultado armazenado em disco.  
**Testing**: `unittest` padrão; OpenCV/MediaPipe importados somente ao inicializar hardware e nunca necessários para os testes unitários de geometria/conversão.  
**Target Platform**: desktop local com webcam, Python 3.11+, SO/dispositivo específicos pendentes.  
**Project Type**: extensão independente `src/gestix/vision/` e ponto de entrada `python -m gestix.vision.runner`; regras puras em módulo separado `src/gestix/recognition/gesture_rules.py`, núcleo atual continua intacto.  
**Performance Goals**: metas numéricas de latência/FPS não estão definidas; registrar FPS, duração MediaPipe/regras e tempo do resultado oficial por execução de teste.  
**Constraints**: processar vídeo local; no máximo uma mão (`num_hands=1`); uma amostra por frame; API OpenAI só pode ser consultada pelo verificador existente quando gates e configuração aprovados, sem chamada ou payload novo nesta Feature; Unity e comandos ficam fora.  
**Scale/Scope**: dois gestos candidatos; câmera única local; sem gravação.

## Constitution Check

- **I–II**: visão/captura, regras geométricas e UI são módulos separados; Python/OpenCV/MediaPipe existentes no baseline. Nenhum SDK/serviço adicional.
- **III**: OpenCV captura localmente, MediaPipe Hands detecta, câmera indisponível/frame vazio têm caminho de erro explícito; frames não são persistidos.
- **IV**: somente corte horizontal e palma à frente. A matemática produz candidata; API verifica inconsistência; modo offline mostra apenas preview; `RecognitionSession` sem verificador aprovado continua `unavailable`.
- **V**: nenhum comando/ação aparece em `RecognitionResult`; Unity/transporte não fazem parte desta Feature.
- **VI–VIII**: testes reprodutíveis simulam câmera/MediaPipe e usam fixtures sintéticas; medir desempenho real depois, sem limites inventados.
- **IX–X**: esta nova Spec 003 referencia e preserva 002; não declara saída/aprovação da Fase 1 nem inicia Fase 2.
- **XI–XII**: sem sincronização musical; processamento local, sem persistência ou envio real adicional.

## Architecture

```text
OpenCV VideoCapture
  -> flip frame horizontalmente
  -> MediaPipe Tasks HandLandmarker (VIDEO, timestamp monotônico)
  -> desenhar conexões e pontos no frame espelhado
  -> landmark_adapter: 21 x (x,y,z) -> HandObservation (63 floats, handedness, tempo)
       -> GestureRuleClassifier.preview(sample) -> candidata visual (debug)
       -> RecognitionSession.process(sample) -> estado oficial
  -> HUD mostra os dois resultados separadamente + FPS -> OpenCV window
```

`GestureRuleClassifier` é stateful para janelas temporais e é usado como Callable pelo `RecognitionSession`. Um segundo exemplar puro de regra atualiza a prévia visual; os dois recebem as mesmas amostras e timestamps. A prévia local não substitui o resultado da sessão. Se a regra candidata se satisfaz e o verificador está desligado, a sessão retorna `unavailable` e sem ID oficial. Sem mão, runner envia `[]`, logo o validador da sessão retorna `not_recognized`. Falha de câmera produz `RecognitionResult.unavailable` diretamente na UI.

## Project Structure

```text
src/gestix/recognition/                 # núcleo 002 — não alterar
src/gestix/recognition/gesture_rules.py # regras matemáticas versionadas, sem dependências de vídeo
src/gestix/vision/__init__.py
src/gestix/vision/landmarks.py          # HandObservation, validação e flatten
src/gestix/vision/mediapipe_camera.py  # OpenCV + Tasks API, detecção e desenho
src/gestix/vision/runner.py             # loop, sessão, prévia e HUD
tests/vision/test_landmarks.py
tests/vision/test_gesture_rules.py
tests/vision/test_vision_runner.py       # doubles/fakes; sem câmera/rede
requirements-vision.txt
specs/003-webcam-gesture-preview/       # Spec, plan, tasks, research, data-model, contract, quickstart
```

## Failure Handling & Security

- Falta do modelo `.task`: erro claro de configuração antes de abrir câmera; status visual indisponível.
- Camera index/open/read/frame inválido: resultado oficial indisponível e cleanup determinístico.
- Sem mão: resetar janelas temporais e enviar vazio para a sessão (`not_recognized`).
- Landmark incompleto/NaN/Inf/handedness inválido: descartar como entrada inválida; nenhum ID.
- MediaPipe/runner exceção: `unavailable`, fechar camera/landmarker/janela em `finally`.
- OpenAI: construir `OpenAIConfig.from_env()` com flags existentes; não criar payload/parser nem executar request; com config incompleta o adaptador existente fica `unavailable`.
- Tecla `q`: sair mesmo se cleanup falhar parcialmente; sem persistência.

## Validation Strategy

1. Testar flatten exato de 21 landmarks, ordem, aspecto, handedness, dimensões, entrada ausente/incompleta/não finita.
2. Testar cada desigualdade geométrica e temporal de `gesture-rules-v1` com fixtures construídas; positivos/negativos de corte, palma, diagonal, abaixo do deslocamento, dedos dobrados, ângulo incorreto, janela curta/longa e rearme.
3. Testar aplicação com `RecognitionSession` real e verificador OpenAI desabilitado: candidata local visível, status oficial `unavailable`, sem ID; sem mão oficial `not_recognized`; falha câmera `unavailable`.
4. Testar fluxo de câmera/landmarker/HUD com objetos fake; nenhum dispositivo ou request externo.
5. Após instalar dependências e baixar manualmente modelo oficial, executar teste manual; registrar Python, SO, webcam, resolução, luz, distância, FPS e latência. Esta máquina não tem intérprete Python acessível nesta execução, então testes ficam explicitamente pendentes até runtime disponível.

## Dependencies & Risks

- Python 3.11+ e pacotes `opencv-python` e `mediapipe` precisam ser instalados em ambiente de produto. Disponibilidade de wheel para o SO/Python alvo deve ser confirmada ao configurar o runtime.
- Modelo oficial `hand_landmarker.task` deve ser obtido manualmente na página oficial MediaPipe; não incluir binário/modelo no repositório.
- Critérios `gesture-rules-v1` são hipóteses geométricas iniciais autorizadas para piloto; iluminacão, oclusão, posição, velocidade e lente podem pedir calibração. Não equivalem a metas de qualidade aprovadas.
- Identificação da face da palma depende do eixo Z e handedness após espelhamento; os testes geométricos não substituem ensaio com mão real.
- Latência sincronizada do LLM pode reduzir FPS depois que uma integração API for aprovada; esta Feature não faz teste live nem altera o comportamento síncrono do núcleo.
- Modelo/payload/privacy/timeout/custos e ratificação constitucional são decisões pendentes de 002. Nenhum fluxo API será ativado por inferência.
